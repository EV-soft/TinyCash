<?php # /sales_hub.php v:1.3.1 d:2026-09-15 i:evs
# Salg & kunder: samlet oversigt med to lister side om side.
# Kundeliste: navn/email, med knapper til Redigér og Kontoudtog (customer_statement.php).
# Fakturaliste: nr./dato/kunde/beløb (inkl. moms, viser restbeløb ved delvis
# betaling)/status, filtrerbar på status (alle/kladde/sendt/betalt). Handlinger
# afhænger af status: kladder kan redigeres/bogføres/slettes; bogførte
# fakturaer (der ikke allerede er krediteret eller selv er en kreditnota) kan
# krediteres. Bogføring og mailafsendelse sker async via fetch() mod
# invoice_post_action.php/send_invoice_action.php, med en fælles styled
# sysConfirm()-bekræftelsesdialog i stedet for native confirm().
require_once 'inc/db_connect.inc.php';
require_once 'inc/auth.inc.php';
require_once 'inc/php2htm.lib.php';
require_once 'inc/menu.inc.php';

$current_status = isset($_GET['status']) ? $_GET['status'] : 'all';
$current_cust   = (int)($_GET['cust'] ?? 0);      // Fakturalisten for én kunde (knappen "Vis kundens fakturaer" i kundelisten)

htm_Header("@Sales & Customers", 1600);
showMenu();

echo '<style>
    .hub-total { font-family: "Courier New", monospace; font-size: 1.1rem; font-weight: 600; text-align: right; }
    #hub_cust th, #hub_inv th, th.sortable { color: #333333 !important; font-weight: bold !important; }
    th.sortable { cursor: pointer; position: relative; }
    th.sortable:after { content: "\f0dc"; font-family: FontAwesome; padding-left: 5px; color: #ccc; }
    #hub_cust td, #hub_inv td { color: var(--theme-text, #333); }
    .filter-label { font-size:0.8rem; font-weight:bold; margin-right:5px; font-family:sans-serif; color: var(--theme-text-muted, #555); }
    .filter-btn { padding:5px 12px; border:1px solid var(--theme-border, #ddd); border-radius:15px; cursor:pointer; font-size:0.75rem; }

    [data-theme="dark"] .filter-label { color: #a4b0be !important; }
    [data-theme="dark"] .btn-info, [data-theme="dark"] [class*="info"], [data-theme="dark"] .bg-info, [data-theme="dark"] a[class*="info"], [data-theme="dark"] a[href*="type="] { background-color: #00a8ff !important; border-color: #00a8ff !important; color: #ffffff !important; }
    [data-theme="dark"] .btn-success, [data-theme="dark"] [class*="success"], [data-theme="dark"] .bg-success { background-color: #10ac84 !important; border-color: #10ac84 !important; color: #ffffff !important; }
    [data-theme="dark"] .btn-info a, [data-theme="dark"] .btn-info i, [data-theme="dark"] .btn-success a, [data-theme="dark"] .btn-success i, [data-theme="dark"] [id$="_card"] a, [data-theme="dark"] [id$="_card"] .btn i { color: #ffffff !important; text-decoration: none !important; }
    [data-theme="dark"] #hub_cust th, [data-theme="dark"] #hub_inv th, [data-theme="dark"] th.sortable { color: #ffffff !important; }
    [data-theme="dark"] #hub_cust td, [data-theme="dark"] #hub_inv td { color: #dcdde1 !important; }
    [data-theme="dark"] th.sortable:after { color: #57606f; }
    [data-theme="dark"] #c_card, [data-theme="dark"] #i_card, [data-theme="dark"] [class*="card"], [data-theme="dark"] [class*="panel"] { color: #ffffff !important; }
    [data-theme="dark"] #c_card h1, [data-theme="dark"] #c_card h2, [data-theme="dark"] #c_card h3, [data-theme="dark"] #c_card h4,
    [data-theme="dark"] #i_card h1, [data-theme="dark"] #i_card h2, [data-theme="dark"] #i_card h3, [data-theme="dark"] #i_card h4 { color: #ffffff !important; }

    /* ── sysConfirm modal ── */
    #sys-confirm-overlay {
        display: none; position: fixed; inset: 0;
        background: rgba(0,0,0,0.45); z-index: 999998;
        align-items: center; justify-content: center;
    }
    #sys-confirm-overlay.open { display: flex; }
    #sys-confirm-box {
        background: var(--bg-card); border-radius: 10px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.35);
        max-width: 420px; width: 90%; font-family: sans-serif;
        overflow: hidden; animation: scaleIn 0.15s ease;
    }
    @keyframes scaleIn { from { transform: scale(0.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    #sys-confirm-icon { font-size: 2.2em; margin-bottom: 8px; }
    #sys-confirm-title { margin: 0 0 6px; color: var(--color-dark); font-size: 1.05em; font-weight: 700; }
    #sys-confirm-text { color: var(--text-muted); font-size: 0.92em; line-height: 1.5; margin: 0; }
    #sys-confirm-buttons { display: flex; gap: 10px; padding: 14px 20px; justify-content: flex-end; background: var(--bg-panel); border-top: 1px solid var(--border-color); }
    #sys-confirm-buttons button { padding: 8px 20px; border: none; border-radius: 5px; font-size: 0.9em; font-weight: 600; cursor: pointer; transition: opacity 0.15s; }
    #sys-confirm-buttons button:hover { opacity: 0.85; }
    #sys-confirm-cancel { background: var(--bg-card); color: var(--text-muted); border: 1px solid var(--border-color) !important; }
    #sys-confirm-ok { color: white; }
</style>';

echo '<script>
// ── sysConfirm: styled confirm-dialog ────────────────────────────────────────
(function() {
    var _cb = null;
    window.sysConfirm = function(msg, callback, opts) {
        opts = opts || {};
        document.getElementById("sys-confirm-icon").textContent    = opts.icon    || "⚠️";
        document.getElementById("sys-confirm-title").textContent   = opts.title   || msg;
        document.getElementById("sys-confirm-text").textContent    = msg;
        document.getElementById("sys-confirm-ok").textContent      = opts.okLabel || "' . lang('@Confirm') . '";
        document.getElementById("sys-confirm-ok").style.background = opts.okColor || "var(--color-danger)";
        // "tc-info-fill" (htm_page.lib.php): kun når DENNE knap rent faktisk
        // bruger var(--color-info) som baggrund - den er lysegrå i dark-temaet
        // og gør ellers #sys-confirm-oks faste "color:white" ulæselig. De andre
        // okColor-varianter (color-danger/color-success) er mørke/mættede i
        // alle temaer og skal fortsat have almindelig hvid tekst.
        document.getElementById("sys-confirm-ok").classList.toggle("tc-info-fill", opts.okColor === "var(--color-info)");
        document.getElementById("sys-confirm-cancel").textContent  = opts.cancelLabel || "' . lang('@Cancel') . '";
        _cb = callback;
        document.getElementById("sys-confirm-overlay").classList.add("open");
    };
    window._sysConfirmOk = function() {
        document.getElementById("sys-confirm-overlay").classList.remove("open");
        if (typeof _cb === "function") _cb();
        _cb = null;
    };
    window._sysConfirmCancel = function() {
        document.getElementById("sys-confirm-overlay").classList.remove("open");
        _cb = null;
    };
})();

// ── Faktura-handlinger ────────────────────────────────────────────────────────
// RETTET (§bugs-batch-19-review): intet forhindrede et utålmodigt gentaget
// klik på "Bogfør" (eller en langsom forbindelse + et andet klik i mellem-
// tiden) i at affyre flere samtidige bogføringsforsøg for samme faktura, før
// siden nåede at genindlæse og vise den nye "sendt"-status. Server-siden
// (invoice_post_action.php) har nu sit eget, uafhængige kapløbsværn - denne
// simple in-flight-spærring her er blot et ekstra, hurtigere lag, der
// forhindrer selve dobbeltklikket i at sende det andet kald overhovedet.
var _postInvInFlight = {};
function postInv(id) {
    if (_postInvInFlight[id]) return;
    sysConfirm(
        "' . lang('@Are you sure you want to post this invoice? This will assign an official invoice number and lock the draft.') . '",
        function() {
            if (_postInvInFlight[id]) return;
            _postInvInFlight[id] = true;
            fetch("invoice_post_action.php?id=" + id, { method: "POST", body: new URLSearchParams({ csrf_token: ' . json_encode(csrf_token()) . ' }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { sysAlert("' . lang('@Invoice successfully posted with number: ') . '" + data.invoice_no); location.reload(); }
                    else { sysAlert("' . lang('@Posting failed: ') . '" + data.error); _postInvInFlight[id] = false; }
                })
                .catch(() => { sysAlert("' . lang('@System error: Could not connect to server.') . '"); _postInvInFlight[id] = false; });
        },
        { title: "' . lang('@Post Invoice') . '", icon: "📋", okLabel: "' . lang('@Post Invoice') . '", okColor: "var(--color-success)" }
    );
}

function delInv(id) {
    sysConfirm(
        "' . lang('@Delete Invoice?') . '",
        function() { tcPost("invoice_edit.php?id=" + id + "&del=1"); },
        { title: "' . lang('@Delete Invoice') . '", icon: "🗑️", okLabel: "' . lang('@Delete') . '", okColor: "var(--color-danger)" }
    );
}

function setFilter(status) {
    window.location.href = "sales_hub.php?status=" + status + "' . ($current_cust > 0 ? '&cust=' . $current_cust : '') . '";
}

function sendMail(id) {
    sysConfirm(
        "' . lang('@Send Invoice via Email?') . '",
        function() {
            const btn = document.getElementById("mail_btn_" + id);
            const originalHTML = btn ? btn.innerHTML : "";
            if (btn) { btn.disabled = true; btn.innerHTML = \'<i class="fa fa-spinner fa-spin"></i>\'; btn.style.opacity = "0.6"; }
            fetch("send_invoice_action.php?id=" + id, { method: "POST", body: new URLSearchParams({ csrf_token: ' . json_encode(csrf_token()) . ' }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { sysAlert("' . lang('@Email sent successfully!') . '"); location.reload(); }
                    else {
                        sysAlert("' . lang('@Error: ') . '" + data.error);
                        if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; btn.style.opacity = "1"; }
                    }
                })
                .catch(() => {
                    sysAlert("' . lang('@System error: Could not connect to mail system.') . '");
                    if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; btn.style.opacity = "1"; }
                });
        },
        { title: "' . lang('@Send Invoice') . '", icon: "📧", okLabel: "' . lang('@Send') . '", okColor: "var(--color-info)" }
    );
}
</script>';

// ── sysConfirm HTML ───────────────────────────────────────────────────────────
echo '<div id="sys-confirm-overlay">
    <div id="sys-confirm-box">
        <div style="padding:24px 24px 16px; text-align:center;">
            <div id="sys-confirm-icon">⚠️</div>
            <h3 id="sys-confirm-title"></h3>
            <p id="sys-confirm-text"></p>
        </div>
        <div id="sys-confirm-buttons">
            <button id="sys-confirm-cancel" onclick="_sysConfirmCancel()">'.lang('@Cancel').'</button>
            <button id="sys-confirm-ok"     onclick="_sysConfirmOk()">'.lang('@Confirm').'</button>
        </div>
    </div>
</div>';

echo '<div style="display:flex; gap:10px; align-items:flex-start; padding:10px;">';

# KOLONNE 1: KUNDER
echo '<div style="flex:2; min-width:400px;">';
    $c_tools  = htm_Button('fa-file-csv',  '', 'info',    'export.php?type=customers',  'padding:4px 8px; margin-right:5px;', 'target="_blank" data-hint="'.lang('@Export All Data').'"', '', false);
    $c_tools .= htm_Button('fa-user-plus', '', 'success', 'customer_edit.php?id=0',     'padding:4px 8px;',                   'data-hint="'.lang('@Create New').'"',                    '', false);
    htm_Card_('@Customers', "100%", "", "c_card", true, $c_tools, fold: true); // TEST: fold-toggle

    // NYT: ingen side i systemet rangerede kunder efter reel omsætning - man kunne se ÉN kundes tal ad gangen på
    // kundekortet, men ikke sammenligne på tværs. Ganges med exch_rate for fremmed-valuta-fakturaer, samme mønster
    // som reminders.php/reconcile_action.php - ellers ville en stor EUR-faktura tælle med sit rå, uomregnede
    // beløb.
    $sh_disc = invoice_discount_sql($conn, 'il.');
    $top_cust_res = DB::query($conn, "
        SELECT c.cust_id, c.cust_name,
               SUM(il.quantity * il.price_each $sh_disc * COALESCE(NULLIF(i.exch_rate, 0), 1)) AS revenue      -- RETTET: omsætning er UDEN moms (var inkl. - 25 % for højt mod resultatopgørelse og bestsellerliste)
        FROM invoice_lines il
        JOIN invoices i ON il.inv_id = i.inv_id
        JOIN customers c ON i.cust_id = c.cust_id
        WHERE LOWER(i.inv_status) != 'draft'
        GROUP BY c.cust_id, c.cust_name
        HAVING SUM(il.quantity * il.price_each) != 0
        ORDER BY revenue DESC
        LIMIT 10");
    $top_cust_rows = [];
    while ($tcr = DB::fetch_assoc($top_cust_res)) {
        $top_cust_rows[] = [
            '<a href="customer_edit.php?id='.(int)$tcr['cust_id'].'">'.htmlspecialchars($tcr['cust_name']).'</a>',
            fmt_dk((float)$tcr['revenue']) . ' ' . ($global_settings['currency'] ?? 'DKK'),
        ];
    }
    if (!empty($top_cust_rows)) {
        echo '<details style="margin-bottom:15px;"><summary style="cursor:pointer; font-weight:bold; color:var(--text-muted); user-select:none; list-style:none; display:flex; align-items:center; gap:6px;">'
            . '<i class="fa-solid fa-ranking-star" style="color:var(--color-primary);"></i> ' . lang('@Top Customers by Revenue') . '</summary>';
        echo '<div style="margin-top:8px;">';
        htm_Table(['@Customer', '@Revenue'], $top_cust_rows, 'topCustTbl', 10, '', true, ['', 'width:150px; text-align:right;']);
        echo '</div></details>';
    }

    $data_c = [];
    $missing_email_cnt = 0;
    $dormant_cnt = 0;
    // NYT: sidste fakturadato pr. kunde hentes i samme forespørgsel (undgår N+1), samme "ekskludér
    // kladder"-princip som resten af rundens nye paneler - en kladde er endnu ikke en reel handel og skal ikke
    // tælle som "aktivitet".
    $resc = DB::query($conn, "SELECT c.cust_id, c.cust_name, c.cust_email,
        (SELECT MAX(i.inv_date) FROM invoices i WHERE i.cust_id = c.cust_id AND LOWER(i.inv_status) != 'draft') AS last_inv_date
        FROM customers c WHERE " . customers_active_filter($conn, 'c.') . " ORDER BY c.cust_name");
    // RETTET: "LIMIT 100" - kunde nr. 101 og frem (alfabetisk) blev aldrig vist i kundelisten, og tællerne
    // "mangler e-mail" / "ingen faktura i 6 måneder" regnede kun på de første 100. Tabellen sideinddeler selv.
    if ($resc) {
        $today = date('Y-m-d');
        while ($rowc = DB::fetch_assoc($resc)) {
            $btn = htm_ActionButtons([
                ['icon' => 'fa-pencil',              'link' => 'customer_edit.php?id='.$rowc['cust_id'],      'hint' => '@Edit', 'type' => 'primary'],
                ['icon' => 'fa-file-invoice-dollar',  'link' => 'customer_statement.php?id='.$rowc['cust_id'], 'hint' => '@Account Statement', 'type' => 'info'],
                ['icon' => 'fa-list',                 'link' => 'sales_hub.php?cust='.$rowc['cust_id'].'#i_card', 'hint' => '@Show the invoices of this customer', 'type' => ((int)$rowc['cust_id'] === $current_cust ? 'success' : 'secondary')],
            ], false);
            // RETTET: en manglende mailadresse blot viste et tomt felt her, uden nogen forklaring på at det stille
            // blokerer flere andre funktioner (reminders.php/customer_statement_send.php/quote_followup.php
            // springer alle en kunde uden mail over uden varsel). Fremhæver nu tomme mailfelter i rødt.
            $email_cell = !empty($rowc['cust_email'])
                ? htmlspecialchars($rowc['cust_email'])
                : '<span style="color:var(--color-danger); font-weight:bold;" data-hint="'.htmlspecialchars(lang('@No email registered - this customer will silently be skipped by payment reminders, account statement emails and quote follow-ups')).'"><i class="fa-solid fa-triangle-exclamation"></i> '.lang('@Missing').'</span>';
            if (empty($rowc['cust_email'])) $missing_email_cnt++;
            // RETTET: cust_name/cust_email skrevet direkte ind i tabellen uden escaping - htm_Table antager at
            // hver celle allerede er den HTML der skal vises (mange kald sender bevidst <a>/<span>), så uescaped
            // fritekst som et kundenavn er en lagret XSS (fx et kundenavn "<script>...").
            $name_cell = htmlspecialchars($rowc['cust_name']);
            // NYT: en kunde der har haft mindst én rigtig faktura, men intet i 180+ dage, flages som "inaktiv" -
            // nyttigt til at fange kunder der er ved at forsvinde, før det er for sent at genaktivere dem. En
            // kunde der ALDRIG har fået en faktura flages IKKE her - det er en anden situation (en helt
            // ny/potentiel kunde), ikke et tegn på at nogen er ved at forsvinde.
            if (!empty($rowc['last_inv_date'])) {
                $days_since = days_between($rowc['last_inv_date'], $today);
                if ($days_since > 180) {
                    $dormant_cnt++;
                    $name_cell .= ' <span style="color:var(--color-warning); font-size:0.85em;" data-hint="'.htmlspecialchars(sprintf(lang('@No invoice in %d days (last: %s)'), $days_since, date(CONF_DATE_FORMAT, strtotime($rowc['last_inv_date'])))).'"><i class="fa-solid fa-moon"></i></span>';
                }
            }
            $data_c[] = [$rowc['cust_id'], $name_cell, $email_cell, $btn];
        }
    }
    if ($dormant_cnt > 0) {
        htm_Banner('<i class="fa-solid fa-moon"></i> ' . sprintf(lang('@%d customer(s) have had no invoice in over 6 months (marked with a moon icon below).'), $dormant_cnt), 'info');
    }
    if ($missing_email_cnt > 0) {
        htm_Banner('<i class="fa-solid fa-triangle-exclamation"></i> ' . sprintf(lang('@%d customer(s) have no email address - they are silently skipped by payment reminders, account statement emails and quote follow-ups.'), $missing_email_cnt), 'warning');
    }
    htm_Table(['@ID', '@Name', '@Email', '@Action'], $data_c, 'hub_cust', 20, '', true,
        ['width:50px;', 'width:120px;', 'width:150px;', 'width:130px; text-align:center;']);
    htm_Card_end();
echo '</div>';

# KOLONNE 2: FAKTURAER
echo '<div style="flex:3;">';
    $i_tools  = htm_Button('fa-file-csv', '', 'info',    'export.php?type=invoices',  'padding:4px 8px; margin-right:5px;', 'target="_blank" data-hint="'.lang('@Export All Data').'"', '', false);
    $i_tools .= htm_Button('fa-plus',     '', 'success', 'invoice_edit.php?id=0',      'padding:4px 8px;',                   'data-hint="'.lang('@Create New').'"',                    '', false);
    htm_Card_("@Invoice List", "100%", "", "i_card", true, $i_tools);

    $i_filter  = '<div style="display:flex; gap:3px; margin-bottom:10px; align-items:center;" data-hint="'.lang('@Filter: Hide all data rows that do not meet criteria').'">';
    $i_filter .= '<span class="filter-label">' . lang('@Filter:') . '</span>';
    foreach (['all', 'draft', 'sent', 'paid'] as $f) {
        // RETTET: $f er altid småt ('draft'/'sent'/'paid'), men de faktiske oversættelsesnøgler er med stort
        // forbogstav (@Draft/@Sent/@Paid) - lang('@draft') matchede derfor aldrig noget, og filterknapperne viste
        // altid det engelske ord uanset sprogvalg. NB: lang('@'.ucfirst($f)) kan frase-skanneren ikke selv opdage
        // - de faktiske nøgler nævnes derfor bevidst som strengliteraler herunder: '@Draft', '@Sent', '@Paid'
        $l        = ($f === 'all') ? lang('@All') : tc_invoice_status_label($f);
        $isActive = (strtolower($current_status) === $f);
        $bg       = $isActive ? 'var(--theme-primary, #3498db)' : 'var(--theme-field-bg, #fff)';
        $color    = $isActive ? '#fff' : 'var(--theme-text, #333)';
        $i_filter .= '<button type="button" onclick="setFilter(\''.$f.'\')" class="filter-btn" style="background:'.$bg.'; color:'.$color.'; font-weight:'.($isActive?'bold':'normal').';">'.$l.'</button>';
    }
    // Kun én kundes fakturaer: navnet vises som et filter, der kan fjernes (status-filteret virker stadig)
    if ($current_cust > 0) {
        $cf_row = DB::fetch_assoc(DB::query($conn, "SELECT cust_name FROM customers WHERE cust_id = $current_cust"));
        $i_filter .= '<span class="filter-btn" style="background:var(--theme-primary, #3498db); color:#fff; font-weight:bold; margin-left:8px;">'
                   . '<i class="fa-solid fa-user"></i> ' . htmlspecialchars($cf_row['cust_name'] ?? ('#' . $current_cust))
                   . ' <a href="sales_hub.php?status=' . urlencode($current_status) . '#i_card" style="color:#fff; text-decoration:none; margin-left:6px;" data-hint="' . lang('@Show the invoices of all customers') . '">✕</a></span>';
    }
    $i_filter .= '</div>';

    $where = [];
    if ($current_status !== 'all') {
        $safe_status  = DB::real_escape_string($conn, strtolower($current_status));
        $where[] = "LOWER(i.inv_status) = '$safe_status'";
    }
    if ($current_cust > 0) $where[] = "i.cust_id = $current_cust";
    $where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $data_i = [];
    if (!defined('SALES_HUB_INV_LIMIT')) define('SALES_HUB_INV_LIMIT', 500);
    // RETTET 2026-08-20: ALVORLIGT FUND - "SUM(l.quantity * l.price_each)" manglede momsen HELT (intet moms-udtryk
    // overhovedet) - "Beløb"-kolonnen viste nettobeløbet, ikke det kunden reelt skylder, i modsætning til hver
    // anden fakturasum-visning i systemet (invoice_view.php, reminders.php osv.). "(100+rate)/100" i stedet for
    // "(1+rate/100)", som ville have udregnet momsen til 0 på SQLite.
    // RETTET: samme fejlklasse som lige fundet i reconcile_action.php/invoice_view.php - total_amount blev regnet
    // i fakturaens EGEN valuta (fx EUR), men sammenlignet direkte mod amount_paid, som ALTID er i DKK (rigtige
    // bankbeløb). "Restbeløb" for en delvist betalt udenlandsk faktura viste derfor et meningsløst tal (EUR-total
    // minus DKK-indbetaling).
    $sh_disc2 = invoice_discount_sql($conn, 'l.');
    // NYT (runde 33): credit_note_no findes kun efter db-setup/migrate_
    // credit_note_no.php er kørt - samme "stille degradering"-mønster som
    // andre nyere kolonner i denne kodebase.
    $has_cn_no_col = db_has_column($conn, 'invoices', 'credit_note_no');
    $sh_cn_no_select = $has_cn_no_col ? ", i.credit_note_no" : "";
    $query  = "SELECT i.inv_id, i.invoice_no, i.credit_ref$sh_cn_no_select, i.inv_date, c.cust_name, i.inv_status,
                      SUM(l.quantity * l.price_each $sh_disc2 * (100 + l.line_vat_rate) / 100.0 * COALESCE(NULLIF(i.exch_rate, 0), 1)) as total_amount,
                      COALESCE((SELECT SUM(amount) FROM invoice_payments WHERE inv_id = i.inv_id), 0) as amount_paid,
                      " . invoice_credited_sql($conn) . " as amount_credited,
                      (SELECT COUNT(*) FROM invoices x WHERE x.credit_ref = i.inv_id) as n_credit_notes
               FROM invoices i
               LEFT JOIN customers c ON i.cust_id = c.cust_id
               LEFT JOIN invoice_lines l ON i.inv_id = l.inv_id
               $where_clause
               GROUP BY i.inv_id
               ORDER BY i.inv_id DESC LIMIT " . SALES_HUB_INV_LIMIT;
    $resi = DB::query($conn, $query);
    if ($resi) {
        while ($rowi = DB::fetch_assoc($resi)) {
            $amou = fmt_dk($rowi['total_amount'] ?? 0);
            // Delvis betaling (2026-08-20): en faktura der er 'sent' men har
            // en eller flere indbetalinger registreret uden at dække det
            // fulde beløb, viser nu restbeløbet i stedet for at se ud som
            // helt ubetalt.
            $paid_so_far = (float)($rowi['amount_paid'] ?? 0);
            $credited_so_far = (float)($rowi['amount_credited'] ?? 0);      // (negativ: en delvis kreditnota)
            if (strtolower($rowi['inv_status']) === 'sent' && ($paid_so_far > 0.01 || $credited_so_far < -0.01)) {
                $remaining = max(0, (float)($rowi['total_amount'] ?? 0) + $credited_so_far - $paid_so_far);
                $amou .= '<br><small style="color:var(--color-warning); font-weight:normal;">' . lang('@Remaining:') . ' ' . fmt_dk($remaining) . '</small>';
            }
            $row_actions = [
                ['icon' => 'fa-eye', 'link' => 'invoice_view.php?id='.$rowi['inv_id'], 'hint' => lang('@Show and process'), 'type' => 'info'],
            ];
            // Slet vises nu KUN for kladder - en bogført faktura afvises alligevel server-side, så vis aldrig en
            // knap der bare ville blive nægtet. Rettelse af en bogført faktura sker via kreditnota (samme knap som
            // allerede fandtes).
            if (strtolower($rowi['inv_status']) === 'draft') {
                $row_actions[] = ['icon' => 'fa-pencil', 'link'    => 'invoice_edit.php?id='.$rowi['inv_id'], 'hint' => '@Edit',                        'type' => 'primary'];
                $row_actions[] = ['icon' => 'fa-gavel',  'onclick' => 'postInv('.$rowi['inv_id'].')',          'hint' => '@Post Invoice (Assign No.)',    'type' => 'success'];
                $row_actions[] = ['icon' => 'fa-trash',  'onclick' => 'delInv('.$rowi['inv_id'].')',           'hint' => '@Delete',                       'type' => 'danger'];
            } elseif (!in_array(strtolower($rowi['inv_status']), ['credited', 'credit'], true) && (int)($rowi['n_credit_notes'] ?? 0) === 0) {     // (én kreditnota pr. faktura - også en delvis)
                // RETTET: knappen blev vist for ALLE ikke-kladde-fakturaer, inkl. allerede krediterede fakturaer
                // og kreditnota-rækkerne selv - samme "vis aldrig en knap der bare bliver afvist"-princip som
                // Slet-knappen ovenfor allerede følger, nu udvidet til denne.
                $row_actions[] = ['icon' => 'fa-undo',   'link'    => 'invoice_credit.php?credit_ref='.$rowi['inv_id'],      /* RETTET: pegede på invoice_edit.php?id=0&credit_ref=, som ikke kender credit_ref - åbnede en tom ny faktura, og kreditnota-siden kunne slet ikke nås */ 'hint' => '@Credit this invoice (Auto-create)', 'type' => 'warning'];
            }

            // RETTET: en kladde der har ligget i månedsvis så identisk ud som en fra i går - dashboardets
            // "Kladdefakturaer"-tæller viser kun et råt antal, uden nogen alders-dimension. Fremhæver nu kladder
            // ældre end 30 dage med en rød "(N dage)"-markering direkte i listen, hvor man rent faktisk beslutter
            // om de skal ryddes op.
            // RETTET: en kreditnota-række har intet invoice_no - viste før blot '---'. Bruger nu dens eget
            // credit_note_no, hvis migrationen er kørt og nummeret er tildelt.
            if (!empty($rowi['credit_ref'])) {
                $invoice_display_no = !empty($rowi['credit_note_no']) ? 'KN-'.str_pad($rowi['credit_note_no'], 6, "0", STR_PAD_LEFT) : '---';
            } else {
                $invoice_display_no = (strtolower($rowi['inv_status']) === 'draft') ? lang('@Draft') : ($rowi['invoice_no'] ?: '---');
            }
            if (strtolower($rowi['inv_status']) === 'draft' && !empty($rowi['inv_date'])) {
                $draft_age_days = days_between($rowi['inv_date'], date('Y-m-d'));
                if ($draft_age_days > 30) {
                    $invoice_display_no .= ' <span style="color:var(--color-danger); font-weight:bold; font-size:0.85em;" data-hint="'.htmlspecialchars(sprintf(lang('@This draft was created %d days ago and may have been forgotten'), $draft_age_days)).'">(' . sprintf(lang('@%d days'), $draft_age_days) . ')</span>';
                }
            }
            // RETTET (§bugs-batch-13-review): samme uescapede cust_name som
            // kundelisten ovenfor - lagret XSS via et fritekst-kundenavn.
            $data_i[] = [
                $invoice_display_no,
                (!empty($rowi['inv_date']) ? date(CONF_DATE_FORMAT, strtotime($rowi['inv_date'])) : ''),      // RETTET: vist rå (ISO) uanset datoformatet
                htmlspecialchars($rowi['cust_name'] ?: '---'),
                $amou,
                mb_strtoupper(tc_invoice_status_label($rowi['inv_status'])),      // (nøglerne SENT/PAID med store bogstaver fandtes ikke - kun DRAFT)
                htm_ActionButtons($row_actions, false)
            ];
        }
    }
    // RETTET: listen stoppede stille ved de 100 nyeste fakturaer - ældre fakturaer kunne ikke findes herfra,
    // uden at noget sagde det. Nu 500, og en besked når grænsen er nået.
    if (count($data_i) >= SALES_HUB_INV_LIMIT) {
        htm_Banner('<i class="fa fa-info-circle"></i> ' . sprintf(lang('@Showing the newest %d invoices - choose a customer or a status to see older ones.'), SALES_HUB_INV_LIMIT), 'info');
    }
    htm_Table(['@Inv. No', '@Date', '@Customer', '@Amount', '@Status', '@Action'], $data_i, 'hub_inv', 20, $i_filter, true,
        ['width:90px;', 'width:120px;', 'width:200px;', 'width:100px; text-align:right;', 'width:90px; text-align:center;', 'width:140px; text-align:left;']);
    htm_Card_end();
echo '</div>';
echo '</div>';

echo '<script>
document.addEventListener("DOMContentLoaded", function() {
    try {
        const custSearch = document.querySelector("#hub_cust_search");
        if (custSearch) custSearch.setAttribute("data-hint", "' . lang('@Search for customer name, ID or email...') . '");
        const invSearch = document.querySelector("#hub_inv_search");
        if (invSearch) invSearch.setAttribute("data-hint", "' . lang('@Search for invoice number, customer or date...') . '");
    } catch(e) {}
});
</script>';

htm_Footer();
?>