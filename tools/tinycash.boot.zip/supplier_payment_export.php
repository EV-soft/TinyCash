<?php # /supplier_payment_export.php v:1.3.1 d:2026-09-15 i:evs
# NY FUNKTION (bruger-anmodet, "kan bogholderen ønske sig mere", runde 31):
# ingen måde at samle flere ubetalte leverandørudgifter til én betalingsomgang
# - bogholderen skulle betale hver for sig. Lader brugeren vælge blandt
# ubetalte, bogførte udgifter (samme $is_payable-kriterie som expense_list.
# php's "Betal nu"-knap) og downloade en CSV med reg.nr/kontonr/beløb/tekst
# til brug ved en samlet overførsel i netbank.
#
# BEVIDST IKKE et "certificeret" bankfil-format (fx et rigtigt Betalings-
# service-/SEPA-XML-format, som kræver en formel bankaftale og præcis
# overholdelse af en bank-specifik specifikation, der ikke kan garanteres
# korrekt herfra) - blot en almindelig CSV til manuel/semi-automatisk import,
# samme "aldrig lad som om noget er mere officielt end det er"-princip som
# resten af sessionen. Markerer ALDRIG selv udgifterne som betalt - det gør
# bogholderen stadig selv (expense_list.php's "Betal nu"), først når
# overførslen faktisk er gennemført.
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';

function spe_csv_safe($v) {
    if (!is_string($v) || $v === '') return $v;
    return (strpbrk($v[0], '=+-@') !== false) ? "'" . $v : $v;
}

$s   = get_settings($conn);
$cur = $s['currency'] ?? 'DKK';

$supplier_module_ready = db_has_column($conn, 'expenses', 'paid_date');
$has_bank_cols = db_has_column($conn, 'suppliers', 'supplier_reg_no');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exp_ids']) && is_array($_POST['exp_ids'])) {
    $ids = array_map('intval', $_POST['exp_ids']);
    $ids = array_filter($ids, fn($i) => $i > 0);
    if (!empty($ids)) {
        if (ob_get_level()) ob_end_clean();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="leverandoer_betalinger_' . date('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        // RETTET: beløbet var altid udgiftens KRONEbeløb uden valuta - en regning på 1.000 EUR stod som "7460,00" og
        // ville blive betalt med 7.460 i leverandørens valuta. Nu fakturaens eget beløb og valuta (kolonnen Valuta).
        $base_cur = strtoupper((string)($global_settings['currency'] ?? 'DKK'));
        fputcsv($output, [lang('@Supplier'), lang('@Reg. No.'), lang('@Account No.'), lang('@Amount'), lang('@Currency'), lang('@Reference')], ';', '"', '');
        $id_list = implode(',', $ids);
        $res = DB::query($conn, "SELECT e.*, s.supplier_name, s.supplier_reg_no, s.supplier_account_no
            FROM expenses e JOIN suppliers s ON e.supplier_id = s.supplier_id
            WHERE e.exp_id IN ($id_list) AND e.is_cancelled = 0 AND e.paid_date IS NULL AND e.voucher_no IS NOT NULL AND (e.exp_type IS NULL OR e.exp_type != 'income')
              AND e.amount > 0 AND COALESCE(s.supplier_reg_no, '') <> '' AND COALESCE(s.supplier_account_no, '') <> ''");      // (kun noget der skal betales, til en kendt konto)
        if ($res) {
            while ($r = DB::fetch_assoc($res)) {
                fputcsv($output, [
                    spe_csv_safe($r['supplier_name']),
                    spe_csv_safe($r['supplier_reg_no'] ?? ''),
                    spe_csv_safe($r['supplier_account_no'] ?? ''),
                    fmt_dk_input(!empty($r['orig_currency']) && (float)($r['orig_amount'] ?? 0) != 0 ? (float)$r['orig_amount'] : (float)$r['amount']),
                    !empty($r['orig_currency']) && (float)($r['orig_amount'] ?? 0) != 0 ? strtoupper($r['orig_currency']) : $base_cur,
                    lang('@Voucher') . ' ' . $r['voucher_no'],
                ], ';', '"', '');
            }
        }
        fclose($output);
        exit;
    }
}

htm_Header('@Supplier Payment Export');
showMenu();

echo "<div style='max-width:1000px; margin:0 auto; padding:10px;'>";
htm_Card_('@Supplier Payment Export', 1000);
htm_Note(lang('@Select unpaid, posted expenses below and download a CSV (supplier, reg. no., account no., amount, reference) for a batch payment in your netbank. This is NOT a certified bank file format - just a helpful export for manual/semi-automatic import. Does not mark anything as paid - do that from the Expense List once the transfer is actually made.'), 'font-size:0.9em; margin-top:-5px;');

if (!$supplier_module_ready) {
    htm_Banner('<i class="fa fa-triangle-exclamation"></i> ' . lang('@The supplier module database structure has not been set up yet. Run the migration under System -> Maintenance -> Database migration to enable the creditor side of this report.'), 'warning');
} elseif (!$has_bank_cols) {
    htm_Banner('<i class="fa fa-triangle-exclamation"></i> ' . lang('@Supplier bank details are not set up yet. Run the migration under System -> Maintenance -> Database migration, then add reg./account numbers on each supplier.'), 'warning');
} else {
    $spe_fx = db_has_column($conn, 'expenses', 'orig_currency') && db_has_column($conn, 'expenses', 'orig_amount');
    $res = DB::query($conn, "SELECT e.exp_id, e.amount, e.voucher_no, e.due_date" . ($spe_fx ? ", e.orig_currency, e.orig_amount" : "") . ", s.supplier_name, s.supplier_reg_no, s.supplier_account_no
        FROM expenses e JOIN suppliers s ON e.supplier_id = s.supplier_id
        WHERE e.is_cancelled = 0 AND e.voucher_no IS NOT NULL AND e.due_date IS NOT NULL AND e.paid_date IS NULL
          AND (e.exp_type IS NULL OR e.exp_type != 'income') AND e.amount > 0
        ORDER BY e.due_date ASC");
    // RETTET: et indtægtsbilag (exp_type 'income' - penge der skal IND) med forfaldsdato stod på listen over
    // leverandører der skal BETALES og kom med i betalingsfilen. Samme udelukkelse som aging_report.php.
    $rows = [];
    while ($r = DB::fetch_assoc($res)) {
        $has_bank_details = !empty($r['supplier_reg_no']) && !empty($r['supplier_account_no']);
        $rows[] = [
            '<input type="checkbox" name="exp_ids[]" value="' . (int)$r['exp_id'] . '" ' . ($has_bank_details ? '' : 'disabled') . ' onchange="updateSpeCount()">',
            htmlspecialchars($r['supplier_name']) . ($has_bank_details ? '' : ' <span style="color:var(--color-danger); font-size:0.8em;" data-hint="' . htmlspecialchars(lang('@No bank details registered for this supplier')) . '">(' . lang('@No bank details') . ')</span>'),
            date(CONF_DATE_FORMAT, strtotime($r['due_date'])),
            // Samme beløb og valuta som betalingsfilen (en regning på 1.000 EUR viste her 7.460 DKK)
            !empty($r['orig_currency']) && (float)($r['orig_amount'] ?? 0) != 0
                ? fmt_dk((float)$r['orig_amount']) . ' ' . htmlspecialchars(strtoupper($r['orig_currency'])) . ' <span style="color:var(--text-muted); font-size:0.85em;">(' . fmt_dk((float)$r['amount']) . ' ' . $cur . ')</span>'
                : fmt_dk((float)$r['amount']) . ' ' . $cur,
        ];
    }
    if (empty($rows)) {
        htm_Note(lang('@No unpaid, posted expenses found.'), 'font-style:italic;');
    } else {
        echo '<form method="post">';
        csrf_field();
        htm_Table(['&nbsp;', '@Supplier', '@Due Date', '@Amount'], $rows, 'speTbl', 100);
        echo '<button type="submit" id="speBtn" disabled style="margin-top:10px; padding:8px 16px; background:var(--color-success); color:#fff; border:none; border-radius:4px; cursor:pointer; opacity:0.5;"><i class="fa fa-file-csv"></i> ' . lang('@Download Payment CSV') . ' (<span id="speCount">0</span>)</button>';
        echo '</form>';
        ?>
        <script>
        function updateSpeCount() {
            var n = document.querySelectorAll('#speTbl input[name="exp_ids[]"]:checked').length;
            document.getElementById('speCount').innerText = n;
            var btn = document.getElementById('speBtn');
            btn.disabled = (n === 0);
            btn.style.opacity = (n === 0) ? '0.5' : '1';
        }
        </script>
        <?php
    }
}
htm_Card_end();
echo "</div>";
htm_Footer();
