<?php # /customer_contact_action.php v:1.3.1 d:2026-09-15 i:evs
# NY FUNKTION (bruger-anmodet, "kan bogholderen ønske sig mere", runde 33):
# gemmer/sletter en enkelt kontaktperson på customer_contacts - kaldet fra
# customer_edit.php's "Kontaktpersoner"-sektion. Rører aldrig selve customers.
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify()) {
    redirect("sales_hub.php");
}

$action  = $_POST['action'] ?? '';
$cust_id = (int)($_POST['cust_id'] ?? 0);

if ($cust_id <= 0) {
    redirect("sales_hub.php");
}

if ($action === 'add') {
    $name  = trim($_POST['contact_name'] ?? '');
    $email = trim($_POST['contact_email'] ?? '');
    $phone = trim($_POST['contact_phone'] ?? '');
    $note  = trim($_POST['contact_note'] ?? '');
    // (som kunde- og leverandørkortet: en ugyldig adresse - og en kunde der ikke findes - afvises på serveren, ikke kun i browseren)
    if (!tc_customer_ok($conn, $cust_id)) redirect('sales_hub.php', '@Not found - it may already have been deleted.', 'error');
    if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        redirect("customer_edit.php?id=$cust_id", '@Please enter a valid email address.', 'error');
    }
    // En kontakt med kun et telefonnummer blev stille smidt væk (ingen besked) - nu gemmes den, og en tom formular afvises
    if ($name === '' && $email === '' && $phone === '') {
        redirect("customer_edit.php?id=$cust_id#contacts", '@Enter at least a name, an email address or a phone number for the contact.', 'error');
    }
    if ($name !== '' || $email !== '' || $phone !== '') {
        DB::insert($conn, 'customer_contacts', [
            'cust_id'       => $cust_id,
            'contact_name'  => $name !== '' ? $name : null,
            'contact_email' => $email !== '' ? $email : null,
            'contact_phone' => $phone !== '' ? $phone : null,
            'contact_note'  => $note !== '' ? $note : null,
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
    }
} elseif ($action === 'delete') {
    $contact_id = (int)($_POST['contact_id'] ?? 0);
    if ($contact_id > 0) {
        DB::query($conn, "DELETE FROM customer_contacts WHERE contact_id = $contact_id AND cust_id = $cust_id");
    }
}

redirect("customer_edit.php?id=$cust_id#contacts");
