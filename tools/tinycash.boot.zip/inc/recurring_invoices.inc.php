<?php # /inc/recurring_invoices.inc.php v:1.3.0 d:2026-08-30 i:evs
# Automatisk generering af fakturaer fra faste/gentagne skabeloner
# (recurring_invoices + recurring_invoice_lines). TinyCash har ingen rigtig
# cron-adgang på almindelig delt hosting, så samme løsning som
# inc/auto_backup.inc.php genbruges: tjekkes ved hver sidevisning
# (htm_Footer()), men udfører kun reelt arbejde når noget faktisk er forfaldent.
#
# VIGTIGT (bogføringslov/uforanderlighed): denne funktion opretter ALTID en
# KLADDE, aldrig en bogført faktura direkte - nøjagtig samme princip som
# resten af fakturaflowet (§invoice-flow-integrity). Brugeren skal selv gå ind
# og bogføre (invoice_post_action.php), præcis som ved en manuelt oprettet
# faktura. Der genereres højst ÉN faktura pr. skabelon pr. sidevisning (ikke
# et helt "indhentnings"-baglæns i ét hug, hvis systemet fx ikke har været
# besøgt i flere måneder) - det throttler naturligt til højst én ny kladde
# pr. sidevisning, og indhenter sig selv over de næste sidevisninger i stedet
# for at eksplodere i én omgang.

function recurring_invoices_check($conn) {
    $today = date('Y-m-d');

    // RETTET: en kunde i papirkurven (customer_edit.php "Slet") fik stadig en ny fakturakladde hver periode - på en
    // kunde der ikke ses nogen steder. Skabelonen springes over (og står stille), så længe kunden er slettet;
    // gendannes kunden, fortsætter den, hvor den slap.
    $res = DB::query($conn, "SELECT recur_id FROM recurring_invoices
                              WHERE is_active = 1 AND next_run_date IS NOT NULL AND next_run_date >= '1990-01-01' AND next_run_date <= '$today'
                                AND cust_id IN (SELECT cust_id FROM customers WHERE " . customers_active_filter($conn) . ")
                              ORDER BY next_run_date ASC");
    if (!$res) return;

    while ($row = DB::fetch_assoc($res)) {
        generate_recurring_invoice($conn, (int)$row['recur_id'], true);
    }
}

// Genererer én kladde-faktura fra en skabelon og fremrykker next_run_date med
// ét interval. Kaldes både fra det automatiske tjek ovenfor ($auto=true) og
// fra "Generér nu"-knappen i recurring_invoices.php ($auto=false).
// Atomisk: reservationen af perioden, fakturahovedet og linjerne - fejler et trin, rulles alt tilbage, og perioden
// prøves igen ved næste sidevisning (før var perioden brugt op, og der kunne stå en kladde uden linjer)
function generate_recurring_invoice($conn, int $recur_id, bool $auto = false): ?int {
    try { return DB::transaction($conn, fn() => generate_recurring_invoice_steps($conn, $recur_id, $auto)); }
    catch (\Throwable $e) { error_log("[recurring invoice $recur_id] " . $e->getMessage());  return null; }
}
function generate_recurring_invoice_steps($conn, int $recur_id, bool $auto): ?int {
    $tmpl = DB::fetch_assoc(DB::query($conn, "SELECT * FROM recurring_invoices WHERE recur_id = $recur_id"));
    if (!$tmpl) return null;
    // RETTET: "Generér nu" dannede en kladde til en kunde i papirkurven (det automatiske tjek springer dem over)
    if (!tc_customer_ok($conn, (int)$tmpl['cust_id'])) return null;

    $today = date('Y-m-d');

    // RETTET: recurring_invoices_check køres ved HVER sidevisning (htm_Footer, se filens header) - to
    // næsten-samtidige sidevisninger (fx to faner, eller to brugere online samtidig, mens en skabelon er
    // forfalden) kunne begge bestå det automatiske tjeks SELECT (linje ~22) FØR nogen af dem nåede at behandle
    // den, og dermed begge generere en dublet-kladdefaktura for samme periode. Kun det automatiske tjek
    // ($auto=true) kapløbssikres her - "Generér nu"-knappen skal bevidst kunne kaldes flere gange samme dag (se
    // kommentaren nedenfor om et tidligt manuelt tryk), så den må ikke låses af samme tjek.
    if ($auto) {
        if (empty($tmpl['next_run_date']) || !strtotime((string)$tmpl['next_run_date']) || $tmpl['next_run_date'] < '1990-01-01' || $today < $tmpl['next_run_date']) return null;      // (en ugyldig dato kører aldrig)
        $claim_next = recurring_next_date($tmpl['next_run_date'], $tmpl['interval_type']);
        $old_next   = DB::escape($conn, $tmpl['next_run_date']);
        $claim_sql  = DB::query($conn, "UPDATE recurring_invoices
                                         SET last_run_date = '$today', next_run_date = '$claim_next'
                                         WHERE recur_id = $recur_id AND next_run_date = '$old_next'");
        if (!$claim_sql || DB::affected_rows($conn, $claim_sql) < 1) {
            return null; // en anden, samtidig sidevisning nåede allerede at behandle denne skabelon
        }
    }

    $due_days = max(0, (int)($tmpl['inv_due_days'] ?? 8));
    $due_date = date('Y-m-d', strtotime("+$due_days days"));
    $proj_sql = !empty($tmpl['proj_id']) ? (int)$tmpl['proj_id'] : 'NULL';

    $cust_ref = DB::escape($conn, $tmpl['cust_reference'] ?? '');
    $note     = DB::escape($conn, $tmpl['inv_note'] ?? '');
    $deliv    = DB::escape($conn, $tmpl['delivery_address'] ?? '');
    // RETTET: hardkodede 'DKK' ignorerede virksomhedens faktisk konfigurerede basisvaluta (Firmaindstillinger ->
    // Valuta) - en automatisk genereret gentagen faktura ville altid blive tagget som DKK, uanset hvad
    // virksomheden reelt har sat op. Samme fejlklasse som quote_actions.php's konverterings-flow og denne sessions
    $settings     = get_settings($conn);
    $inv_currency = DB::escape($conn, $settings['currency'] ?? 'DKK');

    $ok = DB::query($conn, "INSERT INTO invoices
        (cust_id, inv_date, inv_due_date, inv_status, cust_reference, inv_note, delivery_address, currency, proj_id)
        VALUES (" . (int)$tmpl['cust_id'] . ", '$today', '$due_date', 'draft', '$cust_ref', '$note', '$deliv', '$inv_currency', $proj_sql)");
    if (!$ok) throw new Exception('fakturahovedet: ' . DB::error($conn));
    $inv_id = DB::insert_id($conn);

    // EU-OSS: en privatkunde i et andet EU-land får modtagerlandets standardsats (som ved tilbud -> faktura) - ellers
    // afviste bogføringen hver måneds kladde, til hver linje var rettet i hånden
    require_once __DIR__ . '/oss.inc.php';
    $oss_cc = oss_ready($conn) ? oss_dest_for_customer($conn, (int)$tmpl['cust_id'], $today) : null;
    $lines_res = DB::query($conn, "SELECT * FROM recurring_invoice_lines WHERE recur_id = $recur_id ORDER BY rline_id");
    while ($l = DB::fetch_assoc($lines_res)) {
        if ($oss_cc !== null) $l['line_vat_rate'] = oss_map_rate($oss_cc, (float)$l['line_vat_rate']);
        $txt = DB::escape($conn, $l['line_text']);
        $lproj_sql = !empty($l['proj_id']) ? (int)$l['proj_id'] : $proj_sql;
        if (!DB::query($conn, "INSERT INTO invoice_lines
            (inv_id, line_text, quantity, price_each, line_vat_rate, prod_id, proj_id)
            VALUES ($inv_id, '$txt', " . (float)$l['quantity'] . ", " . (float)$l['price_each'] . ", "
            . (float)$l['line_vat_rate'] . ", " . (int)$l['prod_id'] . ", $lproj_sql)")) throw new Exception('en linje: ' . DB::error($conn));
    }

    // RETTET (ALVORLIGT FUND, se [[bugs-batch-10-review]]): recurring_next_date()
    // regner altid videre fra den GAMLE next_run_date, uanset hvornår denne
    // funktion reelt blev kaldt. Det er korrekt og bevidst for den
    // AUTOMATISKE tjek ovenfor (recurring_invoices_check() kalder kun hvis
    // next_run_date <= i dag, så "sent" er den eneste mulighed der - se
    // funktionens egen kommentar om at undgå datodrift). Men "Generér nu"-
    // knappen i recurring_invoices.php kan kaldes NÅR SOM HELST, også LÆNGE
    // før den planlagte dato - og da fremrykkede den ALTID skemaet ét
    // interval frem fra den gamle dato, uanset hvor tidligt den blev trykket.
    // Resultat: et tryk på "Generér nu" 3 måneder før forfald ville SPRINGE
    // den egentlige planlagte faktura for den periode helt over. Fremrykker
    // nu kun skemaet, hvis den faktisk var forfalden (i dag >= next_run_date)
    // - et tidligt manuelt tryk giver nu en ekstra faktura UDEN at forbruge
    // den kommende, planlagte kørsel.
    // ($auto=true har allerede kapløbssikret og fremrykket next_run_date i
    // claim-trinnet ovenfor - gøres den igen her, dobbelt-fremrykkes skemaet
    // ét helt ekstra interval for hver automatisk kørsel.)
    if (!$auto) {
        if ($today >= $tmpl['next_run_date']) {
            $next_run = recurring_next_date($tmpl['next_run_date'], $tmpl['interval_type']);
            DB::query($conn, "UPDATE recurring_invoices SET last_run_date = '$today', next_run_date = '$next_run' WHERE recur_id = $recur_id");
        } else {
            DB::query($conn, "UPDATE recurring_invoices SET last_run_date = '$today' WHERE recur_id = $recur_id");
        }
    }

    if (function_exists('log_action')) {
        log_action($conn, 'GENERATE_RECURRING_INVOICE', 'invoices', $inv_id,
            null, ['recur_id' => $recur_id, 'cust_id' => (int)$tmpl['cust_id']]);
    }

    return $inv_id;
}

// Beregner næste kørselsdato UD FRA den seneste planlagte dato (ikke fra "i dag") - undgår datodrift, hvis
// systemet fx ikke besøges i nogle dage efter forfald.
// RETTET: strtotime('+1 month') fra den 31. Nu: samme dag i måneden, højst månedens sidste dag - og er datoen den
// sidste i sin måned, er den næste også den sidste (31/1 -> 28/2 -> 31/3...).
function recurring_next_date(string $from_date, string $interval_type): string {
    $months = $interval_type === 'quarterly' ? 3 : ($interval_type === 'yearly' ? 12 : 1);
    $t = strtotime($from_date);
    $y = (int)date('Y', $t);  $m = (int)date('n', $t);  $d = (int)date('j', $t);
    $was_last = $d === (int)date('t', $t);
    $m += $months;
    $y += intdiv($m - 1, 12);  $m = ($m - 1) % 12 + 1;
    $last = (int)date('t', mktime(0, 0, 0, $m, 1, $y));
    return sprintf('%04d-%02d-%02d', $y, $m, $was_last ? $last : min($d, $last));
}
