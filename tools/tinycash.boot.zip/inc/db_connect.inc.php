<?php # /inc/db_connect.inc.php v:1.3.1 d:2026-09-15 i:evs
# dump_to_sql() medtager nu triggere - manglede FØR helt, så en gendannelse ville stille fjerne append-only-beskyttelsen på journal/ledger igen
# v1.3.0: DB::fetch_assoc()/fetch_row()/num_rows()/free_result() crashede med
# et fatal error ("Call to a member function fetch() on bool") hvis den givne
# forespørgsel fejlede (fx en manglende tabel/kolonne på en installation der
# mangler migrationer) - ramte en bruger reelt via invoice_view.php. Guard
# tilføjet alle fire steder, se kommentar ved fetch_assoc().
# v1.4.0: tilføjet next_invoice_no() - invoice_post_action.php brugte før et
# kapløbs-sårbart "MAX(invoice_no)+1"-mønster. Se kommentar ved funktionen.
define('APP_VERSION', '1.3.1');
define('APP_DATE', '2026-10-30');
/* 
// --- 1. SIKKER SESSIONSSTART & SPROGVÆLGER-LOGIK ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
 */
/* 
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = strtolower($_GET['lang']);
    
    // Fjern ?lang= parameteren fra URL'en og genindlæs siden rent
    $clean_url = strtok($_SERVER['REQUEST_URI'], '?');
    header("Location: " . $clean_url);
    exit;
} */

// --- 2. GLOBAL DEBUG CONTROL ---
// Fejl VISES kun med ?Debug=true for en indlogget bruger (eller den lokale udviklingsserver) - før kunne enhver, også
// uden login, få filstier og SQL-fejl vist. Fejl LOGGES altid: error_reporting(0) slog også logningen fra, så hverken
// advarsler eller fatale fejl (en hvid side) nogensinde kom i system_errors.log eller systemsundhedens tjek.
error_reporting(E_ALL);
if (isset($_GET['Debug']) && $_GET['Debug'] === 'true' && (!empty($_SESSION['user_id']) || PHP_SAPI === 'cli-server')) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    $GLOBAL_DEBUG_ALERT = '<div style="background:red; color:white; padding:5px; position:fixed; bottom:0; right:0; z-index:9999; font-size:10px; opacity:0.7;">DEBUG ACTIVE</div>';
} else {
    ini_set('display_errors', 0);
}

// --- 3. DYNAMISK KONFIGURATIONSLÆSER ---
// RETTET: env.ini flyttet til inc/data/env.ini. De to gamle stier ('inc/env.ini' og rod-'env.ini') beholdes SIDST
// i listen som bagudkompatibel fallback, så en installation der endnu ikke har flyttet sin fil manuelt (fx via
// FTP) ikke braser.
$env_file = null;
$SøgeStier = [
    __DIR__ . '/data/env.ini',
    __DIR__ . '/env.ini',
    __DIR__ . '/.env',
    __DIR__ . '/../env.ini',
    __DIR__ . '/../.env'
];

foreach ($SøgeStier as $sti) {
    if (file_exists($sti)) {
        $env_file = $sti;
        break;
    }
}

if ($env_file === null) {
    die("<div style='font-family:sans-serif; padding:50px; text-align:center;'>
            <h1 style='color:#e67e22;'>Konfigurationsfejl</h1>
            <p>Hverken <code>env.ini</code> eller <code>.env</code> kunne findes i dine mapper.</p>
         </div>");
}

$lines = @file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
if ($lines !== false) {
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, '#') === 0) continue;
        
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            $value = trim($value, "\"' ");
            
            if ($key !== '') {
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

// --- 4. HENT PARAMETRE FRA MILJØET (Med Sektioner) ---
$config = parse_ini_file($env_file, true);

// FEJLFINDING:
if ($config === false) {
    die("Fejl: Kunne ikke læse env.ini. Tjek rettigheder!");
}
if (!isset($config['ACTIVE_DB'])) {
    die("Fejl: Nøglen ACTIVE_DB blev ikke afundet i env.ini. Indhold fundet: " . implode(', ', array_keys($config)));
}
//   var_dump($config['ACTIVE_DB']);  exit; // DEBUG: Fjern denne linje når det virker

// --- TIDSZONE ---
// RETTET: TinyCash satte aldrig nogen tidszone - PHP brugte serverens php.ini (UTC på mange maskiner). Nu:
// TIMEZONE i env.ini, ellers dansk tid.
$tc_timezone = trim((string)($config['TIMEZONE'] ?? ''));
if ($tc_timezone === '' || !in_array($tc_timezone, timezone_identifiers_list(), true)) $tc_timezone = 'Europe/Copenhagen';
date_default_timezone_set($tc_timezone);

// --- NYT: FLERE REGNSKABER --- Er et regnskab valgt på login-siden, slår vi dets forbindelsesoplysninger op i
// inc/data/accounts.json og bruger DEM i stedet for den eneste, statiske ACTIVE_DB-sektion. Er intet regnskab
// valgt, springer denne gren helt over, og resten af filen opfører sig 100% som før - det er det, der gør
// bagudkompatibiliteten for eksisterende ét-regnskabs-installationer strukturel, ikke tilfældig.
require_once __DIR__ . '/account.lib.php';
$account_entry = (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['account_id']))
    ? account_get($_SESSION['account_id'])
    : null;

if ($account_entry) {
    $db_type     = $account_entry['engine'];
    $db_settings = account_resolve_settings($account_entry, $config['mysql_config'] ?? []);
} else {

// --- NYT: VALGBAR DATABASE-TYPE VIA SESSION (login.php) --- Hvis brugeren har valgt DB-type på login-siden,
// bruger vi DEN i stedet for den statiske ACTIVE_DB fra env.ini. NOTE: Selve forbindelsesoplysningerne
// (host/bruger/kodeord/sti) kommer STADIG udelukkende fra env.ini's [mysql_config]/[sqlite_config] - brugeren
// vælger kun HVILKEN af de to allerede konfigurerede sektioner der bruges, aldrig hvilke credentials der forbindes
// med.
$session_override = null;
if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['db_type']) && in_array($_SESSION['db_type'], ['mysql', 'sqlite'], true)) {
    $session_override = $_SESSION['db_type'] . '_config';
}

// Hent den aktive sektion fra roden af arrayet (session-valg vinder over ACTIVE_DB)
$active_section = $session_override ?? ($config['ACTIVE_DB'] ?? 'mysql_config');
// Hent kun indstillingerne for den aktive sektion
$db_settings = $config[$active_section] ?? [];
$db_type = $db_settings['DB_TYPE'] ?? 'mysql';

} // slut på "intet regnskab valgt"-grenen

// Gem den FAKTISK anvendte type tilbage i sessionen, så resten af sessionen
// (alle sider efter login) er konsistent, selv hvis valget kom fra env.ini's
// fallback i stedet for et eksplicit brugervalg.
if (session_status() === PHP_SESSION_ACTIVE) {
    $_SESSION['db_type'] = $db_type;
}

// Testpakken (tools/tests/run_tests.php): en isoleret SQLite-database via miljøvariablen TINYCASH_TEST_DB - kun fra
// kommandolinjen og PHP's indbyggede testserver, aldrig under en rigtig webserver
$tc_test_db = in_array(PHP_SAPI, ['cli', 'cli-server'], true) ? (string)getenv('TINYCASH_TEST_DB') : '';
if ($tc_test_db !== '') $db_type = 'sqlite';
// ... eller en isoleret MySQL-database: mysql://bruger:kode@vært:port/tinycash_test_xxx (navnet SKAL starte med
// tinycash_test, så testpakken aldrig kan ramme en rigtig database)
if (str_starts_with($tc_test_db, 'mysql://')) {
    $tc_u = parse_url($tc_test_db);
    $tc_name = ltrim((string)($tc_u['path'] ?? ''), '/');
    if (!preg_match('/^tinycash_test\w*$/', $tc_name)) die("TINYCASH_TEST_DB: MySQL-databasens navn skal starte med tinycash_test\n");
    $db_type = 'mysql';
    $db_settings = ['DB_HOST' => ($tc_u['host'] ?? '127.0.0.1') . (isset($tc_u['port']) ? ':' . $tc_u['port'] : ''), 'DB_USER' => urldecode($tc_u['user'] ?? 'root'),
                    'DB_PASS' => urldecode($tc_u['pass'] ?? ''), 'DB_NAME' => $tc_name];
}

// --- 5. DATABASE CONNECTION (DYNAMISK MOTOR) ---
if ($db_type === 'sqlite') {
    // SQLite Engine
    $db_path_rel = $db_settings['DB_PATH'] ?? 'data/tinycash.sqlite';

    // RETTET: realpath kan kun slå stien op, hvis MÅLET allerede findes. Løsning: byg mappe-stien uden om
    // realpath, opret den om nødvendigt, og brug FØRST realpath på selve mappen (som nu altid findes).
    $db_dir_rel = dirname($db_path_rel);
    $db_dir_abs = __DIR__ . '/' . $db_dir_rel;

    if (!is_dir($db_dir_abs)) {
        mkdir($db_dir_abs, 0755, true);
    }

    $db_path_abs = realpath($db_dir_abs) . '/' . basename($db_path_rel);
    if ($tc_test_db !== '') $db_path_abs = $tc_test_db;      // (testpakken - se ovenfor)

    // PHP 8.4+: PDO::connect() giver Pdo\Sqlite med createFunction(); sqliteCreateFunction() er forældet fra 8.5
    $pdo = class_exists('Pdo\Sqlite') ? PDO::connect('sqlite:' . $db_path_abs) : new PDO('sqlite:' . $db_path_abs);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // SQLite's LOWER()/LIKE kender kun A-Z - "ælling" fandt ikke "Ælling". tc_lower() er Unicode (bruges af search.php)
    $tc_lower = fn($v) => $v === null ? null : mb_strtolower((string)$v, 'UTF-8');
    if ($pdo instanceof Pdo\Sqlite) $pdo->createFunction('tc_lower', $tc_lower, 1);
    else                            $pdo->sqliteCreateFunction('tc_lower', $tc_lower, 1);

    // Global $conn skal være vores PDO objekt for at Shim virker
    $conn = $pdo;
   
} else {
    // MySQL Engine
    $db_host = $db_settings['DB_HOST'] ?? 'localhost';
    $db_user = $db_settings['DB_USER'] ?? '';
    $db_pass = $db_settings['DB_PASS'] ?? '';
    $db_name = $db_settings['DB_NAME'] ?? '';

    // RETTET: "@" undertrykker kun PHP-advarsler, ikke undtagelser - og siden PHP 8.1 er mysqli's STANDARD
    // fejltilstand netop at KASTE en mysqli_sql_exception ved en mislykket forbindelse (bekræftet direkte: PHP 8.3
    // her på maskinen). En hvilken som helst reel MySQL-forbindelsesfejl (forkert kodeord, nede server, forkert
    // vært) endte derfor som et grimt, ufanget fatal error i stedet for den pæne "MySQL forbindelse
    // fejlede:..."-besked nedenfor - denne try/catch fanger begge fejltilstande (den ældre false-retur OG den
    // nyere kastede undtagelse) ens.
    try {
        $db_port = null;      // ("vært:port" - fx testpakkens lokale MariaDB)
        if (preg_match('/^(.+):(\d+)$/', $db_host, $hp)) { $db_host = $hp[1];  $db_port = (int)$hp[2]; }
        $conn = @mysqli_connect($db_host, $db_user, $db_pass, $db_name, $db_port);
    } catch (\Throwable $e) {
        die("MySQL forbindelse fejlede: " . $e->getMessage());
    }

    if (!$conn) {
        die("MySQL forbindelse fejlede: " . mysqli_connect_error());
    }
    mysqli_set_charset($conn, "utf8mb4");
    // MySQL regner i samme tidszone som PHP: NOW() / CURRENT_TIMESTAMP og visningen af TIMESTAMP-kolonner
    @mysqli_query($conn, "SET time_zone = '" . date('P') . "'");
}

// Et tidspunkt databasen selv har skrevet (DEFAULT CURRENT_TIMESTAMP: login_log.login_time, audit_log.log_date,
// mail_log.sent_at, journal/expenses.created_at ...) - vist i lokal tid. SQLite skriver altid UTC; MySQL
// bruger allerede PHP's tidszone (SET time_zone ovenfor), så der er det uændret.
function db_ts_local($ts): string {
    $ts = (string)$ts;
    if ($ts === '' || !DB::is_sqlite()) return $ts;
    try { return (new DateTime($ts, new DateTimeZone('UTC')))->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Y-m-d H:i:s'); }
    catch (\Throwable $e) { return $ts; }
}
// Det modsatte: et lokalt tidspunkt (fx et filter "fra 2026-10-01 00:00:00") til sammenligning med sådan en kolonne
function db_ts_param(string $local): string {
    if (!DB::is_sqlite()) return $local;
    try { return (new DateTime($local))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    catch (\Throwable $e) { return $local; }
}


// RETTET (samme konsolidering som env.ini ovenfor): system_errors.log
// flyttet til inc/data/, som allerede har sit eget "Require all denied"
// (se inc/data/.htaccess) og rummer databasen i forvejen.
ini_set('log_errors', 1);
// (testpakken logger ved siden af sin testdatabase - ellers fyldte hver testkørsel den rigtige fejllog med forventede fejl)
ini_set('error_log', $tc_test_db !== '' ? sys_get_temp_dir() . '/tinycash_test_errors.log' : __DIR__ . '/data/system_errors.log');
// Loggen roteres ved 5 MB (den forrige del gemmes som .1) - ellers voksede den uden grænse på webhotellet
$tc_err_log = (string)ini_get('error_log');
if ($tc_err_log !== '' && @filesize($tc_err_log) > 5 * 1048576) @rename($tc_err_log, $tc_err_log . '.1');

// Indstillingerne hentes én gang pr. forespørgsel; enhver skrivning til settings gennem DB-klassen glemmer dem igen
// (tc_settings_touched()). setting('nøgle', standard) giver standardværdien hvis nøglen mangler eller er tom.
function get_settings($conn) {
    if (isset($GLOBALS['tc_settings_cache'])) return $GLOBALS['tc_settings_cache'];
    $settings = [];
    $sql = "SELECT setting_key, setting_value FROM settings";
    $res = DB::query($conn, $sql);
    if ($res) {
        while ($row = DB::fetch_assoc($res)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        // Brug DB-klassens metode i stedet for mysqli_free_result
        DB::free_result($res); 
        $GLOBALS['tc_settings_cache'] = $settings;      // (kun ved en vellykket læsning)
    }
    return $settings;
}
function setting(string $key, $default = '') {
    global $conn;
    $v = get_settings($conn)[$key] ?? null;
    return ($v === null || $v === '') ? $default : $v;
}
function tc_settings_forget(): void {
    unset($GLOBALS['tc_settings_cache']);
}
function tc_settings_touched($sql): void {
    if (isset($GLOBALS['tc_settings_cache']) && preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE)\b[\s\S]*\bsettings\b/i', (string)$sql)) tc_settings_forget();
}

require_once __DIR__ . '/country.inc.php';      // landepakken (talformat, momssats, ...) - læses først når den bruges

// --- 6. INDSTILLINGER  ---
$global_settings = get_settings($conn);
$current_date_format = (!empty($global_settings['date_format'])) ? $global_settings['date_format'] : 'd.m.Y';
define('CONF_DATE_FORMAT', $current_date_format);
// Tidszonen pr. regnskab (Firmaindstillinger); ellers TIMEZONE i env.ini, ellers landepakkens
$tc_tz_set = trim((string)($global_settings['timezone'] ?? ''));
if ($tc_tz_set === '' && trim((string)($config['TIMEZONE'] ?? '')) === '') $tc_tz_set = (string)tc_country_pack('timezone', '');
if ($tc_tz_set !== '' && $tc_tz_set !== date_default_timezone_get() && in_array($tc_tz_set, timezone_identifiers_list(), true)) date_default_timezone_set($tc_tz_set);

// SPROG-LOGIK ER FJERNET HERFRA. STYRES UDELUKKENDE AF AUTH.INC.PHP.

// Fortolker et beløb/antal skrevet af en bruger, uanset om det er skrevet med dansk (komma-decimal, evt.
// punktum-tusindtalsseparator, fx "1.500,00") eller engelsk/HTML5-number-notation (punktum-decimal, fx "1500.00"
// eller "1500").
// BAGGRUND: en tidligere rettelse erstattede blot komma med punktum (str_replace(',', '.', $s)) på en række
// beløbsfelter i hele projektet. Det retter "199,95" -> "199.95" korrekt, MEN gør det værre for et beløb der ER
// hævet til noget større og skrevet med fuld dansk tusindtals-formatering: "1.500,00" bliver til "1.500.00" (TO
// punktummer), og PHPs (float)-cast stopper simpelthen ved det FØRSTE ekstra punktum og returnerer 1.5 - altså et
// beløb der lige er hævet til 1500 kr endte som 1,50 kr efter gem.
function parse_dk_number($s): float {
    // RETTET: mellemrum (også hårdt mellemrum) som tusindtalsseparator - "1 234,50" fra et bankudtræk blev 1 kr
    $s = str_replace([' ', "\u{00A0}", "\u{202F}", "'"], '', trim((string)$s));
    if ($s === '') return 0.0;
    // RETTET: samme tegn flere gange kan kun være tusindtalsseparatoren - "1.234.567" blev 1,234 og "1,234,567" 1,234
    if (substr_count($s, '.') > 1) $s = str_replace('.', '', $s);
    if (substr_count($s, ',') > 1) $s = str_replace(',', '', $s);
    $has_comma = strpos($s, ',') !== false;
    $has_dot   = strpos($s, '.') !== false;
    if ($has_comma && $has_dot) {
        // Begge tegn til stede - det der optræder SIDST er decimal-tegnet,
        // det andet er en tusindtalsseparator og fjernes.
        if (strrpos($s, ',') > strrpos($s, '.')) {
            $s = str_replace('.', '', $s);   // punktum var tusindtalsseparator
            $s = str_replace(',', '.', $s);  // komma er decimal-tegnet
        } else {
            $s = str_replace(',', '', $s);   // komma var tusindtalsseparator (fx "1,500.00")
        }
    } elseif ($has_comma) {
        // Kun komma til stede: decimaltegnet i lande med komma-decimal (Danmark), ellers tusindtalsseparatoren
        $s = tc_num_sep()[0] === '.' ? str_replace(',', '', $s) : str_replace(',', '.', $s);
    }
    // Kun punktum (eller intet separator-tegn) til stede: allerede gyldig
    // float-syntaks (matcher hvad en native <input type="number"> selv ville
    // sende), rør ikke ved den.
    return (float)$s;
}

// RETTET: flere bogføringssider kontrollerede kun datoens FORMAT (åååå-mm-dd) - "2026-02-31" slap igennem og blev
// bogført med en dato der ikke findes (SQLite's datofunktioner giver NULL for den, og strtotime() gør den stille
// til 3. marts). En gyldig kalenderdato i formatet åååå-mm-dd.
function tc_is_date($d): bool {
    $d = (string)$d;
    return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4));
}

// KONTROL AF INDTASTNINGER - fælles for alle formularer (i stedet for hver sin håndskrevne grænse).
// tc_num(): et gyldigt tal (dansk "1.234,56" eller "1234.56") inden for grænserne, ellers null. Tomt felt = null.
// parse_dk_number() alene gør "abc" til 0 og "250" til 250 - den afgør ikke om værdien er gyldig.
function tc_num($raw, ?float $min = null, ?float $max = null): ?float {
    $s = trim((string)$raw);
    if ($s === '' || !preg_match('/^[-+]?[0-9.,][0-9.,\s\x{00A0}\x{202F}\']*$/u', $s) || !preg_match('/[0-9]/', $s)) return null;
    $n = parse_dk_number($s);
    if (!is_finite($n) || ($min !== null && $n < $min) || ($max !== null && $n > $max)) return null;
    return $n;
}
// En procent (momssats, rabat): 0-100
function tc_pct($raw): ?float {
    return tc_num($raw, 0, 100);
}
// EAN-/GLN-lokationsnummer (13 cifre med GS1-kontrolciffer, fx en offentlig myndigheds e-faktura-adresse).
// Returnerer de 13 cifre, '' for tomt, null for ugyldigt.
function tc_ean($raw): ?string {
    $d = preg_replace('/[\s-]/', '', (string)$raw);
    if ($d === '') return '';
    if (!preg_match('/^\d{13}$/', $d)) return null;
    $sum = 0;
    for ($i = 0; $i < 12; $i++) $sum += (int)$d[$i] * ($i % 2 ? 3 : 1);
    return (10 - $sum % 10) % 10 === (int)$d[12] ? $d : null;
}
// Findes kontoen i kontoplanen? (en konto der er slået fra, findes stadig - den må bare ikke vælges i nye bilag)
// Resultatet før $date, der ikke er lukket ind på egenkapitalen (resultatkontienes samlede saldo før datoen, uden
// årsafslutning har den ikke været 0), og egenkapitalkontoen det hører til (den laveste) - til SAF-T-primo. [beløb, konto|0]
function saft_prior_result($conn, string $date): array {
    $d = DB::escape($conn, $date);
    $r = DB::fetch_row(DB::query($conn, "SELECT COALESCE(SUM(l.amount), 0) FROM ledger l JOIN journal j ON j.jou_id = l.jou_id JOIN accounts a ON a.acc_id = l.acc_id
                                       WHERE a.acc_type IN ('income', 'expense') AND j.jou_date < '$d'"));
    $prior = round((float)($r[0] ?? 0), 2);
    if (abs($prior) < 0.005) return [0.0, 0];
    $eq = DB::fetch_row(DB::query($conn, "SELECT MIN(acc_id) FROM accounts WHERE acc_type = 'equity'"));
    return [$prior, (int)($eq[0] ?? 0)];
}

function tc_account_ok($conn, $acc_id): bool {
    $acc_id = (int)$acc_id;
    return $acc_id > 0 && (bool)DB::fetch_assoc(DB::query($conn, "SELECT acc_id FROM accounts WHERE acc_id = $acc_id"));
}
// Et aktivt projekt (eller $keep_id: det projekt posten allerede har, selv om det er afsluttet). 0 = intet projekt = ok.
function tc_project_ok($conn, $proj_id, int $keep_id = 0): bool {
    $proj_id = (int)$proj_id;
    return $proj_id <= 0 || (bool)DB::fetch_assoc(DB::query($conn, "SELECT proj_id FROM projects WHERE proj_id = $proj_id AND (is_active = 1 OR proj_id = $keep_id)"));
}
// En kunde der findes og ikke ligger i papirkurven (eller $keep_id: den kunde posten allerede har)
function tc_customer_ok($conn, $cust_id, int $keep_id = 0): bool {
    $cust_id = (int)$cust_id;
    if ($cust_id <= 0) return false;
    $trash = db_has_column($conn, 'customers', 'deleted_at') ? " AND (deleted_at IS NULL OR cust_id = $keep_id)" : '';
    return (bool)DB::fetch_assoc(DB::query($conn, "SELECT cust_id FROM customers WHERE cust_id = $cust_id$trash"));
}

// Fakturastatus som tekst på brugerens sprog. Status gemmes som et lille engelsk ord (draft/sent/paid/credit/
// credited); lang('@' . strtoupper($s)) fandt kun @DRAFT, så listen viste "KLADDE" ved siden af SENT/PAID, og
// lang('@' . ucfirst('credit')) gav bogføringsordet "Kredit" i stedet for "Kreditnota".
function tc_invoice_status_label(?string $status): string {
    $keys = ['draft' => '@Draft', 'sent' => '@Sent', 'paid' => '@Paid', 'credit' => '@Credit Note',
             'credited' => '@Credited', 'cancelled' => '@Cancelled'];
    $s = strtolower(trim((string)$status));
    return isset($keys[$s]) ? lang($keys[$s]) : htmlspecialchars(ucfirst($s));
}

// Et kort fingeraftryk af en brugers kodeords-hash (gemt i sessionen ved login; ændres kodeordet, passer det ikke længere)
function tc_pw_fingerprint(string $hash): string { return $hash === '' ? '' : substr(hash('sha256', $hash), 0, 16); }

// Regnskabsåret (fiscal_years) der indeholder $date - ellers kalenderåret. [start, slut]. Rapporternes standardperiode:
// date('Y-01-01') var forkert for et forskudt regnskabsår (fx 1/7-30/6)
function tc_fiscal_year_bounds($conn, ?string $date = null): array {
    $date = $date ?? date('Y-m-d');
    if (db_has_table($conn, 'fiscal_years')) {
        $d = DB::escape($conn, $date);
        $r = DB::fetch_assoc(DB::query($conn, "SELECT start_date, end_date FROM fiscal_years WHERE start_date <= '$d' AND end_date >= '$d' ORDER BY start_date DESC LIMIT 1"));
        if ($r && tc_is_date((string)$r['start_date'])) return [(string)$r['start_date'], (string)$r['end_date']];
        // Ikke oprettet endnu (det nye år oprettes først ved lukningen af det gamle): det nærmeste kendte regnskabsår
        // forskudt hele år - ellers blev 1/7-31/12 i et forskudt år regnet som en del af kalenderåret
        if ($fy = tc_fiscal_year_extrapolate($conn, $date)) return $fy;
    }
    return [substr($date, 0, 4) . '-01-01', substr($date, 0, 4) . '-12-31'];
}
// Det regnskabsår der indeholder $date, udledt af det nærmeste oprettede år (samme start-dag, hele år frem/tilbage), eller null
function tc_fiscal_year_extrapolate($conn, string $date): ?array {
    $d = DB::escape($conn, $date);
    $r = DB::fetch_assoc(DB::query($conn, "SELECT start_date FROM fiscal_years WHERE start_date <= '$d' ORDER BY start_date DESC LIMIT 1"))
      ?: DB::fetch_assoc(DB::query($conn, "SELECT start_date FROM fiscal_years ORDER BY start_date ASC LIMIT 1"));
    $s = substr((string)($r['start_date'] ?? ''), 0, 10);
    if (!tc_is_date($s) || substr($s, 5) === '01-01') return null;      // (et kalenderår giver samme svar som standarden)
    $y = (int)substr($date, 0, 4);
    $start = $y . substr($s, 4);
    if ($start > $date) $start = ($y - 1) . substr($s, 4);
    if (!tc_is_date($start)) return null;      // (29/2 som startdag)
    return [$start, date('Y-m-d', strtotime("$start +1 year -1 day"))];
}
// Regnskabsåret "$year" = det regnskabsår der slutter i $year (1/7/2025-30/6/2026 er 2026); ellers kalenderåret
function tc_fiscal_year_of($conn, int $year): array {
    if (db_has_table($conn, 'fiscal_years')) {
        $r = DB::fetch_assoc(DB::query($conn, "SELECT start_date, end_date FROM fiscal_years WHERE end_date >= '$year-01-01' AND end_date <= '$year-12-31' ORDER BY end_date DESC LIMIT 1"));
        if ($r && tc_is_date((string)$r['start_date']) && tc_is_date((string)$r['end_date'])) return [(string)$r['start_date'], (string)$r['end_date']];
        // (ikke oprettet endnu: regnskabsåret der slutter i $year, udledt af de oprettede år)
        if ($fy = tc_fiscal_year_extrapolate($conn, "$year-12-31")) {
            if ((int)substr($fy[1], 0, 4) === $year) return $fy;
            if ($fy2 = tc_fiscal_year_extrapolate($conn, ($year - 1) . "-12-31")) if ((int)substr($fy2[1], 0, 4) === $year) return $fy2;
        }
    }
    return ["$year-01-01", "$year-12-31"];
}

// Tal i landets format (landepakkens number.dec/thou - i Danmark 1.234,56). fmt_dk(): til visning.
// fmt_dk_input(): til et inputfelt eller en CSV-celle, uden tusindtalsseparator (1234,56) - læses igen af
// parse_dk_number() og af landets Excel. Maskinformat (OIOUBL/XML, 1234.56) er stadig number_format($n, 2, '.', '').
function fmt_dk($n, int $dec = 2): string {
    [$d, $t] = tc_num_sep();
    return number_format((float)$n, $dec, $d, $t);
}
// En sats/procent uden overflødige nuller: 25 -> "25", 12.5 -> "12,5". (fmt_dk($rate, 0) viste 12,5 % som "13 %")
function fmt_pct($n): string {
    return rtrim(rtrim(fmt_dk($n, 2), '0'), tc_num_sep()[0]);
}
function fmt_dk_input($n, int $dec = 2): string {
    return number_format((float)$n, $dec, tc_num_sep()[0], '');
}

// Findes tabellen/kolonnen (er migrationen kørt)? Begge motorer, uden fejl hvis tabellen mangler. Kolonnelisten
// huskes pr. forespørgsel - en side der selv ændrer en tabel undervejs, kalder db_schema_forget($table) bagefter.
function db_table_columns($conn, string $table): array {
    $cache = &$GLOBALS['tc_schema_cache'];
    $key = strtolower($table);
    if (isset($cache[$key])) return $cache[$key];
    $cols = [];
    if (preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        $res = DB::is_sqlite()
            ? @DB::query($conn, "PRAGMA table_info($table)")
            : @DB::query($conn, "SELECT COLUMN_NAME AS name FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table'");
        if ($res) while ($row = DB::fetch_assoc($res)) $cols[] = strtolower((string)($row['name'] ?? $row['NAME'] ?? ''));
    }
    return $cache[$key] = $cols;
}
function db_has_table($conn, string $table): bool {
    return db_table_columns($conn, $table) !== [];
}
function db_has_column($conn, string $table, string $column): bool {
    return in_array(strtolower($column), db_table_columns($conn, $table), true);
}
function db_schema_forget(?string $table = null): void {
    if ($table === null) $GLOBALS['tc_schema_cache'] = [];
    else unset($GLOBALS['tc_schema_cache'][strtolower($table)]);
}

// Oversætter en bruger-rolle (users.user_role - "admin"/"accountant"/"user", valgt i
// user_create.php/user_edit.php's "Rolle"-dropdown) til det numeriske adgangsniveau (users.user_level, 1-3), som
// ALT sidespecifikt $rLev-tjek i inc/auth.inc.php reelt gatekeeper på - IKKE user_role direkte.
// BAGGRUND: user_role og user_level er to helt uafhængige kolonner i users-tabellen, og INTET sted i koden har
// nogensinde holdt dem synkroniseret - hverken user_create.php (INSERT satte kun user_role, user_level faldt til
// kolonnens standard på 1) eller user_edit.php (UPDATE satte også kun user_role, rørte aldrig user_level på en
// eksisterende bruger). Den ENESTE konto der nogensinde har fået begge sat korrekt er bootstrap-adminkontoen fra
// init_demo_data.php, som sætter dem direkte i et enkelt DB::insert-kald - derfor er dette hul aldrig blevet
// opdaget af nogen af denne sessions mange adgangskontrol-tests, som alle brugte netop den konto.
function role_to_level(string $role): int {
    return ['admin' => 3, 'accountant' => 2, 'user' => 1][$role] ?? 1;
}

// Momskontoen $acc + de konti den har AFLØST ved et skift til standardkontoplanen (slukket, std_ref_id = $acc) -
// som SQL-liste til "l.acc_id IN (...)". Efter et skift midt i en periode manglede momsen der var bogført på den
// gamle konto før skiftet, og skiftets saldooverførsel blev talt med som årets moms på den nye konto.
function tc_vat_acc_list($conn, int $acc): string {
    static $has_status = null;
    if ($has_status === null) {
        if (DB::is_sqlite()) {
            $has_status = false;
            $c = DB::query($conn, "PRAGMA table_info(accounts)");
            if ($c) while ($x = DB::fetch_assoc($c)) if ($x['name'] === 'acc_status') $has_status = true;
        } else {
            $c = DB::query($conn, "SHOW COLUMNS FROM accounts LIKE 'acc_status'");
            $has_status = $c && DB::num_rows($c) > 0;
        }
    }
    $ids = [$acc];
    $st  = $has_status ? " AND acc_status = 'off'" : '';
    $res = DB::query($conn, "SELECT acc_id FROM accounts WHERE std_ref_id = $acc AND acc_id <> $acc$st");
    if ($res) while ($r = DB::fetch_row($res)) $ids[] = (int)$r[0];
    return implode(',', array_unique($ids));
}

// Den konto en bogføringsrolle (conf_acc_*) reelt bruger, hvis den findes i kontoplanen - ellers 0. Til de gamle
// "opret konto NNNN"-migreringer: efter en kontoplan fra setup_chart.php eller et skift til standardkontoplanen er
// rollen dækket af en anden konto, og den faste konto må ikke oprettes oven i (3000 er fx et standardnummer).
function tc_role_account($conn, string $key, int $default): int {
    $v = get_settings($conn)[$key] ?? '';
    $acc = (int)($v !== '' ? $v : $default);
    return ($acc > 0 && DB::fetch_assoc(DB::query($conn, "SELECT acc_id FROM accounts WHERE acc_id = $acc"))) ? $acc : 0;
}
// Første egenkapitalkonto i kontoplanen (årsafslutningen) - 0 hvis ingen
function tc_equity_account($conn): int {
    $r = DB::fetch_row(DB::query($conn, "SELECT MIN(acc_id) FROM accounts WHERE acc_type = 'equity'"));
    return (int)($r[0] ?? 0);
}

// Erstat din nuværende is_date_locked med denne mere robuste version
// Antal hele kalenderdage fra $from til $to (negativt hvis $to ligger før) - kun datodelen tæller.
// RETTET: "(int)((strtotime($to) - strtotime($from)) / 86400)" gav én dag for lidt hen over skiftet til
// sommertid (døgnet er kun 23 timer: 28/3 -> 30/3 2026 blev 1 dag) - en faktura blev "forfalden" en dag for
// sent i rykkerlisten og restancelisten, og dagstællerne på forsiden og i listerne var forkerte.
function days_between($from, $to): int {
    $f = DateTime::createFromFormat('!Y-m-d', substr((string)$from, 0, 10));
    $t = DateTime::createFromFormat('!Y-m-d', substr((string)$to, 0, 10));
    if (!$f || !$t) return 0;
    return (int)$f->diff($t)->format('%r%a');
}

function is_date_locked($conn, $date) {
    $sql = "SELECT setting_value FROM settings WHERE setting_key = 'accounting_lock_date' LIMIT 1";
    
    // Brug din egen wrapper
    $stmt = DB::prepare($conn, $sql);
    
    if ($stmt) {
        if (DB::is_sqlite()) {
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($res);
        }
        
        if ($row) {
            $lock_date = $row['setting_value'];
            if (!empty($lock_date) && strtotime($date) <= strtotime($lock_date)) {
                return true;
            }
        }
    }
    return false;
}

/* ==========================================================================
   RETTET: DB::num_rows() på SQLite returnerede ALTID 1 (sandt), så snart
   forespørgslen bare lykkedes - uanset om der reelt var 0 eller flere
   matchende rækker. Det gjorde fx "findes brugernavnet allerede?"-tjek i
   user_create.php altid sandt, selv for helt nye, ledige brugernavne.

   Årsagen: PDO (som SQLite bruger) har ingen pålidelig "tæl rækker uden at
   forbruge dem"-funktion for SELECT, i modsætning til MySQLi, som som
   standard bufrer hele resultatet med det samme (så num_rows() OG en
   efterfølgende fetch_assoc() begge virker på samme resultat). Det er netop
   dette MySQLi-mønster - num_rows() efterfulgt af fetch_assoc() på samme
   variabel - som bruges 14+ steder i projektet.

   Løsningen er denne lille wrapper-klasse: for SQLite SELECT-forespørgsler
   hentes ALLE rækker øjeblikkeligt ind i et PHP-array (ligesom MySQLi gør
   internt), så både optælling og efterfølgende, gentagen rækkehentning
   virker korrekt - uden at ændre opførslen for MySQL-installationer eller
   for ikke-SELECT-forespørgsler (INSERT/UPDATE/DELETE) på SQLite.
   ========================================================================== */
class SQLiteBufferedResult {
    private $rows;
    private $pointer = 0;
    private $count;

    public function __construct(array $rows) {
        $this->rows = $rows;
        $this->count = count($rows);
    }

    public function fetch($mode = 'assoc') {
        if ($this->pointer >= $this->count) return false;
        $row = $this->rows[$this->pointer];
        $this->pointer++;
        if ($mode === 'num') {
            return array_values($row);
        } elseif ($mode === 'both') {
            return array_merge($row, array_values($row));
        }
        return $row; // 'assoc'
    }

    public function numRows() {
        return $this->count;
    }
}

class DB {
    public static function is_sqlite() {
        global $db_type;
        return ($db_type === 'sqlite');
    }
    public static function query($conn, $sql) {
        global $pdo, $db_type;
        // En strukturændring gør den huskede kolonneliste (db_table_columns()) forældet
        if (preg_match('/^\s*(ALTER|CREATE|DROP|RENAME)\s+TABLE/i', (string)$sql)) $GLOBALS['tc_schema_cache'] = [];
        tc_settings_touched($sql);
        try {
            if ($db_type === 'sqlite') {
                $stmt = $pdo->query($sql);
                if ($stmt === false) return false;
                // Kun SELECT-forespørgsler bufres til et array (se klassen
                // ovenfor) - INSERT/UPDATE/DELETE returnerer stadig det rå
                // PDOStatement-objekt som hidtil, uændret opførsel.
                if (preg_match('/^\s*SELECT/i', $sql)) {
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    return new SQLiteBufferedResult($rows);
                }
                return $stmt;
            } else {
                self::$stmt_affected = null;
                return mysqli_query($conn, $sql);
            }
        } catch (Exception $e) {
            // Vi returnerer false, men vi logger fejlen, så du kan se den i logfilen
            error_log("DB Query Suppressed Error: " . $e->getMessage() . " | SQL: " . $sql);
            return false;
        }
    }
    // Tilføj denne metode inde i din DB klasse i inc/db_connect.inc.php
    public static function error($conn) {
        global $db_type, $pdo;
        if ($db_type === 'sqlite') {
            return $pdo->errorInfo()[2] ?? 'Unknown SQLite error';
        } else {
            return mysqli_error($conn);
        }
    }
    // fetch_assoc/fetch_row/num_rows/free_result tjekkede FØR ikke om $result
    // overhovedet var et gyldigt resultat, før de kaldte ->fetch()/mysqli_*()
    // på det. En fejlet DB::query() (fx pga. en manglende tabel/kolonne -
    // typisk på en installation hvor create_all_tables.php/migrationer ikke
    // er kørt) returnerer false, og false->fetch() er et PHP fatal error
    // ("Call to a member function fetch() on bool") i stedet for en pæn
    // fejl. Ramte reelt en bruger på en anden installation (invoice_view.php
    // via layout_settings). Guard tilføjet alle fire steder.
    public static function fetch_assoc($result) {
        global $db_type;
        if ($result === false || $result === null || $result === true) return false;      // (true = en skrivning uden resultatsæt)
        if ($result instanceof SQLiteBufferedResult) return $result->fetch('assoc');
        return ($db_type === 'sqlite') ? $result->fetch(PDO::FETCH_ASSOC) : mysqli_fetch_assoc($result);
    }
    public static function fetch_row($result) {
        global $db_type;
        if ($result === false || $result === null || $result === true) return false;      // (true = en skrivning uden resultatsæt)
        if ($result instanceof SQLiteBufferedResult) return $result->fetch('num');
        return ($db_type === 'sqlite') ? $result->fetch(PDO::FETCH_NUM) : mysqli_fetch_row($result);
    }
    // Denne metode er den, der fejler lige nu. Sørg for den står præcis sådan her:
    public static function free_result($result) {
        global $db_type;
        if ($result === false || $result === null) return;
        if ($result instanceof SQLiteBufferedResult) return; // rent PHP-array, intet at frigøre
        if ($db_type !== 'sqlite') {
            mysqli_free_result($result);
        }
        // Hvis det er sqlite, gør vi ingenting (derfor fejler den ikke)
    }
    public static function insert($conn, $table, $data) {
            global $db_type;
            if ($table === 'settings') tc_settings_forget();
            self::$stmt_affected = null;
            $keys = array_keys($data);
            $fields = implode(", ", $keys);
            // Lav pladsholdere: SQLite/PDO bruger '?', MySQLi bruger '?' (hvis vi bruger prepared statements)
            $placeholders = implode(", ", array_fill(0, count($data), "?"));
            $sql = "INSERT INTO $table ($fields) VALUES ($placeholders)";
            if ($db_type === 'sqlite') {
                global $pdo;
                $stmt = $pdo->prepare($sql);
                return $stmt->execute(array_values($data));
            } else {
                $stmt = mysqli_prepare($conn, $sql);
                if (!$stmt) return false;
                // Generer types-string (f.eks. "sss" for 3 strenge)
                $types = str_repeat("s", count($data));
                mysqli_stmt_bind_param($stmt, $types, ...array_values($data));
                return mysqli_stmt_execute($stmt);
            }
        }
    // Denne metode gør, at du kan bruge samme kode til både MySQL og SQLite
    public static function prepare_and_execute($conn, $sql, $params = []) {
        global $pdo, $db_type;
        tc_settings_touched($sql);
        if ($db_type === 'sqlite') {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } else {
            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) return false;
            // Her forenkler vi: Vi antager kun strenge for nu, eller du kan udvide
            $types = str_repeat("s", count($params));
            if ($params) mysqli_stmt_bind_param($stmt, $types, ...$params);
            if (!mysqli_stmt_execute($stmt)) return false;
            // En UPDATE/DELETE/INSERT har intet resultatsæt - mysqli_stmt_get_result() giver da false, også når den lykkedes.
            // Alle "claim"-mønstre (if (!$claim || DB::affected_rows(...) < 1)) fejlede derfor altid på MySQL: en udgift
            // kunne ikke betales, et tilbud ikke skifte status osv. Som på SQLite: noget sandt ved succes.
            // (antallet tages fra statementet - mysqli_affected_rows($conn) giver -1 efter et prepared statement på PHP 8.5)
            self::$stmt_affected = (int)mysqli_stmt_affected_rows($stmt);
            $res = mysqli_stmt_get_result($stmt);
            return ($res === false && mysqli_stmt_errno($stmt) === 0) ? true : $res;
        }
    }
    public static function num_rows($result) {
        global $db_type;
        if ($result === false || $result === null || $result === true) return 0;
        if ($result instanceof SQLiteBufferedResult) return $result->numRows();
        if ($db_type === 'sqlite') {
            // Fallback for evt. resultater der ikke gik gennem DB::query()
            // (fx et rå PDOStatement fra prepare_and_execute) - dette bør
            // normalt ikke ramme SELECT-tilfælde længere, jf. rettelsen ovenfor.
            return ($result) ? 1 : 0;
        } else {
            return mysqli_num_rows($result);
        }
    }
    // NYT: Transaktionsstøtte - kræves af expense_actions.php (og ethvert andet sted, der skal garantere flere
    // sammenhørende opdateringer enten lykkes helt eller fortrydes helt, fx annullering af en bogført udgift +
    // synkronisering af journalen i samme operation).
    // Indlejring: en bogføringsfunktion kan selv starte en transaktion, også når kalderen allerede har en - den inderste
    // bliver et SAVEPOINT (begge motorer), så den kan rulles tilbage alene, og kun den yderste committer rigtigt.
    private static int $tx_depth = 0;
    public static function begin_transaction($conn) {
        global $pdo, $db_type;
        if (self::$tx_depth > 0) {
            self::exec_raw($conn, 'SAVEPOINT tc_sp' . self::$tx_depth);
            self::$tx_depth++;
            return true;
        }
        $ok = ($db_type === 'sqlite') ? $pdo->beginTransaction() : mysqli_begin_transaction($conn);
        if ($ok) self::$tx_depth = 1;
        return $ok;
    }
    public static function commit($conn) {
        global $pdo, $db_type;
        if (self::$tx_depth > 1) {
            self::$tx_depth--;
            self::exec_raw($conn, 'RELEASE SAVEPOINT tc_sp' . self::$tx_depth);
            return true;
        }
        self::$tx_depth = 0;
        return ($db_type === 'sqlite') ? $pdo->commit() : mysqli_commit($conn);
    }
    public static function rollback($conn) {
        global $pdo, $db_type;
        if (self::$tx_depth > 1) {
            self::$tx_depth--;
            self::exec_raw($conn, 'ROLLBACK TO SAVEPOINT tc_sp' . self::$tx_depth);
            self::exec_raw($conn, 'RELEASE SAVEPOINT tc_sp' . self::$tx_depth);
            return true;
        }
        self::$tx_depth = 0;
        if ($db_type === 'sqlite') return $pdo->inTransaction() ? $pdo->rollBack() : false;
        return mysqli_rollback($conn);
    }
    public static function in_transaction(): bool {
        return self::$tx_depth > 0;
    }
    // Kører $fn i en transaktion (indlejret = savepoint): alt eller intet. Returnerer $fn's værdi; en fejl ruller tilbage og
    // kastes videre. Brug den i enhver funktion der skriver et bilag (journal + ledger + evt. følgetabeller).
    public static function transaction($conn, callable $fn) {
        self::begin_transaction($conn);
        try {
            $result = $fn();
            self::commit($conn);
            return $result;
        } catch (\Throwable $e) {
            self::rollback($conn);
            throw $e;
        }
    }
    private static function exec_raw($conn, string $sql): void {
        global $pdo, $db_type;
        if ($db_type === 'sqlite') $pdo->exec($sql); else mysqli_query($conn, $sql);
    }
    public static function prepare($conn, $sql) {
        global $pdo, $db_type;
        tc_settings_touched($sql);
        return ($db_type === 'sqlite') ? $pdo->prepare($sql) : mysqli_prepare($conn, $sql);
    }
    public static function fetch_array($result) {
        global $db_type;
        if ($result instanceof SQLiteBufferedResult) return $result->fetch('both');
        return ($db_type === 'sqlite') ? $result->fetch(PDO::FETCH_BOTH) : mysqli_fetch_array($result);
    }
    public static function update($conn, $table, $data, $where_field, $where_value) {
        global $db_type;
        if ($table === 'settings') tc_settings_forget();
        self::$stmt_affected = null;
        $fields = "";
        foreach (array_keys($data) as $key) {
            $fields .= "$key = ?, ";
        }
        $fields = rtrim($fields, ", ");
        $sql = "UPDATE $table SET $fields WHERE $where_field = ?";
        $params = array_values($data);
        $params[] = $where_value; // Tilføj WHERE-værdien til sidst
        if ($db_type === 'sqlite') {
            global $pdo;
            $stmt = $pdo->prepare($sql);
            return $stmt->execute($params);
        } else {
            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) return false;
            $types = str_repeat("s", count($params));
            mysqli_stmt_bind_param($stmt, $types, ...$params);
            return mysqli_stmt_execute($stmt);
        }
    }
    public static function dump_to_sql($conn) {
        global $db_type, $pdo;
        $sqlDump = "-- TinyCash System Dump - Type: $db_type - Date: " . date('Y-m-d H:i:s') . "\n\n";
        if ($db_type === 'sqlite') {
            $res = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
            foreach ($res as $row) {
                $table = $row['name'];
                $createRes = $pdo->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='$table'");
                $create = $createRes->fetch();
                $sqlDump .= $create['sql'] . ";\n";
                $data = $pdo->query("SELECT * FROM \"$table\"");
                $data->setFetchMode(PDO::FETCH_ASSOC);
                foreach ($data as $item) {
                    // Nu indeholder $item kun kolonnenavne, og array_values() vil kun returnere data én gang
                    $vals = array_map(function($v) {
                        return is_null($v) ? 'NULL' : '"' . str_replace('"', '""', $v) . '"';
                    }, array_values($item));
                    $sqlDump .= "INSERT INTO \"$table\" VALUES (" . implode(", ", $vals) . ");\n";
                }
                $sqlDump .= "\n";
            }
            // Triggere (fx den append-only-beskyttelse migrate_append_only_ledger.php
            // opretter på journal/ledger) manglede FØR helt i dumpet - en gendannelse
            // (backup_restore_worker.php: DROP TABLE + reimport) ville derfor stille
            // fjerne beskyttelsen igen, selvom selve tabellerne kom tilbage korrekt.
            // Fundet ved samme arbejde som selve append-only-triggerne blev tilføjet.
            // Indeksene manglede også - efter en gendannelse var bl.a. de unikke indeks væk (webbutikkens ordre-id, så en
            // genfremsendt ordre blev bogført to gange, og varenummeret). (sql er NULL for SQLite's egne autoindeks.)
            $idxRes = $pdo->query("SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%'");
            foreach ($idxRes as $idx) $sqlDump .= $idx['sql'] . ";\n";
            $trigRes = $pdo->query("SELECT sql FROM sqlite_master WHERE type='trigger'");
            foreach ($trigRes as $trig) {
                if (!empty($trig['sql'])) $sqlDump .= $trig['sql'] . ";\n";
            }
        } else {
            $res = mysqli_query($conn, "SHOW TABLES");
            while ($row = mysqli_fetch_row($res)) {
                $table = $row[0];
                $createRes = mysqli_query($conn, "SHOW CREATE TABLE `$table`");
                $create = mysqli_fetch_row($createRes);
                $sqlDump .= "\n" . $create[1] . ";\n";
                $data = mysqli_query($conn, "SELECT * FROM `$table`");
                while ($item = mysqli_fetch_assoc($data)) {
                    $vals = array_map(function($v) use ($conn) { return is_null($v) ? 'NULL' : '"' . mysqli_real_escape_string($conn, $v) . '"'; }, array_values($item));
                    $sqlDump .= "INSERT INTO `$table` VALUES(" . implode(",", $vals) . ");\n";
                }
            }
            // Samme begrundelse som SQLite-grenen ovenfor - triggere manglede FØR i dumpet.
            $trigRes = mysqli_query($conn, "SHOW TRIGGERS");
            if ($trigRes) {
                while ($trig = mysqli_fetch_assoc($trigRes)) {
                    $createTrig = mysqli_query($conn, "SHOW CREATE TRIGGER `" . $trig['Trigger'] . "`");
                    if ($createTrig) {
                        $ct = mysqli_fetch_assoc($createTrig);
                        if (!empty($ct['SQL Original Statement'])) $sqlDump .= "\n" . $ct['SQL Original Statement'] . ";\n";
                    }
                }
            }
        }
        return $sqlDump;
    }
    // Kun DB-STRUKTUR (CREATE TABLE m.m.), ingen data. Bruges af program-backup,
    // hvor det er skemaet - ikke regnskabsdataene - der skal kunne rulles tilbage
    // sammen med koden. Cross-engine som dump_to_sql().
    public static function dump_schema($conn) {
        global $db_type, $pdo;
        $out = "-- TinyCash Schema (structure only) - Type: $db_type - Date: " . date('Y-m-d H:i:s') . "\n\n";
        if ($db_type === 'sqlite') {
            $res = $pdo->query("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 1 WHEN 'index' THEN 2 ELSE 3 END");
            foreach ($res as $row) {
                $out .= $row['sql'] . ";\n";
            }
        } else {
            $res = mysqli_query($conn, "SHOW TABLES");
            while ($row = mysqli_fetch_row($res)) {
                $table   = $row[0];
                $created = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE `$table`"));
                $out .= "\n" . $created[1] . ";\n";
            }
        }
        return $out;
    }
    // Tilføj denne til din DB klasse i inc/db_connect.inc.php
    public static function escape($conn, $string) {
        global $db_type, $pdo;
        if ($db_type === 'sqlite') {
            return str_replace("'", "''", $string); // SQLite escape
        } else {
            return mysqli_real_escape_string($conn, $string); // MySQLi escape
        }
    }
    // Alias for escape(): mange kaldesteder (expense_edit, bank_import, vat_save,
    // auto_backup m.fl.) bruger MySQLi-navnet real_escape_string(). Uden dette gav
    // de "Call to undefined method DB::real_escape_string()". Håndterer både
    // MySQL og SQLite via escape().
    public static function real_escape_string($conn, $string) {
        return self::escape($conn, $string);
    }
    // Tilføj denne til din DB klasse i inc/db_connect.inc.php
    public static function insert_id($conn) {
        global $db_type, $pdo;
        if ($db_type === 'sqlite') {
            return $pdo->lastInsertId();
        } else {
            return mysqli_insert_id($conn);
        }
    }
    // RETTET: manglede helt. Flere steder i koden afgør et kapløbsforsøg ("blev DENNE forespørgsel den der skrev,
    // eller nåede en anden forespørgsel det først?") ved bagefter at SELECT'e og se om den ønskede sluttilstand er
    // opnået - men det tjekker kun OM tilstanden er korrekt, ikke HVEM der satte den. WHERE <forventet gammel
    // tilstand>", selvom kun ét af dem reelt ændrede rækken - taberen så bare vinderens allerede-committede
    // resultat, og ville derfor fejlagtigt tro sit eget forsøg lykkedes.
    public static function affected_rows($conn, $result = null) {
        global $db_type;
        if ($db_type === 'sqlite') {
            return ($result instanceof PDOStatement) ? $result->rowCount() : 0;
        } else {
            return ($result === true && self::$stmt_affected !== null) ? self::$stmt_affected : mysqli_affected_rows($conn);
        }
    }
    private static ?int $stmt_affected = null;      // (kun sat af den seneste prepare_and_execute - DB::query() nulstiller)
    public static function stmt_bind_param(&$stmt, $types, ...$params) {
        global $db_type;
        if ($db_type !== 'sqlite') {
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }
        // SQLite kræver ikke bind_param, da vi binder direkte i execute()
    }
    public static function stmt_execute($stmt, $params = []) {
        global $db_type;
        if ($db_type === 'sqlite') {
            // SQLite: Send parametre med direkte i execute
            return $stmt->execute($params);
        } else {
            // MySQL: Parametre er allerede bundet via bind_param
            return mysqli_stmt_execute($stmt);
        }
    }
}

// Central bogføring af én ledger-linje. Medtager registreringsdato (created_at) og bruger-ID KUN hvis kolonnerne
// findes på ledger-tabellen - så bogføring aldrig knækker på en database hvor migrate_ledger_audit.php endnu ikke
// er kørt, men compliance-felterne udfyldes når de er til stede. Cross-engine.
// RETTET (flere regnskaber): fakturaarkivet, e-fakturaerne og SAF-T-arkivet lå i FÆLLES mapper for alle regnskaber
// (storage/invoices/invoice_<nr>.pdf) - og alle regnskaber starter deres nummerserie samme sted. Returnerer ''
// eller '<regnskabs-id>/'.
function tc_account_storage_subdir(): string {
    $id = (string)($_SESSION['account_id'] ?? '');
    if ($id === '' || !function_exists('account_list')) return '';
    $all = account_list(true);
    if (count($all) < 2 || (string)($all[0]['id'] ?? '') === $id) return '';
    $safe = preg_replace('/[^A-Za-z0-9_-]/', '', $id);
    return $safe !== '' ? $safe . '/' : '';
}
// Mappen <base>/<undermappe> - oprettes ved behov
function tc_account_storage_dir(string $base): string {
    $dir = rtrim($base, '/') . '/' . tc_account_storage_subdir();
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

// Firmalogoets mappe og fil. RETTET: logoet lå altid som images/logo.* - fælles for ALLE regnskaber på installationen,
// så et logo uploadet i regnskab B stod på regnskab A's fakturaer og tilbud. Følger nu samme opdeling som
// tc_account_storage_dir(): det første regnskab beholder images/logo.*, de øvrige images/<regnskab>/logo.*.
const TC_LOGO_EXTS = ['png', 'jpg', 'jpeg', 'webp', 'gif'];
function tc_logo_dir(): string {
    return tc_account_storage_dir('images');
}
function tc_logo_path(): ?string {
    $dir = tc_logo_dir();
    foreach (TC_LOGO_EXTS as $e) if (file_exists($dir . 'logo.' . $e)) return $dir . 'logo.' . $e;
    return null;
}

// Firmaets egen standardtekst til fakturamails - '' når den ikke er sat, eller når den blot er den gamle
// engelske forudfyldning fra Firmaindstillinger ("Please find your invoice attached."), som blev gemt ved
// enhver gemning og overstyrede den oversatte tekst på kundens sprog
function tc_custom_mail_body(array $settings): string {
    $b = trim(str_replace("\r\n", "\n", (string)($settings['default_mail_body'] ?? '')));
    return ($b === '' || $b === "Please find your invoice attached.\n\nBest regards,") ? '' : $b;
}

// RETTET: et kontonummer der IKKE findes i kontoplanen blev bogført uden videre (fx en indstilling der peger på
// standardværdien 5000, som kontoplanen ikke har). Nu en Exception - kalderne bogfører i en transaktion og ruller
// tilbage med en forklaring.
function ledger_accounts_missing($conn, array $acc_ids): array {
    $missing = [];
    foreach (array_unique(array_map('intval', $acc_ids)) as $a) {
        if ($a <= 0 || !DB::fetch_assoc(DB::query($conn, "SELECT acc_id FROM accounts WHERE acc_id = $a"))) $missing[] = $a;
    }
    return $missing;
}
function ledger_post($conn, $jou_id, $acc_id, $amount, bool $allow_missing = false) {
    static $known = [];
    if (!$allow_missing && !isset($known[(int)$acc_id])) {
        if (!DB::fetch_assoc(DB::query($conn, "SELECT acc_id FROM accounts WHERE acc_id = " . (int)$acc_id))) {
            $lm_key = '@The account %d does not exist in the chart of accounts - check Company Settings (posting accounts) or the chart of accounts. Nothing was posted.';
            throw new Exception(sprintf(function_exists('lang') ? lang($lm_key) : substr($lm_key, 1), (int)$acc_id));
        }
        $known[(int)$acc_id] = true;
    }
    static $has_audit = null;
    if ($has_audit === null) {
        $has_audit = false;
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "PRAGMA table_info(ledger)");
            if ($res) {
                while ($r = DB::fetch_assoc($res)) {
                    if (strtolower($r['name']) === 'created_at') { $has_audit = true; break; }
                }
            }
        } else {
            $res = DB::query($conn, "SHOW COLUMNS FROM ledger LIKE 'created_at'");
            $has_audit = ($res && DB::num_rows($res) > 0);
        }
    }
    $jou_id = (int)$jou_id;
    $acc_id = (int)$acc_id;
    $amount = (float)$amount;
    if ($has_audit) {
        $uid = (int)($_SESSION['user_id'] ?? 0);
        $now = date('Y-m-d H:i:s');
        return DB::query($conn, "INSERT INTO ledger (jou_id, acc_id, amount, created_at, user_id) VALUES ($jou_id, $acc_id, $amount, '$now', $uid)");
    }
    return DB::query($conn, "INSERT INTO ledger (jou_id, acc_id, amount) VALUES ($jou_id, $acc_id, $amount)");
}

// NYT: journal har ingen fælles opretningsfunktion (i modsætning til ledger_post ovenfor) - hvert af de 13 steder
// i koden, der selv skriver "INSERT INTO journal", bygger sin egen SQL-streng fra bunden med sine egne kolonner
// (trans_type/proj_id varierer fra sted til sted). I stedet for at kopiere et fuldt findes-kolonnen-tjek ind i
// alle 13, giver denne lille delte funktion KUN den ekstra ", created_by"-kolonne + ", <bruger-id>"-værdi, parate
// til at sættes ind i hvert steds eksisterende kolonne-/værdiliste - samme graceful "virker uanset om migrationen
// er kørt endnu"-filosofi som ledger_posts eget $has_audit-tjek, blot uden at tvinge alle 13 steder til én fælles
// funktionssignatur (hvilket ville have krævet at omskrive hvert steds allerede forskelligartede opbygning, med
// langt højere risiko for fejl i midt i regnskabskritisk kode).
function journal_created_by_sql($conn): array {
    static $has = null;
    if ($has === null) {
        $has = false;
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "PRAGMA table_info(journal)");
            if ($res) { while ($r = DB::fetch_assoc($res)) { if (strtolower($r['name']) === 'created_by') { $has = true; break; } } }
        } else {
            $res = DB::query($conn, "SHOW COLUMNS FROM journal LIKE 'created_by'");
            $has = ($res && DB::num_rows($res) > 0);
        }
    }
    if (!$has) return ['col' => '', 'val' => ''];
    return ['col' => ', created_by', 'val' => ', ' . (int)($_SESSION['user_id'] ?? 0)];
}

// Fælles, hulfrit bilagsnummer (voucher_no) på tværs af ALLE posteringstyper
// (fakturaer, kreditnotaer, udgifter, bankafstemning) - jf. bogføringsloven.
// Atomisk via en tæller-tabel (voucher_counter): kaldes inde i den kaldende
// flows egen DB::begin_transaction()/commit(), så en rullet-tilbage postering
// også frigiver nummeret igen (ingen huller fra mislykkede forsøg). Falder
// gracefult tilbage til et best-effort MAX+1 hvis migrationen (db-setup/
// migrate_voucher_counter.php) ikke er kørt endnu, ligesom ledger_post().
function next_voucher_no($conn) {
    static $has_counter = null;
    if ($has_counter === null) {
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "SELECT name FROM sqlite_master WHERE type='table' AND name='voucher_counter'");
        } else {
            $res = DB::query($conn, "SHOW TABLES LIKE 'voucher_counter'");
        }
        $has_counter = ($res && DB::num_rows($res) > 0);
    }

    if (!$has_counter) {
        return _voucher_fallback_max($conn) + 1;
    }

    $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM voucher_counter WHERE id = 1"));
    if (!$row) {
        // Tabellen findes, men er ikke seedet endnu - seed den defensivt.
        DB::insert($conn, 'voucher_counter', ['id' => 1, 'next_no' => _voucher_fallback_max($conn) + 1]);
    }

    // UPDATE'en tager en rækkelås (MySQL InnoDB) / eksklusiv skrivelås (SQLite)
    // inden for den kaldende transaktion, så to samtidige posteringer aldrig
    // kan få samme nummer.
    // RETTET: et allerede brugt bilagsnummer (fx efter import eller en nulstillet tæller) blev udstedt igen - to
    // bilag med samme nummer. Et brugt nummer springes over (samme værn som next_invoice_no()).
    for ($guard = 0; $guard < 3; $guard++) {
        DB::query($conn, "UPDATE voucher_counter SET next_no = next_no + 1 WHERE id = 1");
        $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM voucher_counter WHERE id = 1"));
        $no  = (int)$row['next_no'] - 1;
        if (!DB::fetch_assoc(DB::query($conn, "SELECT jou_id FROM journal WHERE voucher_no = $no LIMIT 1"))
            && !DB::fetch_assoc(DB::query($conn, "SELECT exp_id FROM expenses WHERE voucher_no = $no LIMIT 1"))) return $no;
        $max = _voucher_fallback_max($conn);
        DB::query($conn, "UPDATE voucher_counter SET next_no = " . ($max + 1) . " WHERE id = 1 AND next_no <= $max");
    }
    return _voucher_fallback_max($conn) + 1;
}

function _voucher_fallback_max($conn) {
    $mj = DB::fetch_assoc(DB::query($conn, "SELECT MAX(voucher_no) AS m FROM journal"));
    $me = DB::fetch_assoc(DB::query($conn, "SELECT MAX(voucher_no) AS m FROM expenses"));
    $mi = DB::fetch_assoc(DB::query($conn, "SELECT MAX(invoice_no) AS m FROM invoices"));
    return max((int)($mj['m'] ?? 0), (int)($me['m'] ?? 0), (int)($mi['m'] ?? 0));
}

// Det kundevendte fakturanummer (invoice_no) - SEPARAT fra voucher_no (det
// interne, fælles bilagsnummer på tværs af alle posteringstyper). Brugte før
// et "SELECT MAX(invoice_no)+1"-mønster i invoice_post_action.php, som er
// sårbart over for et kapløb: to samtidige bogføringer kunne i teorien læse
// samme MAX() før nogen af dem når at skrive, og få samme nummer - der er
// heller ingen UNIQUE-begrænsning på kolonnen som sidste sikkerhedsnet.
// Samme atomiske mønster som next_voucher_no() ovenfor, egen tæller-tabel
// (invoice_no_counter) så de to nummerserier ikke blander sig. Fundet ved en
// faktura-/fakturaflow-gennemgang.
function next_invoice_no($conn) {
    static $has_counter = null;
    if ($has_counter === null) {
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "SELECT name FROM sqlite_master WHERE type='table' AND name='invoice_no_counter'");
        } else {
            $res = DB::query($conn, "SHOW TABLES LIKE 'invoice_no_counter'");
        }
        $has_counter = ($res && DB::num_rows($res) > 0);
    }

    if (!$has_counter) {
        return _invoice_no_fallback_max($conn) + 1;
    }

    $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM invoice_no_counter WHERE id = 1"));
    if (!$row) {
        // Tabellen findes, men er ikke seedet endnu - seed den defensivt,
        // startende fra 1001 hvis der slet ingen fakturaer er endnu (samme
        // startpunkt invoice_post_action.php altid har brugt).
        $start = max(_invoice_no_fallback_max($conn) + 1, 1001);
        DB::insert($conn, 'invoice_no_counter', ['id' => 1, 'next_no' => $start]);
    }

    // RETTET: tælleren tjekkede ikke om nummeret allerede var brugt - fakturaer med numre der er kommet ind uden om
    // den (import, demo-data, en ændret startværdi) ville give DUBLEREDE fakturanumre, når tælleren nåede dertil.
    // Et brugt nummer springes nu over: tælleren rykkes forbi det højeste eksisterende nummer.
    for ($guard = 0; $guard < 3; $guard++) {
        // Samme atomiske UPDATE-mønster som next_voucher_no().
        DB::query($conn, "UPDATE invoice_no_counter SET next_no = next_no + 1 WHERE id = 1");
        $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM invoice_no_counter WHERE id = 1"));
        $no  = (int)$row['next_no'] - 1;
        if (!DB::fetch_assoc(DB::query($conn, "SELECT inv_id FROM invoices WHERE invoice_no = $no LIMIT 1"))) return $no;
        $max = _invoice_no_fallback_max($conn);
        DB::query($conn, "UPDATE invoice_no_counter SET next_no = " . ($max + 1) . " WHERE id = 1 AND next_no <= $max");
    }
    return _invoice_no_fallback_max($conn) + 1;
}

function _invoice_no_fallback_max($conn) {
    $mi = DB::fetch_assoc(DB::query($conn, "SELECT MAX(invoice_no) AS m FROM invoices"));
    return max((int)($mi['m'] ?? 0), 1000);
}

// NY: en kreditnota (invoice_credit.php) fik aldrig sit eget kundevendte fakturanummer - kun invoice_no=NULL,
// hvilket fik invoice_view.php til at vise "@DRAFT" for en fuldt bogført kreditnota. Egen, separat nummerserie
// (credit_note_no_counter) - samme atomiske mønster som next_invoice_no ovenfor - så kreditnotaer og almindelige
// fakturaer aldrig deler numre.
function next_credit_note_no($conn) {
    static $has_counter = null;
    if ($has_counter === null) {
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "SELECT name FROM sqlite_master WHERE type='table' AND name='credit_note_no_counter'");
        } else {
            $res = DB::query($conn, "SHOW TABLES LIKE 'credit_note_no_counter'");
        }
        $has_counter = ($res && DB::num_rows($res) > 0);
    }

    if (!$has_counter) {
        return null; // migration ikke kørt endnu - stille degradering, samme mønster som andre nyere kolonner
    }

    $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM credit_note_no_counter WHERE id = 1"));
    $cn_max = fn() => (int)(DB::fetch_row(DB::query($conn, "SELECT MAX(credit_note_no) FROM invoices"))[0] ?? 0);
    if (!$row) {
        // RETTET: startede altid ved 1 - også når der allerede fandtes kreditnotaer (dublerede kreditnotanumre)
        DB::insert($conn, 'credit_note_no_counter', ['id' => 1, 'next_no' => $cn_max() + 1]);
    }

    for ($guard = 0; $guard < 3; $guard++) {      // (et brugt nummer springes over - samme værn som next_invoice_no())
        DB::query($conn, "UPDATE credit_note_no_counter SET next_no = next_no + 1 WHERE id = 1");
        $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM credit_note_no_counter WHERE id = 1"));
        $no  = (int)$row['next_no'] - 1;
        if (!DB::fetch_assoc(DB::query($conn, "SELECT inv_id FROM invoices WHERE credit_note_no = $no LIMIT 1"))) return $no;
        $max = $cn_max();
        DB::query($conn, "UPDATE credit_note_no_counter SET next_no = " . ($max + 1) . " WHERE id = 1 AND next_no <= $max");
    }
    return $cn_max() + 1;
}

// NY: fælles, ENESTE beregning af en fakturas bogførte DKK-total (netto/moms/inkl.) - genbruges nu af BÅDE
// invoice_post_action.php (selve bogføringen) OG reconcile_action.php (afstemning). Konsekvens: en 1.000
// EUR-faktura (7.450 DKK bogført) blev markeret 'paid' efter blot én DKK-bankindbetaling på 1.000 DKK (langt fra
// hele beløbet), eller omvendt aldrig nåede 'paid' selvom kunden reelt havde betalt fuldt ud i EUR.
// NYT: valgfri rabat pr. linje (invoice_lines.discount_pct, db-setup/migrate_invoice_line_discount.php) - trækkes
// fra NETTOBELØBET før moms beregnes, samme rækkefølge som standard dansk fakturapraksis. Udtrukket til to delte
// hjælpefunktioner, da MANGE steder i kodebasen selv genberegner en linje-/fakturatotal direkte fra invoice_lines
// i stedet for at kalde invoice_dkk_totals (som kun tager ét inv_id ad gangen, upraktisk for en rapport der
// summerer på tværs af mange fakturaer) - se
// aging_report.php/index.php/project_view.php/reconcile_list.php/recurring_invoices.php/reminder_action.php/reminders.php/subledger_reconciliation.php
// for de øvrige kaldesteder, alle rettet i samme runde.
function invoice_lines_has_discount_col($conn): bool {
    static $has = null;
    if ($has === null) {
        $has = false;
        if (DB::is_sqlite()) {
            $dcc = DB::query($conn, "PRAGMA table_info(invoice_lines)");
            if ($dcc) { while ($dccr = DB::fetch_assoc($dcc)) { if ($dccr['name'] === 'discount_pct') { $has = true; break; } } }
        } else {
            $dcc = DB::query($conn, "SHOW COLUMNS FROM invoice_lines LIKE 'discount_pct'");
            $has = ($dcc && DB::num_rows($dcc) > 0);
        }
    }
    return $has;
}

// Returnerer SQL-fragmentet der ganger et linjebeløb ned med rabatten - eller
// en tom streng, hvis discount_pct-kolonnen slet ikke findes endnu. $prefix
// er tabel-aliaset i den konkrete forespørgsel (fx "il." i et JOIN), inkl.
// det afsluttende punktum, eller en tom streng hvis der ikke joines.
function invoice_discount_sql($conn, string $prefix = ''): string {
    return invoice_lines_has_discount_col($conn) ? "* (100 - COALESCE({$prefix}discount_pct, 0)) / 100.0" : "";
}

// NYT: en udgift kan nu VALGFRIT splittes på flere konti via expense_lines - se
// db-setup/migrate_expense_lines.php. Returnerer ALTID mindst én "linje" - findes ingen rigtige
// expense_lines-rækker for denne udgift (langt de fleste, bagudkompatibelt), bygges én SYNTETISK linje af selve
// expense-rækkens egne account_id/amount/vat_rate, så en kaldende funktion aldrig behøver et separat if/else for
// "har linjer eller ej".
function expense_lines_has_table($conn): bool {
    static $has = null;
    if ($has === null) {
        if (DB::is_sqlite()) {
            $r = DB::query($conn, "SELECT name FROM sqlite_master WHERE type='table' AND name='expense_lines'");
            $has = ($r && DB::fetch_assoc($r)) ? true : false;
        } else {
            $r = DB::query($conn, "SHOW TABLES LIKE 'expense_lines'");
            $has = ($r && DB::num_rows($r) > 0);
        }
    }
    return $has;
}

function expense_get_lines($conn, int $exp_id): array {
    $rows = [];
    if (expense_lines_has_table($conn)) {
        $res = DB::query($conn, "SELECT account_id, amount, line_vat_rate, description FROM expense_lines WHERE exp_id = $exp_id ORDER BY line_id ASC");
        if ($res) { while ($r = DB::fetch_assoc($res)) { $rows[] = $r; } }
    }
    if (empty($rows)) {
        $exp = DB::fetch_assoc(DB::query($conn, "SELECT account_id, amount, vat_rate FROM expenses WHERE exp_id = $exp_id"));
        if (!$exp) return [];
        $rows = [['account_id' => $exp['account_id'], 'amount' => $exp['amount'], 'line_vat_rate' => $exp['vat_rate'], 'description' => null]];
    }

    // Løs hver linjes momssats: linjens egen, ellers dens konto standardsats
    // (samme "pr.-post override, ellers kontoens standard"-mønster som
    // expenses.vat_rate/accounts.vat_rate allerede brugte for én-konto-udgifter).
    $result = [];
    foreach ($rows as $r) {
        $acc_id = (int)$r['account_id'];
        $gross  = (float)$r['amount'];
        $rate   = (isset($r['line_vat_rate']) && $r['line_vat_rate'] !== null && $r['line_vat_rate'] !== '') ? (float)$r['line_vat_rate'] : null;
        if ($rate === null) {
            $acc_row = DB::fetch_assoc(DB::query($conn, "SELECT vat_rate, acc_type FROM accounts WHERE acc_id = $acc_id"));
            // (en salgskonto uden sats har landets standardsats, som på fakturaen og i bankafstemningen)
            $rate = ($acc_row && $acc_row['vat_rate'] === null && $acc_row['acc_type'] === 'income') ? tc_vat_std_rate() : (float)($acc_row['vat_rate'] ?? 0);
        }
        $vat = ($rate > 0) ? round($gross * $rate / (100 + $rate), 2) : 0.0;
        $net = round($gross - $vat, 2);
        // Omvendt betalingspligt (EU-køb m.m.): fakturaen er uden moms, så beløbet er netto. Momsen beregnes oven i
        // og bogføres både som skyldig (rc_acc) og som købsmoms - rc_vat, uden at ændre betalingen. Se tc_vat_rc_info().
        $rc = tc_vat_rc_info($conn, $acc_id);
        $rc_vat = 0.0;
        if ($rc) { $vat = 0.0;  $net = $gross;  $rate = 0.0;  $rc_vat = round($gross * $rc['rate'] / 100, 2); }
        $result[] = ['account_id' => $acc_id, 'gross' => $gross, 'vat_rate' => $rate, 'vat' => $vat, 'net' => $net, 'description' => $r['description'] ?? null,
                     'rc_vat' => $rc_vat, 'rc_acc' => $rc ? $rc['acc'] : 0, 'rc_type' => $rc ? $rc['type'] : null];
    }
    return $result;
}

// NYT: "Slet" på en kunde/leverandør er nu en gendannelig blødsletning (deleted_at) - se
// db-setup/migrate_trash_bin.php/trash_bin.php. Stille degraderet til "vis alle" (tom streng) hvis migrationen
// ikke er kørt endnu.
function customers_active_filter($conn, string $prefix = ''): string {
    static $has = null;
    if ($has === null) {
        if (DB::is_sqlite()) {
            $r = DB::query($conn, "PRAGMA table_info(customers)");
            $has = false;
            if ($r) { while ($row = DB::fetch_assoc($r)) { if ($row['name'] === 'deleted_at') { $has = true; break; } } }
        } else {
            $r = DB::query($conn, "SHOW COLUMNS FROM customers LIKE 'deleted_at'");
            $has = ($r && DB::num_rows($r) > 0);
        }
    }
    return $has ? "{$prefix}deleted_at IS NULL" : "1=1";
}

function suppliers_active_filter($conn, string $prefix = ''): string {
    static $has = null;
    if ($has === null) {
        if (DB::is_sqlite()) {
            $r = DB::query($conn, "PRAGMA table_info(suppliers)");
            $has = false;
            if ($r) { while ($row = DB::fetch_assoc($r)) { if ($row['name'] === 'deleted_at') { $has = true; break; } } }
        } else {
            $r = DB::query($conn, "SHOW COLUMNS FROM suppliers LIKE 'deleted_at'");
            $has = ($r && DB::num_rows($r) > 0);
        }
    }
    return $has ? "{$prefix}deleted_at IS NULL" : "1=1";
}

function invoice_dkk_totals($conn, int $inv_id): array {
    $disc_factor = invoice_discount_sql($conn);
    $tot_row = DB::fetch_assoc(DB::query($conn,
        "SELECT COALESCE(SUM(quantity * price_each $disc_factor), 0) AS net,
                COALESCE(SUM(quantity * price_each $disc_factor * line_vat_rate / 100.0), 0) AS vat
         FROM invoice_lines WHERE inv_id = $inv_id"));
    // Beløbene er i FAKTURAENS EGEN valuta her (den linjerne er indtastet i) -
    // afrundes til øre i den valuta først, samme rækkefølge som invoice_post_
    // action.php altid har brugt (undgår binær flydende-komma-støj i SUM()).
    $total_excl = round((float)($tot_row['net'] ?? 0), 2);
    $total_vat  = round((float)($tot_row['vat'] ?? 0), 2);

    $exch_row  = DB::fetch_assoc(DB::query($conn, "SELECT exch_rate FROM invoices WHERE inv_id = $inv_id"));
    $exch_rate = (float)($exch_row['exch_rate'] ?? 0);
    if ($exch_rate > 0) {
        $total_excl = round($total_excl * $exch_rate, 2);
        $total_vat  = round($total_vat * $exch_rate, 2);
    }
    $total_incl = round($total_excl + $total_vat, 2);

    return ['excl' => $total_excl, 'vat' => $total_vat, 'incl' => $total_incl, 'exch_rate' => $exch_rate];
}

// DELVIS KREDITNOTA: en faktura der kun er krediteret for en del, beholder sin status (sendt/betalt) - det kunden
// stadig skylder er fakturaen + dens kreditnota(er) (negative) - betalingerne. Kreditnotaernes beløb (DKK inkl.
// moms, negativt) for en faktura:
function invoice_credited_dkk($conn, int $inv_id): float {
    $sum = 0.0;
    $res = DB::query($conn, "SELECT inv_id FROM invoices WHERE credit_ref = $inv_id");
    if ($res) while ($r = DB::fetch_assoc($res)) $sum += invoice_dkk_totals($conn, (int)$r['inv_id'])['incl'];
    return round($sum, 2);
}
// Bogførte rykkergebyrer på en faktura (DKK) - en del af det kunden skylder på fakturaen (se inc/reminder.inc.php)
function invoice_fees_dkk($conn, int $inv_id): float {
    if (!db_has_table($conn, 'invoice_fees')) return 0.0;
    return round((float)(DB::fetch_row(DB::query($conn, "SELECT COALESCE(SUM(amount), 0) FROM invoice_fees WHERE inv_id = $inv_id"))[0] ?? 0), 2);
}
// Samme som SQL-udtryk til lister (fakturaen har alias $alias); 0 uden tabellen
// Dubletkontrollen ved bankimport (CSV, CAMT) gælder kun linjer på samme bankkonto - en linje uden konto (NULL/0) hører
// til standard-bankkontoen. Før blev en ens linje på en anden konto (samme dato, tekst og beløb) afvist som dublet.
function tc_bank_dup_acc_sql(int $acc_id): string {
    $def = (int)setting('conf_acc_bank', 5000);
    return "COALESCE(NULLIF(acc_id, 0), $def) = " . ($acc_id > 0 ? $acc_id : $def);
}
function invoice_fees_sql($conn, string $alias = 'i'): string {
    return db_has_table($conn, 'invoice_fees') ? "(SELECT COALESCE(SUM(fe.amount), 0) FROM invoice_fees fe WHERE fe.inv_id = $alias.inv_id)" : '0';
}
// Det åbne beløb på en faktura (DKK): total + kreditnotaer + rykkergebyrer - betalinger
function invoice_open_dkk($conn, int $inv_id): float {
    $paid = DB::fetch_assoc(DB::query($conn, "SELECT COALESCE(SUM(amount), 0) AS paid FROM invoice_payments WHERE inv_id = $inv_id"));
    return round(invoice_dkk_totals($conn, $inv_id)['incl'] + invoice_credited_dkk($conn, $inv_id) + invoice_fees_dkk($conn, $inv_id) - (float)($paid['paid'] ?? 0), 2);
}
// Samme kreditnotabeløb som et SQL-udtryk til lister (fakturaen har alias $alias)
function invoice_credited_sql($conn, string $alias = 'i'): string {
    $disc = invoice_discount_sql($conn, 'cl.');
    return "(SELECT COALESCE(SUM(cl.quantity * cl.price_each $disc * (100 + cl.line_vat_rate) / 100.0 * COALESCE(NULLIF(ci.exch_rate, 0), 1)), 0)"
         . " FROM invoices ci JOIN invoice_lines cl ON cl.inv_id = ci.inv_id WHERE ci.credit_ref = $alias.inv_id)";
}

// ÅBNE FAKTURAER - den ene definition alle lister og rapporter bruger (før havde hver side sin egen kopi af formlen og sit
// eget statusfilter, og de gik i utakt: et gebyr manglede ét sted, en krediteret faktura med et skyldigt gebyr et andet).
// Som SQL-udtryk for fakturaen med alias $alias, i bogføringsvalutaen (samme beløb som invoice_open_dkk() pr. faktura):
//   invoice_total_sql = linjer inkl. moms x kurs + kreditnotaer (negative) + bogførte rykkergebyrer
//   invoice_paid_sql  = registrerede betalinger
//   invoice_open_sql  = total - betalt (negativt = kunden har penge til gode)
function invoice_total_sql($conn, string $alias = 'i'): string {
    $disc = invoice_discount_sql($conn, 'tl.');
    return "((SELECT COALESCE(SUM(tl.quantity * tl.price_each $disc * (100 + tl.line_vat_rate) / 100.0), 0) FROM invoice_lines tl WHERE tl.inv_id = $alias.inv_id)"
         . " * COALESCE(NULLIF($alias.exch_rate, 0), 1) + " . invoice_credited_sql($conn, $alias) . " + " . invoice_fees_sql($conn, $alias) . ")";
}
function invoice_paid_sql(string $alias = 'i'): string {
    return "(SELECT COALESCE(SUM(tp.amount), 0) FROM invoice_payments tp WHERE tp.inv_id = $alias.inv_id)";
}
function invoice_open_sql($conn, string $alias = 'i'): string {
    return "(" . invoice_total_sql($conn, $alias) . " - " . invoice_paid_sql($alias) . ")";
}
// De fakturaer der kan have et restbeløb: bogførte originaler (ikke kladder, ikke kreditnotaerne selv - de indgår i
// originalens total). Status alene siger ikke om der er noget åbent: 'credited' kan stadig skylde et gebyr eller have
// en betaling der skal tilbage, og 'paid' kan være overbetalt. Brug "... AND " . invoice_open_sql(...) . " > 0.01" for
// det kunden skylder.
function invoice_open_where(string $alias = 'i'): string {
    return "$alias.credit_ref IS NULL AND LOWER($alias.inv_status) <> 'draft'";
}

// Nummerserie til Tilbud/Ordrebekræftelse (quotes) - egen tæller
// (quote_no_counter), adskilt fra invoice_no_counter, så et tilbuds nummer
// aldrig kan kollidere med eller "bruge af" den rigtige fakturaserie. I
// modsætning til next_invoice_no() (som bevidst kun tildeles ved selve
// BOGFØRINGEN, af hensyn til bogføringsloven) tildeles quote_no med det
// samme ved oprettelse - et tilbud er intet regnskabsdokument, så der er
// ingen tilsvarende juridisk grund til at vente.
function next_quote_no($conn) {
    static $has_counter = null;
    if ($has_counter === null) {
        if (DB::is_sqlite()) {
            $res = DB::query($conn, "SELECT name FROM sqlite_master WHERE type='table' AND name='quote_no_counter'");
        } else {
            $res = DB::query($conn, "SHOW TABLES LIKE 'quote_no_counter'");
        }
        $has_counter = ($res && DB::num_rows($res) > 0);
    }

    if (!$has_counter) {
        $mq = DB::fetch_assoc(DB::query($conn, "SELECT MAX(quote_no) AS m FROM quotes"));
        return (int)($mq['m'] ?? 0) + 1;
    }

    $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM quote_no_counter WHERE id = 1"));
    $q_max = fn() => (int)(DB::fetch_row(DB::query($conn, "SELECT MAX(quote_no) FROM quotes"))[0] ?? 0);
    if (!$row) {
        DB::insert($conn, 'quote_no_counter', ['id' => 1, 'next_no' => $q_max() + 1]);
    }

    // Samme atomiske UPDATE-mønster som next_voucher_no()/next_invoice_no(). Et brugt nummer springes over - en
    // nulstillet tæller (fx efter flytning af data mellem regnskaber) gav ellers to tilbud med samme nummer.
    for ($guard = 0; $guard < 3; $guard++) {
        DB::query($conn, "UPDATE quote_no_counter SET next_no = next_no + 1 WHERE id = 1");
        $row = DB::fetch_assoc(DB::query($conn, "SELECT next_no FROM quote_no_counter WHERE id = 1"));
        $no  = (int)$row['next_no'] - 1;
        if (!DB::fetch_assoc(DB::query($conn, "SELECT quote_id FROM quotes WHERE quote_no = $no LIMIT 1"))) return $no;
        $max = $q_max();
        DB::query($conn, "UPDATE quote_no_counter SET next_no = " . ($max + 1) . " WHERE id = 1 AND next_no <= $max");
    }
    return $q_max() + 1;
}

// -----------------------------------------------------------------------
// DB-NIVEAU APPEND-ONLY PÅ HOVEDBOGEN (bogføringsloven)
// -----------------------------------------------------------------------
// Delt mellem db-setup/migrate_append_only_ledger.php (eksisterende
// installationer) og create_all_tables.core.php (friske installationer),
// så de to steder ikke kan glide fra hinanden. Se migrate_append_only_
// ledger.php's egen, udførlige kommentar for den fulde begrundelse for
// hvert enkelt tjek. Bevidst "best effort" - kaster ALDRIG en fejl videre,
// da fraværet af triggere ikke må forhindre selve installationen/
// migrationen i at gennemføre (PHP-lagets tjek er stadig det primære værn).
// RETTET 2026-08-20 (fundet under den systematiske migrations-gennemgang
// efter migration_credit.php's flerlagsfejl): returnerede FØR kun et
// heltal (antal oprettet). Kaldende kode (migrate_append_only_ledger.php)
// tolkede "0" som "alle findes allerede" - men 0 kunne LIGE SÅ GODT betyde
// "alle 4 forsøg fejlede stille" (fx manglende TRIGGER-rettighed, ikke
// ualmindeligt på delt hosting) - fejlen forsvandt kun i PHP's egen
// error_log, usynlig for den admin der kører migrationen. Returnerer nu et
// array med både antal oprettet OG en liste over hvad der reelt fejlede,
// så kaldende kode kan vise en ærlig besked i stedet for en falsk
// "allerede anvendt".
function create_append_only_triggers($conn): array {
    global $pdo, $db_type;
    $created = 0;
    $failed = [];

    // NYT: to tilføjelser til denne allerede eksisterende funktion: (a) trg_expenses_*-triggerne nedenfor - "ingen
    // database-trigger på expenses"-hullet. expense_edit.php havde allerede PRÆCIS samme felt-begrænsning i
    // PHP-laget (beløb/konto/dato/type låst, kun leverandør/beskrivelse/projekt frit redigerbart på en bogført
    // udgift) - denne trigger håndhæver nu DEN SAMME, allerede besluttede politik på selve databaseniveauet, samme
    // mønster som journal/ledger allerede fik 2026-08-20.
    // RETTET SAMTIDIG: funktionen sprang FØR enhver trigger allerede fundet ved navn helt over (både SQLite- og
    // MySQL-grenen) - en ÆNDRET trigger-definition (som netop journal-opdateringen her) ville derfor ALDRIG slå
    // igennem på en installation, der allerede havde den gamle udgave oprettet, uanset hvor mange gange
    // migrationen blev kørt igen. Ubetinget DROP+CREATE (samme to kald, blot uden "spring over hvis
    // findes"-tjekket foran) gør funktionen reelt idempotent OGSÅ ved fremtidige definitionsændringer, ikke kun
    // ved førstegangsoprettelse.
    $journal_has_created_by = false;
    if (DB::is_sqlite()) {
        $res = DB::query($conn, "PRAGMA table_info(journal)");
        if ($res) { while ($r = DB::fetch_assoc($res)) { if (strtolower($r['name']) === 'created_by') { $journal_has_created_by = true; break; } } }
    } else {
        $res = DB::query($conn, "SHOW COLUMNS FROM journal LIKE 'created_by'");
        $journal_has_created_by = ($res && DB::num_rows($res) > 0);
    }

    if ($db_type === 'sqlite') {
        $jou_created_by_chk = $journal_has_created_by ? " OR NEW.created_by IS NOT OLD.created_by" : "";
        $triggers = [
            'trg_journal_no_delete_posted' => "
                CREATE TRIGGER trg_journal_no_delete_posted
                BEFORE DELETE ON journal FOR EACH ROW
                WHEN OLD.voucher_no IS NOT NULL
                BEGIN SELECT RAISE(ABORT, 'Bogforte journalposter kan ikke slettes (bogforingsloven) - brug Annuller i stedet'); END;",
            'trg_journal_restrict_update_posted' => "
                CREATE TRIGGER trg_journal_restrict_update_posted
                BEFORE UPDATE ON journal FOR EACH ROW
                WHEN OLD.voucher_no IS NOT NULL AND (
                    NEW.voucher_no IS NOT OLD.voucher_no OR NEW.jou_date IS NOT OLD.jou_date OR
                    NEW.created_at IS NOT OLD.created_at OR NEW.trans_type IS NOT OLD.trans_type OR
                    NEW.currency IS NOT OLD.currency OR (OLD.is_cancelled = 1 AND NEW.is_cancelled = 0)
                    $jou_created_by_chk
                )
                BEGIN SELECT RAISE(ABORT, 'Bogforte journalposter kan kun rettes i tekst/projekt eller annulleres (bogforingsloven)'); END;",
            'trg_ledger_no_delete_posted' => "
                CREATE TRIGGER trg_ledger_no_delete_posted
                BEFORE DELETE ON ledger FOR EACH ROW
                WHEN (SELECT voucher_no FROM journal WHERE jou_id = OLD.jou_id) IS NOT NULL
                BEGIN SELECT RAISE(ABORT, 'Bogforte hovedbogslinjer kan ikke slettes (bogforingsloven)'); END;",
            'trg_ledger_no_update_posted' => "
                CREATE TRIGGER trg_ledger_no_update_posted
                BEFORE UPDATE ON ledger FOR EACH ROW
                WHEN (SELECT voucher_no FROM journal WHERE jou_id = OLD.jou_id) IS NOT NULL
                BEGIN SELECT RAISE(ABORT, 'Bogforte hovedbogslinjer kan ikke rettes (bogforingsloven)'); END;",
            'trg_expenses_no_delete_posted' => "
                CREATE TRIGGER trg_expenses_no_delete_posted
                BEFORE DELETE ON expenses FOR EACH ROW
                WHEN OLD.voucher_no IS NOT NULL
                BEGIN SELECT RAISE(ABORT, 'Bogforte udgifter kan ikke slettes (bogforingsloven) - brug Annuller i stedet'); END;",
            'trg_expenses_restrict_update_posted' => "
                CREATE TRIGGER trg_expenses_restrict_update_posted
                BEFORE UPDATE ON expenses FOR EACH ROW
                WHEN OLD.voucher_no IS NOT NULL AND (
                    NEW.voucher_no IS NOT OLD.voucher_no OR NEW.exp_date IS NOT OLD.exp_date OR
                    NEW.account_id IS NOT OLD.account_id OR NEW.amount IS NOT OLD.amount OR
                    NEW.vat_rate IS NOT OLD.vat_rate OR NEW.currency IS NOT OLD.currency OR
                    NEW.exp_type IS NOT OLD.exp_type OR NEW.orig_currency IS NOT OLD.orig_currency OR
                    NEW.orig_amount IS NOT OLD.orig_amount OR NEW.exch_rate IS NOT OLD.exch_rate OR
                    NEW.created_at IS NOT OLD.created_at OR NEW.created_by IS NOT OLD.created_by OR
                    (OLD.is_cancelled = 1 AND NEW.is_cancelled = 0)
                )
                BEGIN SELECT RAISE(ABORT, 'Bogforte udgifter kan kun rettes i leverandor/beskrivelse/projekt/bilag eller annulleres (bogforingsloven)'); END;",
        ];
        foreach ($triggers as $name => $sql) {
            try {
                @$pdo->exec("DROP TRIGGER IF EXISTS $name");
                $pdo->exec($sql);
                $created++;
            } catch (Exception $e) {
                error_log("create_append_only_triggers: $name fejlede: " . $e->getMessage());
                $failed[$name] = $e->getMessage();
            }
        }
    } else {
        $jou_created_by_chk = $journal_has_created_by ? " OR NOT (NEW.created_by <=> OLD.created_by)" : "";
        $triggers = [
            'trg_journal_no_delete_posted' => "
                CREATE TRIGGER trg_journal_no_delete_posted BEFORE DELETE ON journal FOR EACH ROW
                BEGIN IF OLD.voucher_no IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte journalposter kan ikke slettes (bogforingsloven) - brug Annuller i stedet';
                END IF; END",
            'trg_journal_restrict_update_posted' => "
                CREATE TRIGGER trg_journal_restrict_update_posted BEFORE UPDATE ON journal FOR EACH ROW
                BEGIN IF OLD.voucher_no IS NOT NULL AND (
                    NOT (NEW.voucher_no <=> OLD.voucher_no) OR NOT (NEW.jou_date <=> OLD.jou_date) OR
                    NOT (NEW.created_at <=> OLD.created_at) OR NOT (NEW.trans_type <=> OLD.trans_type) OR
                    NOT (NEW.currency <=> OLD.currency) OR (OLD.is_cancelled = 1 AND NEW.is_cancelled = 0)
                    $jou_created_by_chk
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte journalposter kan kun rettes i tekst/projekt eller annulleres (bogforingsloven)';
                END IF; END",
            'trg_ledger_no_delete_posted' => "
                CREATE TRIGGER trg_ledger_no_delete_posted BEFORE DELETE ON ledger FOR EACH ROW
                BEGIN IF (SELECT voucher_no FROM journal WHERE jou_id = OLD.jou_id) IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte hovedbogslinjer kan ikke slettes (bogforingsloven)';
                END IF; END",
            'trg_ledger_no_update_posted' => "
                CREATE TRIGGER trg_ledger_no_update_posted BEFORE UPDATE ON ledger FOR EACH ROW
                BEGIN IF (SELECT voucher_no FROM journal WHERE jou_id = OLD.jou_id) IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte hovedbogslinjer kan ikke rettes (bogforingsloven)';
                END IF; END",
            'trg_expenses_no_delete_posted' => "
                CREATE TRIGGER trg_expenses_no_delete_posted BEFORE DELETE ON expenses FOR EACH ROW
                BEGIN IF OLD.voucher_no IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte udgifter kan ikke slettes (bogforingsloven) - brug Annuller i stedet';
                END IF; END",
            'trg_expenses_restrict_update_posted' => "
                CREATE TRIGGER trg_expenses_restrict_update_posted BEFORE UPDATE ON expenses FOR EACH ROW
                BEGIN IF OLD.voucher_no IS NOT NULL AND (
                    NOT (NEW.voucher_no <=> OLD.voucher_no) OR NOT (NEW.exp_date <=> OLD.exp_date) OR
                    NOT (NEW.account_id <=> OLD.account_id) OR NOT (NEW.amount <=> OLD.amount) OR
                    NOT (NEW.vat_rate <=> OLD.vat_rate) OR NOT (NEW.currency <=> OLD.currency) OR
                    NOT (NEW.exp_type <=> OLD.exp_type) OR NOT (NEW.orig_currency <=> OLD.orig_currency) OR
                    NOT (NEW.orig_amount <=> OLD.orig_amount) OR NOT (NEW.exch_rate <=> OLD.exch_rate) OR
                    NOT (NEW.created_at <=> OLD.created_at) OR NOT (NEW.created_by <=> OLD.created_by) OR
                    (OLD.is_cancelled = 1 AND NEW.is_cancelled = 0)
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bogforte udgifter kan kun rettes i leverandor/beskrivelse/projekt/bilag eller annulleres (bogforingsloven)';
                END IF; END",
        ];
        foreach ($triggers as $name => $sql) {
            // RETTET: denne løkke havde INGEN try/catch, i modsætning til SQLite-grenen ovenfor - stod derfor i
            // direkte modstrid med funktionens egen "kaster ALDRIG en fejl videre"-kontrakt lige herover. Siden
            // PHP 8.1 KASTER mysqli_query m.fl. en mysqli_sql_exception ved fejl i stedet for at returnere false
            // (bekræftet direkte, samme rodårsag som de to andre rettelser) - og den helt konkrete fejl
            // kommentaren selv nævner ("manglende TRIGGER-rettighed, ikke ualmindeligt på delt hosting") ville
            // derfor have væltet HELE create_all_tables_for/en frisk MySQL-installation, i stedet for blot at
            // springe triggerne over som tilsigtet.
            try {
                // RETTET (se funktionens egen kommentar foroven): "SHOW TRIGGERS... hvis findes, spring
                // over"-tjekket er fjernet - DROP+CREATE køres nu ubetinget hver gang, så en ÆNDRET
                // trigger-definition (fx journal-opdateringens nye created_by-tjek) rent faktisk slår igennem ved
                // en fornyet kørsel.
                @mysqli_query($conn, "DROP TRIGGER IF EXISTS `$name`");
                if (mysqli_query($conn, $sql)) {
                    $created++;
                } else {
                    $err = mysqli_error($conn);
                    error_log("create_append_only_triggers: $name fejlede: " . $err);
                    $failed[$name] = $err;
                }
            } catch (\Throwable $e) {
                error_log("create_append_only_triggers: $name fejlede: " . $e->getMessage());
                $failed[$name] = $e->getMessage();
            }
        }
    }
    return ['created' => $created, 'failed' => $failed];
}

// RETTET (bruger-rapport "oversættelsesforslag er stadig blankt"): sporet til at INGEN af de tre steder i
// projektet, der laver udgående HTTPS-curl-kald (translation_manager.php's OpenAI-kald, inc/help.lib.php's to
// OpenAI-kald, inc/enablebanking.lib.php's bank-API-kald), satte CURLOPT_CAINFO - på en server/udviklingsmaskine
// uden en systemkonfigureret CA-rodcertifikat-liste (bekræftet konkret her: både curl.cainfo og openssl.cafile er
// ukommenteret/tomme i php.ini) fejler ETHVERT sådant kald med curl-fejl 60 ("unable to get local issuer
// certificate"). translation_manager.php's egen getAiSuggestion fangede fejlen og faldt tavst tilbage til den
// urørte engelske nøgle i stedet for et rigtigt AI-forslag - så det SÅ ud som om funktionen "virkede"
// (success:true), men gav aldrig en reel oversættelse, hvilket brugeren oplevede som at forslaget "stadig er
// blankt".
// Fælles løsning: bundler selv en ajourført CA-rodcertifikat-liste (Mozillas, hentet fra curl.se/ca/cacert.pem,
// samme kilde curl selv anbefaler) i inc/cacert.pem, og peger eksplicit på den her - så alle tre kaldssteder
// virker uafhængigt af den underliggende servers php.ini, uanset om den kører på Windows (hvor dette langt fra er
// ualmindeligt at mangle) eller Linux. tc_curl_init ligger i denne fil, fordi db_connect.inc.php er det ene
// include, alle sider (og alle tre kaldssteder) reelt har til fælles - php2htm.lib.php er det ikke (se fx
// bank_integration_connect.php).
function tc_curl_init(string $url) {
    $ch = curl_init($url);
    $cacert = __DIR__ . '/cacert.pem';
    if (is_file($cacert)) {
        curl_setopt($ch, CURLOPT_CAINFO, $cacert);
        curl_setopt($ch, CURLOPT_CAPATH, dirname($cacert));
    }
    return $ch;
}

?>