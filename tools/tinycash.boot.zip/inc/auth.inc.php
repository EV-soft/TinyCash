<?php # /inc/auth.inc.php v:1.3.1 d:2026-09-15 i:evs
# v1.2.0: KRITISK - ?set_level= tillod enhver logget-ind bruger at give sig
# selv admin-niveau uden noget tjek. Kræver nu real_user_level fra login.php
# og tillader kun at sænke, aldrig hæve. Fundet ved en adgangskontrol-
# gennemgang. Se også login.php + user_edit.php/user_create.php (samme fund).
require_once 'inc/php2htm.lib.php';

// UTF-8-kontrol af alt hvad en side modtager (formularer, links) - se tc_utf8() i inc/core_utils.lib.php
$_GET  = tc_utf8($_GET);
$_POST = tc_utf8($_POST);
$_REQUEST = tc_utf8($_REQUEST);

if (session_status() === PHP_SESSION_NONE) {
    $session_time = 14400; // 4 timer
    ini_set('session.gc_maxlifetime', $session_time);
    
    // Tving et unikt sessionsnavn specifikt til dit PHP 8-miljø
    // Dette klipper ALT samarbejde med de gamle, defekte sessionsfiler på serveren!
    session_name('TCC_V100_SESSION'); 

    // RETTET: 'secure' manglede helt - session-cookien (som er den ENESTE ting der beviser man er logget ind)
    // kunne derfor altid sendes over almindelig, ukrypteret HTTP, selv på en installation der ellers udelukkende
    // køres over HTTPS. Sættes nu betinget ud fra om forespørgslen faktisk kom ind over HTTPS - hårdkodet 'true'
    // ville have låst lokal HTTP-udvikling (php -S, ingen HTTPS) helt ude af at kunne logge ind overhovedet.
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || ($_SERVER['SERVER_PORT'] ?? '') == 443;

    session_set_cookie_params([
        'lifetime' => $session_time,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $is_https
    ]);

    session_start();
    // Cookien sendes kun når sessionen oprettes - dens 4 timer regnedes fra login, så en aktiv bruger blev logget ud midt
    // i arbejdet (og mistede en udfyldt formular). Den fornyes nu ved hver side: udløb efter 4 timers inaktivitet.
    if (!headers_sent() && isset($_COOKIE[session_name()]) && $_COOKIE[session_name()] === session_id()) {
        setcookie(session_name(), session_id(), ['expires' => time() + $session_time, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => $is_https]);
    }
    echo "";
}

// 1. --- HÅNDTER NIVEAUSKIFT FRA L-INDIKATOR (Kører ALTID) ---
// KRITISK RETTET 2026-08-19: dette tjekkede FØR intet som helst - enhver
// logget-ind bruger (også niveau 1) kunne besøge ?set_level=3 og give sig
// selv fuldt admin-niveau i resten af sessionen, og dermed omgå enhver side
// der bruger $rLev (CLAUDE.md's egen anbefalede metode til at afspærre nye
// sider). Nu tillades KUN at sænke til en midlertidig forhåndsvisning af et
// LAVERE niveau end brugerens ægte, database-hentede niveau
// ($_SESSION['real_user_level'], sat udelukkende i login.php ved reelt
// login) - aldrig at hæve over det. Findes intet ægte niveau i sessionen
// (fx en session fra før denne rettelse), afvises ændringen helt.
if (isset($_GET['set_level'])) {
    $requested_level = (int)$_GET['set_level'];
    $real_level = $_SESSION['real_user_level'] ?? null;
    if ($real_level !== null && $requested_level >= 1 && $requested_level <= $real_level) {
        $_SESSION['user_level'] = $requested_level;
    }
}

// 2. --- SPROG-HÅNDTERING (Kører ALTID) ---
if (isset($_GET['l'])) {
    $requested_lang = strtolower($_GET['l']);
    if (preg_match('/^[a-z]{2}$/', $requested_lang)) {
        $_SESSION['lang'] = $requested_lang;
        
        // Opdater proglang med det samme, så biblioteket forstår det
        if ($requested_lang === 'en') {
            $_SESSION['proglang'] = 'en : English';
        } else {
            $_SESSION['proglang'] = 'da : Dansk';
        }
    }
}

// Fallback hvis sessionen ikke er sat endnu
// (sat længere nede, efter forbindelsen til regnskabet - standardsproget følger landepakken)
if (!isset($_SESSION['proglang'])) {
    $_SESSION['proglang'] = 'da : Dansk';
}

// Hent den aktuelle sti med det samme
$current_url = $_SERVER['REQUEST_URI'];

// 3. --- AKTIV HARD TIMEOUT KONTROL (Kører kun hvis logget ind og ikke på login.php) ---
$max_inactivity = 43200; // 12 timers inaktivitet tilladt inden hårdt udsmid
if (isset($_SESSION['user_id']) && strpos($current_url, 'login.php') === false) {
    if (isset($_SESSION['last_activity'])) {
        $inactive_time = time() - $_SESSION['last_activity'];
        
        if ($inactive_time > $max_inactivity) {
            // Tving udsmidning
            $_SESSION = array();
            session_destroy();
            
            // Gem arbejdssiden i cookien inden vi dør
            if (!empty($current_url)) {
                $cookie_path = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
                setcookie('redirect_to', $current_url, time() + 3600, $cookie_path);
            }
            header("Location: login.php");
            exit;
        }
    }
    $_SESSION['last_activity'] = time(); // Opdater aktivitet ved gyldigt klik
}

// 4. --- LOGIN-KONTROL ---
if (strpos($current_url, 'login.php') !== false) {
    return; 
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] <= 0) {
    if (!empty($current_url)) {
        $cookie_path = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
        setcookie('redirect_to', $current_url, time() + 3600, $cookie_path);
    }
    header("Location: login.php");
    exit;
}

// 4a. --- DEAKTIVERET-KONTO-TJEK: denne fil har ALDRIG genslået den logget-ind bruger op i databasen efter selve
// login-øjeblikket - alt (rolle, niveau, brugernavn) kom udelukkende fra sessionsvariabler sat én gang ved login.
// En admin der ændrede en andens rolle, kodeord, eller (denne feature) deaktiverede kontoen, havde derfor INGEN
// effekt på en allerede aktiv session, som forblev fuldt funktionsdygtig indtil brugeren selv loggede ud.
require_once 'inc/db_connect.inc.php';
if (!isset($_SESSION['lang'])) $_SESSION['lang'] = tc_default_lang();      // (landepakkens sprog - ikke altid dansk)
$auth_has_is_active_col = db_has_column($conn, 'users', 'is_active');
// Kodeordet ændret siden login (fx nulstillet af en administrator efter et brud): sessionen er ikke længere gyldig.
// En session fra før denne kontrol får blot sit fingeraftryk sat første gang.
$auth_pw_row = DB::fetch_assoc(DB::query($conn, "SELECT password_hash FROM users WHERE user_id = " . (int)$_SESSION['user_id']));
$auth_pw_fp  = tc_pw_fingerprint((string)($auth_pw_row['password_hash'] ?? ''));
if (!isset($_SESSION['pw_fp'])) $_SESSION['pw_fp'] = $auth_pw_fp;
elseif (!$auth_pw_row || !hash_equals((string)$_SESSION['pw_fp'], $auth_pw_fp)) {
    $_SESSION = array();
    session_destroy();
    header("Location: login.php");
    exit;
}
if ($auth_has_is_active_col) {
    $auth_user_row = DB::fetch_assoc(DB::query($conn, "SELECT is_active FROM users WHERE user_id = " . (int)$_SESSION['user_id']));
    if (!$auth_user_row || (int)$auth_user_row['is_active'] === 0) {
        $_SESSION = array();
        session_destroy();
        header("Location: login.php?msg=account_disabled");
        exit;
    }
}
// ?Debug=true for en indlogget bruger - også på sider der indlæser db_connect.inc.php før denne fil (sessionen fandtes
// ikke endnu, da db_connect afgjorde om fejl måtte vises)
if (isset($_GET['Debug']) && $_GET['Debug'] === 'true' && !ini_get('display_errors')) {
    ini_set('display_errors', 1);
    $GLOBAL_DEBUG_ALERT = '<div style="background:red; color:white; padding:5px; position:fixed; bottom:0; right:0; z-index:9999; font-size:10px; opacity:0.7;">DEBUG ACTIVE</div>';
}
// RETTET (SIKKERHED): login'et er bundet til det regnskab det blev givet i - er et andet regnskab valgt i sessionen
// (Skift regnskab), er brugeren ikke logget ind dér. (En session fra før denne rettelse logges ud én gang.)
if ((string)($_SESSION['auth_account_id'] ?? '-') !== (string)($_SESSION['account_id'] ?? '')) {
    foreach (['user_id', 'user_name', 'user_level', 'real_user_level', 'user_role', 'auth_account_id'] as $k) unset($_SESSION[$k]);
    header("Location: login.php");
    exit;
}
// RETTET: en ændret rolle (fx en administrator nedgraderet til bruger) fik først virkning ved næste login -
// sessionen beholdt sine rettigheder i op til 4 timer. Rolle og niveau læses nu ved hver side; et midlertidigt
// sænket visningsniveau (?set_level=) bevares, men kan aldrig ligge over det nye niveau.
$auth_role_row = DB::fetch_assoc(DB::query($conn, "SELECT user_role, user_level FROM users WHERE user_id = " . (int)($_SESSION['user_id'] ?? 0)));
if ($auth_role_row) {
    $auth_db_level = (int)$auth_role_row['user_level'];
    $auth_real     = (int)($_SESSION['real_user_level'] ?? $auth_db_level);
    if ($auth_db_level !== $auth_real || (string)($_SESSION['user_role'] ?? '') !== (string)$auth_role_row['user_role']) {
        $auth_cur = (int)($_SESSION['user_level'] ?? $auth_db_level);
        $_SESSION['user_level']      = ($auth_cur >= $auth_real) ? $auth_db_level : min($auth_cur, $auth_db_level);
        $_SESSION['real_user_level'] = $auth_db_level;
        $_SESSION['user_role']       = (string)$auth_role_row['user_role'];
    }
}

// 4b. --- CSRF-BESKYTTELSE (kun POST, kun for logget-ind brugere) ---
// RETTET: fandtes slet ikke noget sted i appen - bekræftet ved en fuld projekt-gennemsøgning. En ondsindet side
// kunne derfor få en indlogget brugers browser til automatisk at indsende en formular til en hvilken som helst
// POST-side i TinyCash (ændre firma-indstillinger, oprette en admin-bruger, slette en konto...) uden brugerens
// vidende - SameSite=Lax beskytter kun mod passive tredjeparts-anmodninger (img/iframe/fetch), ikke mod at offeret
// narres til at klikke et link eller en auto-indsendt formular på en ekstern side.
// RETTET: en forespørgsel større end post_max_size (fx et stort bilag) kommer frem med en TOM $_POST - så manglede
// CSRF-nøglen, og brugeren fik "Sikkerhedstjekket mislykkedes (CSRF)" i stedet for at få at vide, at filen var for stor.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $tc_back = (string)($_SERVER['HTTP_REFERER'] ?? '');
    $tc_back = (parse_url($tc_back, PHP_URL_HOST) === ($_SERVER['HTTP_HOST'] ?? '') || parse_url($tc_back, PHP_URL_HOST) === parse_url('http://' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST)) ? $tc_back : 'index.php';
    redirect($tc_back, sprintf(lang('@The upload was too large (the maximum is %s) - nothing was saved.'), ini_get('post_max_size')), 'error');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_verify()) {
    http_response_code(403);
    die(lang('@Security check failed (CSRF). Please reload the page and try again.'));
}
// Handlinger der startes af et LINK kommer som POST (htm_Header()'s tcPost) - en handling som GET afvises
// altid, også med csrf_token i URL'en. Se csrf_get_actions()/csrf_action_by_name() i inc/php2htm.lib.php.
if (csrf_get_is_action()) {
    http_response_code(403);
    die(lang('@Security check failed (CSRF). Please reload the page and try again.'));
}
// Et link sendt som POST (nøglen er tjekket ovenfor) behandles som den GET det var: handlings-scriptet
// læser stadig $_GET, og en side der også har en formular, tager det ikke for en indsendt formular.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['_tc_link'])) {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_POST = [];
    $_REQUEST = $_GET;
}

// 5. --- BRUGER-NIVEAU KONTROL ---
// RETTET (§bugs-batch-16-review): fallback-værdien var 2, ikke 1 - en session
// hvor user_level af en eller anden grund aldrig blev sat (fx et login-flow
// der endnu ikke er nået frem til at kopiere det fra databasen, eller en
// fremtidig tilsvarende write-side-fejl som de flere gange fundne
// user_level-udeladelser i user_create.php/user_edit.php/
// inc/user_create_admin.php) ville stiltiende få niveau 2 - som allerede har
// adgang til hele "Regnskab"/"System"-menugruppen (se
// get_menu_visibility_defaults() i inc/menu.inc.php), IKKE kun den sikreste,
// mest restriktive standard. Fail-safe skal altid være det LAVESTE niveau,
// samme standardværdi som users.user_level-kolonnen selv bruger.
$uLev = $_SESSION['user_level'] ?? 1;

if (isset($rLev) && $uLev < $rLev) {
    deny_access_gracefully();
}

// Central funktion til at afvise adgang med bevaret menu og design
function deny_access_gracefully() {
    if (ob_get_length()) ob_clean();
    
    if (!function_exists('showMenu')) {
        require_once 'inc/menu.inc.php';
    }
    
    htm_Header(lang('@Access Denied'));
    showMenu();
    
    htm_Card_(lang('@Access Denied'), 600, '', 'access_error', false);
    echo '<div style="text-align:center; padding:20px;">';
    echo '<i class="fa fa-exclamation-triangle" style="font-size:48px; color:#e74c3c; margin-bottom:15px;"></i>';
    echo '<p style="font-size:1.2em; color:#555; margin-bottom:25px;">' . lang('@Your user level is not high enough to view this page.') . '</p>';
    htm_Button('fa-arrow-left', '@Back to Dashboard', 'primary', 'sales_hub.php', '', 'data-hint="'.lang('@Return to the main dashboard').'"', '', true);
    echo '</div>';
    htm_Card_end();
    
    htm_Footer();
    exit;
}

// Fælles afvisning af en side, der hører til et lands regler (momsangivelse, OIOUBL, SAF-T DK ...), når den valgte
// landepakke ikke har den - eller bogføringsvalutaen ikke er landets egen.
// $feature: se tc_pack_feature() i inc/country.inc.php - landepakken afgør, om siden findes for virksomhedens land.
function require_country_feature($conn, string $feature) {
    if (tc_pack_feature($feature)) return;
    $base = strtoupper(get_settings($conn)['currency'] ?? 'DKK');

    if (ob_get_length()) ob_clean();
    if (!function_exists('showMenu')) {
        require_once 'inc/menu.inc.php';
    }

    htm_Header(lang('@Access Restricted'));
    showMenu();

    htm_Card_(lang('@Access Restricted'), 600, '', 'access_error', false);
    echo '<div style="text-align:center; padding:20px;">';
    echo '<i class="fa fa-flag" style="font-size:48px; color:#e74c3c; margin-bottom:15px;"></i>';
    echo '<p style="font-size:1.2em; color:#555; margin-bottom:10px;">' . lang('@This feature follows the tax and bookkeeping rules of another country, or needs the country\'s own currency as base currency.') . '</p>';
    echo '<p style="font-size:0.95em; color:#888; margin-bottom:25px;">' . sprintf(lang('@Your company is set up with the country %s and %s as its base currency (Company Settings).'), htmlspecialchars((string)tc_country_pack('name', '')), htmlspecialchars($base)) . '</p>';
    htm_Button('fa-arrow-left', '@Back to Dashboard', 'primary', 'sales_hub.php', '', 'data-hint="'.lang('@Return to the main dashboard').'"', '', true);
    echo '</div>';
    htm_Card_end();

    htm_Footer();
    exit;
}
