<?php # /inc/auto_backup.inc.php v:1.3.1 d:2026-09-15 i:evs
# gendannelsesvejledning i backup-mailen nævner nu det indbyggede offline-dekrypteringsværktøj før openssl-kommandoen
# Automatisk krypteret backup: gemmes ALTID lokalt i backups/ (AUTO_BACKUP_*, nyeste 8 beholdes); mail er valgfri off-site-kopi
# Bruger DB::dump_to_sql() og DB::is_sqlite() fra db_connect.inc.php
# Udløses når: 7+ dage (mindst ugentligt, jf. bogføringsloven) siden sidste backup OG ændringer siden da
# v1.3.0: PHPMailer's $mail->Timeout stod på sin egen standard (300 sek.) -
# da denne funktion køres synkront i htm_Footer() på HVER sidevisning, kunne
# en langsom/uopnåelig SMTP-server hænge en helt almindelig side i op til 5
# minutter. Sat eksplicit til 15 sekunder.

function auto_backup_check($conn) {
    global $db_type, $pdo, $db_settings;
    if (!$conn) return;

    // ── 1. Tjek interval ──────────────────────────────────────────────────────
    $last_ts = (int)(get_settings($conn)['auto_backup_last'] ?? 0);

    if ((time() - $last_ts) / 86400 < 7) return;

    // ── 2. Er der ændringer siden seneste backup? ─────────────────────────────
    $last_dt = date('Y-m-d H:i:s', $last_ts ?: 0);
    $changed = false;

    $last_db = db_ts_param($last_dt);      // log_date / created_at er databasens egen tid
    $chk = @DB::query($conn, "SELECT COUNT(*) FROM audit_log WHERE log_date > '$last_db'");
    if ($chk) { $r = DB::fetch_row($chk); if ((int)$r[0] > 0) $changed = true; }

    // RETTET: loopet inkluderede FØR også 'invoices' og 'transactions'. 'invoices' har slet ingen
    // created_at-kolonne, så den forespørgsel fejlede tavst (DB::query returnerer false, sunket af @-operatoren) -
    // en ny faktura oprettet uden om expenses/journal blev derfor aldrig opdaget som "ændring", MEDMINDRE den også
    // blev logget til audit_log (nu rettet direkte ved kilden i invoice_edit.php, se CREATE_DRAFT_INVOICE).
    if (!$changed) {
        foreach (['expenses', 'journal'] as $tbl) {
            $chk2 = @DB::query($conn, "SELECT COUNT(*) FROM $tbl WHERE created_at > '$last_db'");
            if ($chk2) { $r2 = DB::fetch_row($chk2); if ((int)$r2[0] > 0) { $changed = true; break; } }
        }
    }

    if (!$changed) {
        _ab_save($conn, 'auto_backup_last', time());
        return;
    }

    // ── 3. Hent indstillinger ─────────────────────────────────────────────────
    $s       = [];
    $set_res = @DB::query($conn, "SELECT setting_key, setting_value FROM settings");
    while ($row = DB::fetch_assoc($set_res)) { $s[$row['setting_key']] = $row['setting_value']; }

    // RETTET (samme fund som fejlmeddelelsen nedenfor): backup-destinations-mailen konfigureres på backup.php ("🤖
    // Automatisk Backup"-sektionen), IKKE i Firmaindstillinger - denne kommentar sagde stadig det gamle, forkerte
    // sted. Selve SMTP-afsenderen kommer fra appens centrale mail-konfiguration (inc/mail_config.inc.php -> MAIL_*
    // fra env.ini), samme kilde som al anden udgående post i systemet.
    $backup_mail  = trim($s['auto_backup_mail'] ?? '');
    $company_name = trim($s['company_name']     ?? 'TinyCash');

    // Master-kodeordet læses fra env.ini [backup_config] - ALDRIG fra databasen,
    // så det ikke lækker i en ukrypteret regnskabs-backup. Overgangs-fallback til
    // den gamle settings-placering, så eksisterende opsætning ikke pludselig
    // sender ukrypteret før nøglen er flyttet til env.ini.
    $backup_pass = _ab_master_password();
    if ($backup_pass === '') {
        $backup_pass = trim($s['auto_backup_password'] ?? '');
    }

    require_once __DIR__ . '/mail_config.inc.php';

    // RETTET: disse to grene glemte at gemme auto_backup_last, i modsætning til "ingen ændringer"-grenen ovenfor.
    // Ingen af de berørte tabeller har noget indeks på de filtrerede kolonner (se migrate_auto_backup_indexes.php)
    // - fulde tabel-scanninger på hver sidevisning, værre jo mere bogføringshistorik der er.
    // ÆNDRET: en manglende backup-mailadresse eller SMTP-opsætning må IKKE længere afbryde backuppen. Tidligere
    // sprang funktionen helt fra uden mail, så en installation uden mail-opsætning havde slet ingen automatisk
    // backup (netop den gap bogføringslovens ugentlige backup-krav skal lukke).
    $can_mail = ($backup_mail !== '') && defined('MAIL_HOST') && MAIL_HOST !== '';

    // ── 4. Byg ZIP ───────────────────────────────────────────────────────────
    if (!class_exists('ZipArchive')) {
        _ab_log($conn, 'Auto backup: PHP ZipArchive-extension er ikke aktiveret');
        _ab_save($conn, 'auto_backup_last', time());
        return;
    }

    $tmp_dir    = rtrim(sys_get_temp_dir(), '/') . '/';
    $date_stamp = date('Y-m-d_His');
    $is_sqlite  = DB::is_sqlite();
    $engine     = $is_sqlite ? 'sqlite' : 'mysql';
    $zip_file   = $tmp_dir . 'tc_backup_' . $date_stamp . '.zip';

    $zip = new ZipArchive();
    if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        _ab_log($conn, 'Auto backup: kunne ikke oprette midlertidig ZIP-fil i ' . $tmp_dir);
        _ab_save($conn, 'auto_backup_last', time());
        return;
    }

    // Database-dump via den eksisterende DB::dump_to_sql()
    $sql_dump = DB::dump_to_sql($conn);
    $dump_filename = $is_sqlite ? 'tinycash_sqlite.sql' : 'tinycash_mysql.sql';
    $zip->addFromString($dump_filename, $sql_dump);

    // Ved SQLite: inkluder også den rå .sqlite-fil for komplet gendannelse
    if ($is_sqlite) {
        $db_path = $db_settings['DB_PATH'] ?? 'data/tinycash.sqlite';
        $db_abs  = realpath(__DIR__ . '/' . $db_path)
                 ?: realpath(__DIR__ . '/../' . $db_path);
        if ($db_abs && file_exists($db_abs)) {
            $zip->addFile($db_abs, 'tinycash.sqlite');
        }
    }

    // Uploads (kvitteringer og bilag). Rekursivt (RecursiveIteratorIterator,
    // samme mønster som full_project_backup.php) i stedet for det tidligere
    // glob('*')+is_file() - et almindeligt glob('*') matcher ikke ind i
    // undermapper, så filer i en eventuel fremtidig undermappe-struktur under
    // uploads/ ville stille springes over uden varsel. getSubPathName()
    // returnerer OS-native separator (backslash på Windows) - normaliseres
    // til forward slash, ellers giver en Linux-udpakning bagefter én flad
    // fil med et bogstaveligt backslash i navnet i stedet for en rigtig
    // undermappe (bekræftet direkte for storage/ nedenfor, som rent faktisk
    // har undermapper - uploads/ har det ikke i praksis her, men samme
    // fejlklasse gælder kodemæssigt).
    $uploads_dir = __DIR__ . '/../uploads/';
    if (is_dir($uploads_dir)) {
        $items = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploads_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($items as $item) {
            if ($item->isFile()) $zip->addFile($item->getRealPath(), 'uploads/' . str_replace('\\', '/', $items->getSubPathName()));
        }
    }

    // Storage (voucher_depot/einvoices/saf-t) - manglede FØR helt fra den
    // automatiske off-site backup, samme fund som i full_project_backup.php/
    // backup_restore_worker.php. Fundet ved en backup-/gendannelsesgennemgang.
    $storage_dir = __DIR__ . '/../storage/';
    if (is_dir($storage_dir)) {
        $items = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($storage_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($items as $item) {
            if ($item->isFile()) $zip->addFile($item->getRealPath(), 'storage/' . str_replace('\\', '/', $items->getSubPathName()));
        }
    }

    // JSON-data (sprogfiler, hjælpesystem, kontoplan-skabeloner, inkl. json-data/languages/'s AI-genererede
    // hjælpesystem-oversættelser) - manglede FØR helt fra denne backup, i modsætning til
    // full_project_backup.php/backup_system.php, som nu begge er rettet til at tage hele mappen med rekursivt.
    $json_dir = __DIR__ . '/../json-data/';
    if (is_dir($json_dir)) {
        $items = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($json_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($items as $item) {
            if ($item->isFile() && strtolower($item->getExtension()) === 'json') {
                $zip->addFile($item->getRealPath(), 'json-data/' . str_replace('\\', '/', $items->getSubPathName()));
            }
        }
    }

    // Program-backup (kildekode + DB-struktur) foldes ind under program/, så den
    // automatiske ugentlige backup er én samlet backup af BÅDE data og program.
    require_once __DIR__ . '/program_backup.lib.php';
    program_backup_add_to_zip($zip, $conn, 'program/');

    // Info-fil
    $zip->addFromString('backup_info.txt',
        "TinyCash Auto Backup\n" .
        "Dato:    " . date(CONF_DATE_FORMAT . ' H:i:s') . "\n" .
        "Motor:   " . strtoupper($engine) . "\n" .
        "Firma:   " . $company_name . "\n" .
        "Version: " . (defined('APP_VERSION') ? APP_VERSION : '?') . "\n"
    );
    $zip->close();

    // ── 5. Krypter med AES-256-CBC (OpenSSL-kompatibelt format) ──────────────
    // Filformatet er PRÆCIS det openssl's kommandolinje selv laver og læser:
    //   "Salted__" + 8-byte salt + ciffertekst
    // Nøgle+IV udledes med PBKDF2-HMAC-SHA256 (10.000 iterationer) af master-
    // kodeordet + saltet - identisk med `openssl enc -pbkdf2 -md sha256`. Derved
    // kan backuppen dekrypteres med ÉT standard openssl-kald på en hvilken som
    // helst maskine i en katastrofe, uden TinyCash-koden. Master-kodeordet
    // sendes ALDRIG i mailen - kun brugeren kender det (se mail-body nedenfor).
    $encrypted = false;
    $send_file = $zip_file;

    if (function_exists('openssl_encrypt') && !empty($backup_pass)) {
        $enc_file  = $zip_file . '.enc';
        $salt      = random_bytes(8);
        $key_iv    = hash_pbkdf2('sha256', $backup_pass, $salt, 10000, 48, true); // 32 nøgle + 16 IV
        $key       = substr($key_iv, 0, 32);
        $iv        = substr($key_iv, 32, 16);
        $zip_data  = file_get_contents($zip_file);
        $cipher    = openssl_encrypt($zip_data, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($cipher !== false) {
            file_put_contents($enc_file, "Salted__" . $salt . $cipher);
            @unlink($zip_file);
            $send_file = $enc_file;
            $encrypted = true;
        }
    }

    // ── 5b. Gem ALTID en lokal kopi i backups/ ────────────── Dette er nu backuppens primære resultat; mailen
    // nedenfor er kun en valgfri off-site-kopi. backups/ er beskyttet mod web-adgang (backups/.htaccess "Deny from
    // all"), så selv en ukrypteret fallback ikke kan hentes via HTTP.
    $local_saved = false;
    $backups_dir = __DIR__ . '/../backups/';
    if (!is_dir($backups_dir)) { @mkdir($backups_dir, 0755, true); }
    $local_ext   = $encrypted ? '.zip.enc' : '.zip';
    // Flere regnskaber deler backups/: regnskabets id i navnet (det første regnskab som før), og oprydningen tæller
    // kun regnskabets egne - før slettede ét regnskabs backups et andets, og ingen kunne se, hvilket regnskab de var
    $ab_acct     = rtrim(tc_account_storage_subdir(), '/');
    $local_path  = $backups_dir . 'AUTO_BACKUP_' . ($ab_acct !== '' ? $ab_acct . '_' : '') . $date_stamp . '_' . $engine . $local_ext;
    if (is_dir($backups_dir) && @copy($send_file, $local_path)) {
        $local_saved = true;
        $now = time();
        _ab_save($conn, 'auto_backup_last', $now);
        _ab_save($conn, 'last_backup_time', $now);
        // Ingen fejl når den lokale kopi er lavet - en manglende master-nøgle er
        // dog værd at påpege, da fallback-kopien så ligger ukrypteret.
        _ab_save($conn, 'auto_backup_error', $encrypted ? '' :
            'Automatisk backup gemt lokalt UKRYPTERET - sæt et master-kodeord under System -> Vedligeholdelse -> Backup-administration -> Automatisk Backup for at kryptere den.');
        // Behold kun de nyeste N automatiske lokale kopier (ikke manuelle backups).
        _ab_prune_local($backups_dir, 8, $ab_acct);
    } else {
        _ab_log($conn, 'Auto backup: kunne ikke gemme lokal kopi i ' . $backups_dir);
        _ab_save($conn, 'auto_backup_last', time());
    }

    // Uden mail-/SMTP-opsætning er vi færdige her - den lokale kopi er lavet.
    if (!$can_mail) {
        @unlink($send_file);
        return;
    }

    // ── 6. Send mail via PHPMailer (valgfri off-site-kopi) ───────────────────
    // Samme PHPMailer-installation som resten af systemet (inc/phpmailer/).
    $mailer_path = null;
    foreach ([
        __DIR__ . '/phpmailer/',
        __DIR__ . '/../vendor/phpmailer/phpmailer/src/',
        __DIR__ . '/PHPMailer/src/',
    ] as $p) {
        if (file_exists($p . 'PHPMailer.php')) { $mailer_path = $p; break; }
    }

    if (!$mailer_path) {
        // Den lokale kopi er allerede gemt ovenfor; kun off-site-mailen springes over.
        _ab_log($conn, 'Auto backup: PHPMailer ikke fundet — lokal kopi gemt, men ingen off-site-mail sendt');
        @unlink($send_file);
        return;
    }

    require_once $mailer_path . 'Exception.php';
    require_once $mailer_path . 'PHPMailer.php';
    require_once $mailer_path . 'SMTP.php';

    $attach_ext  = $encrypted ? '.zip.enc' : '.zip';
    $attach_name = 'tinycash_backup_' . $date_stamp . '_' . $engine . $attach_ext;

    $enc_info = $encrypted
        ? "Kryptering:  AES-256-CBC (PBKDF2-SHA256, 10.000 iterationer)\n" .
          "Kodeord:     Dit MASTER-kodeord. Det sendes ALDRIG i denne mail - kun du kender det.\n"
        // RETTET: pegede FØR på "Firmaindstillinger -> Automatisk backup" - den sektion er flyttet til backup.php,
        // så denne henvisning (som står i selve gendannelses-mailen, afsendt under et rigtigt uheld) pegede stille
        // på et sted, hvor indstillingen ikke længere findes.
        : "Kryptering:  INGEN - sæt et master-kodeord i System -> Vedligeholdelse -> Backup-administration -> Automatisk Backup.\n";

    // Nemmeste metode nævnes først: det indbyggede offline-dekrypteringsværktøj
    // (backup_decrypt_offline.html) kører 100% i browseren, kræver ingen
    // terminal/openssl, og virker uden serverforbindelse hvis filen er gemt
    // lokalt på forhånd - det er præcis den situation, en gendannelses-mail
    // er skrevet til (se backup.php's egen boks om samme værktøj). openssl-
    // kommandoen bevares som teknisk alternativ for dem der foretrækker det.
    $decrypt_tool_note = "Nemmeste metode - indbygget dekrypteringsværktøj (ingen terminal nødvendig):\n" .
        "   Åbn \"backup_decrypt_offline.html\" (i TinyCash under System -> Maintenance ->\n" .
        "   Backup Management -> Offline Decryption Tool). Kører fuldstændigt i browseren - gem\n" .
        "   filen på din egen computer i forvejen, så den også virker hvis serveren er nede.\n" .
        "   Indtast dit master-kodeord og vælg $attach_name direkte i værktøjet.\n\n" .
        "Alternativ metode - via terminal (openssl):\n";

    // Erstat DIT_MASTER_KODEORD med dit eget. -md sha256 gør nøgleudledningen entydig.
    $restore_sqlite = $decrypt_tool_note . "1. Dekrypter (indtast dit master-kodeord):\n   openssl enc -d -aes-256-cbc -pbkdf2 -md sha256 -in $attach_name -out backup.zip -pass pass:DIT_MASTER_KODEORD\n2. Udpak ZIP og erstat tinycash.sqlite på serveren.\n";
    $restore_mysql  = $decrypt_tool_note . "1. Dekrypter (indtast dit master-kodeord):\n   openssl enc -d -aes-256-cbc -pbkdf2 -md sha256 -in $attach_name -out backup.zip -pass pass:DIT_MASTER_KODEORD\n2. Udpak ZIP og importer tinycash_mysql.sql:\n   mysql -u BRUGER -p DATABASE < tinycash_mysql.sql\n";

    $body =
        "Automatisk backup fra " . $company_name . "\n\n" .
        "Dato:        " . date(CONF_DATE_FORMAT . ' H:i') . "\n" .
        "Database:    " . strtoupper($engine) . "\n" .
        $enc_info . "\n" .
        "--- Gendannelsesvejledning ---\n" .
        ($is_sqlite ? $restore_sqlite : $restore_mysql) . "\n" .
        "Denne mail er sendt automatisk af TinyCash.\n";

    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = (MAIL_PORT == 465) ? 'ssl' : 'tls';
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';
        // Kort, eksplicit timeout: dette kald kører synkront inde i hver
        // sidevisnings htm_Footer() (via auto_backup_check()) - uden denne
        // falder PHPMailer tilbage til sin egen standard på 300 sekunder,
        // så en langsom/uopnåelig SMTP-server kan hænge EN HELT SIDE i op
        // til 5 minutter i stedet for at fejle hurtigt og blive logget.
        $mail->Timeout    = 15;
        $mail->setFrom(MAIL_FROM, $company_name . ' Backup');
        $mail->addAddress($backup_mail);
        $mail->Subject    = '[TinyCash] Automatisk backup — ' . $company_name . ' — ' . date(CONF_DATE_FORMAT);
        $mail->Body       = $body;
        $mail->addAttachment($send_file, $attach_name);
        $mail->send();

        // Gem succes-status
        $now = time();
        _ab_save($conn, 'auto_backup_last', $now);
        _ab_save($conn, 'last_backup_time', $now);
        _ab_save($conn, 'auto_backup_error', '');

    } catch (Exception $e) {
        _ab_log($conn, 'Auto backup: lokal kopi gemt, men off-site-mail fejlede: ' . $e->getMessage());
        // Vigtigst af alle disse tidsstempel-rettelser: uden den ville en vedvarende SMTP-fejl (forkert login,
        // uopnåelig server) genopbygge HELE ZIP'en på hver eneste sidevisning, ikke bare køre de lette
        // COUNT(*)-tjek fra
        _ab_save($conn, 'auto_backup_last', time());
    }

    @unlink($send_file); // Ryd krypteret fil fra server
}

// ── Hjælpefunktioner ─────────────────────────────────────────────────────────
function _ab_save($conn, $key, $value) {
    global $db_type;
    $safe_val = DB::real_escape_string($conn, (string)$value);
    $safe_key = DB::real_escape_string($conn, $key);
    $sql = $db_type === 'sqlite'
        ? "INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES ('$safe_key', '$safe_val')"
        : "INSERT INTO settings (setting_key, setting_value) VALUES ('$safe_key', '$safe_val') ON DUPLICATE KEY UPDATE setting_value = '$safe_val'";
    @DB::query($conn, $sql);
}

function _ab_log($conn, $msg) {
    _ab_save($conn, 'auto_backup_error', $msg);
    error_log('[TinyCash Auto Backup] ' . $msg);
}

// Oprydning: behold kun de $keep nyeste AUTOMATISKE lokale backups i backups/.
// Rører ALDRIG manuelle backups (FULL_BACKUP_*/TinyCash_Backup_* o.l.) - kun de
// filer denne funktion selv lægger (AUTO_BACKUP_*). Filnavnets Y-m-d_His-stempel
// sorterer kronologisk, så en almindelig sort() giver ældste først.
function _ab_prune_local($dir, $keep, string $acct = '') {
    $re = $acct === '' ? '/^AUTO_BACKUP_\d{4}-\d\d-\d\d_/' : '/^AUTO_BACKUP_' . preg_quote($acct, '/') . '_\d{4}-\d\d-\d\d_/';
    $files = array_values(array_filter(glob(rtrim($dir, '/') . '/AUTO_BACKUP_*') ?: [], fn($f) => preg_match($re, basename($f))));
    if (count($files) <= $keep) return;
    sort($files);
    foreach (array_slice($files, 0, count($files) - $keep) as $old) {
        @unlink($old);
    }
}

// Master-kodeordet til backup-kryptering hentes fra env.ini [backup_config],
// IKKE fra databasen - så det ikke havner i database-dumps eller nogen backup.
// RETTET: env.ini flyttet til inc/data/env.ini - gammel sti bevaret som
// bagudkompatibel fallback (se db_connect.inc.php's $SøgeStier).
function _ab_master_password() {
    $ini = @parse_ini_file(__DIR__ . '/data/env.ini', true) ?: @parse_ini_file(__DIR__ . '/env.ini', true);
    return (is_array($ini) && isset($ini['backup_config']['BACKUP_PASSWORD']))
        ? trim($ini['backup_config']['BACKUP_PASSWORD'])
        : '';
}

// ── Mangler real_escape_string på DB-klassen? Tilføj her som fallback ────────
if (!method_exists('DB', 'real_escape_string')) {
    // Allerede defineret i db_connect.inc.php som DB::escape() — brug den
}
