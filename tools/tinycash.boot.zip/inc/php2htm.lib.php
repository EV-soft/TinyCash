<?php # /inc/php2htm.lib.php v:1.3.1 d:2026-09-15 i:evs
# htm_InputGroup omdøbt til htm_Field i hele projektet, på brugerens ønske
# Inkluder de centraliserede hjælpemoduler.
# core_utils.lib.php rummer lang() og andre ikke-HTML-byggende funktioner
# (clean_address_text, get_tc_doc, resolve_doc_path). Skal inkluderes FØR
# alt herunder, da stort set alle htm_*-funktioner kalder lang().
include_once __DIR__ . '/help.lib.php';
include_once __DIR__ . '/core_utils.lib.php';
include_once __DIR__ . '/htm_page.lib.php'; # HEADER & FOOTER

# QUICK MENU
function htm_QuickMenu() {
    ?>
    <div class="quick-actions">
        <a href="account_edit.php?id=0" class="qa-btn qa-account" data-hint="<?php echo lang('@Create a new account in the chart of accounts'); ?>"><i class="fa fa-plus-circle"></i> <span><?php echo lang('@Account'); ?></span></a>
        <a href="expense_edit.php?id=0" class="qa-btn qa-expense" data-hint="<?php echo lang('@Register a new expense or purchase'); ?>"><i class="fa fa-minus-circle"></i> <span><?php echo lang('@Expense'); ?></span></a>
        <a href="invoice_edit.php?id=0" class="qa-btn qa-invoice" data-hint="<?php echo lang('@Create a new invoice'); ?>"><i class="fa fa-file-invoice-dollar"></i> <span><?php echo lang('@Invoice'); ?></span></a>
    </div>
    <?php
}



# INPUT GROUP htm_Field()
function htm_Field($icon, $labl, $name, $valu='', $type='text', $opti=null, $extr='', $wdth='100%', $hint='', $plho='', $legd='', $echo=true) {
    $is_bare = (strpos($extr, 'bare') !== false || strpos($legd, 'bare') !== false);
    if ($is_bare && $type === 'sele' && is_array($opti)) {
        $bare_style = '';
        $clean_extr = $extr;
        if (preg_match('/style=["\']([^"\']+)["\']/', $extr, $style_match)) {
            $bare_style = $style_match[1];
            $clean_extr = preg_replace('/style=["\']([^"\']+)["\']/', '', $extr);
        }
        $clean_extr = trim(str_replace('bare', '', $clean_extr));
        $h = '<select name="'.$name.'" id="'.$name.'" style="'.$bare_style.'" '.$clean_extr.'>';
        foreach ($opti as $k => $v) {
            $sel = ((string)$valu === (string)$k) ? 'selected' : '';
            $h .= '<option value="'.htmlspecialchars((string)$k).'" '.$sel.'>'.htmlspecialchars((string)$v).'</option>';
        }
        $h .= '</select>';
        if (!$echo) return $h;
        echo $h;
        return;
    }

    if (!$echo) ob_start();
    static $id_counter = 0;
    $id_counter++;
    $unique_id = str_replace(array('[]', '[', ']'), '_', $name) . $id_counter;

    $translated_label = lang($labl);
    $english_reference = ltrim($labl, '@');

    $outer_hint_attr = '';
    $legend_hint_attr = '';

    $current_lang = strtolower(isset($_SESSION['lang']) ? $_SESSION['lang'] : 'da');
    $show_english_fallback = ($current_lang !== 'en' && strtolower($translated_label) !== strtolower($english_reference));

    if ($hint > '') {
        $clean_hint = str_replace(array('<br>', '<br />', '<br/>'), "\n", lang($hint));
        if ($show_english_fallback) {
            $clean_hint .= "\n\n(English: " . $english_reference . ")";
        }
        $outer_hint_attr = ' data-hint="'.htmlspecialchars($clean_hint, ENT_QUOTES).'"';
        // RETTET - $hint sad FØR kun på selve <div>/<fieldset>, aldrig direkte på <legend>. Et hover over
        // caption-teksten BURDE i teorien allerede ramme det via closest([data-hint]) op til <fieldset>, men
        // <legend> har en særlig, ikke-standard boksmodel (den "stikker hul" i fieldset'ets kant) som ikke alle
        // browsere hit-tester ens - data-hint lægges derfor nu direkte på <legend> også, så det aldrig afhænger af
        // den opførsel.
        $legend_hint_attr = $outer_hint_attr;
    }
    elseif ($show_english_fallback) {
        $legend_hint_attr = ' data-hint="'.htmlspecialchars("English: " . $english_reference, ENT_QUOTES).'"';
    }

    if (empty($translated_label)) {
        $translated_label = $english_reference;
    }

    if (strpos(' '.$extr, 'dash') > 0) { $bord = 'border: 2px dashed blue;'; } 
    elseif (strpos(' '.$extr, 'required') > 0) { $bord = 'border: 2px solid orange;'; } 
    else { $bord = ''; }
    
    // RETTET: der stod bogstaveligt "..." her - formentlig et glemt/ufuldendt tilføjelse. Uden en eksplicit
    // min-width kan et fieldset-element ikke krympe under sit eget indholds intrinsiske minimumsbredde (en
    // velkendt, ikke-standard browser-kvirk) - når flere htm_Field-felter sidder i en display:flex-række med for
    // lidt plads (fx et filterformular med 4+ felter), krymper den ydre boks her korrekt via flex-shrink, men
    // fieldset'et INDENI nægter at følge med og flyder derfor ud over sin egen boks ind over naboen - "min-width:
    // 0;" er den etablerede, veldokumenterede rettelse for netop dette (tillader hele flex-item-kæden at krympe
    // reelt).
    $h = '<div'.$outer_hint_attr.' style="display:inline-block; width:'.$wdth.'; min-width: 0;">';
    // min-width:0 også her - selve fieldset-elementet er hvor browserens
    // "min-width:min-content"-standardstil reelt sidder (se kommentaren
    // ved den ydre div ovenfor); uden den her ville den ydre div godt
    // kunne krympe, mens fieldset'et indeni stadig nægtede at følge med.
    $h .= '<fieldset'.$outer_hint_attr.' style="border-radius:8px; margin:2px; border:1px solid var(--border-fieldset); background-color: var(--bg-card); min-width: 0; box-sizing: border-box; '.$bord.' padding:5px 10px;">';

    if ($labl) { 
        $i_h = $icon ? '<i class="fa '.$icon.'" style="margin-right:5px; color: var(--color-primary);"></i> ' : '';

        $align = 'right'; 
        if (strpos($extr, 'leg:left') !== false || strpos($legd, 'leg:left') !== false) {
            $align = 'left';
        } elseif (strpos($extr, 'leg:center') !== false || strpos($legd, 'leg:center') !== false) {
            $align = 'center';
        } elseif (strpos($extr, 'leg:right') !== false || strpos($legd, 'leg:right') !== false) {
            $align = 'right';
        } 
        else {
            if (strpos($extr, 'align-left') !== false || strpos($legd, 'align-left') !== false) $align = 'left';
            if (strpos($extr, 'align-center') !== false || strpos($legd, 'align-center') !== false) $align = 'center';
        }

        $clean_legd = str_replace(array('align-left', 'align-center'), '', $legd);

        $centering_css = ($align == 'center') ? 'margin-left:auto; margin-right:auto; float:none; display:table;' : '';
        $align_css = 'text-align: ' . $align . ';';

        // RETTET - <legend> krymper som udgangspunkt til nøjagtig tekstens egen bredde, så selve
        // hover-/hint-fladen stopper brat lige efter sidste bogstav. Ekstra padding-right giver et bredere, mere
        // tilgivende hover-mål uden at ændre selve tekstens visuelle placering (venstre-/center-/højre-justeringen
        // ovenfor er uændret, kun selve boksen er bredere).
        $h .= '<legend'.$legend_hint_attr.' style="font-size:0.85rem; padding:2px 5px; color: var(--text-muted); margin:0; '. $align_css . $centering_css . $clean_legd . '">' . $i_h . $translated_label . '</legend>';
    }

    $p_a = ($plho !== '') ? " placeholder='".htmlspecialchars(lang($plho), ENT_QUOTES)."'" : '';

    // RETTET: border:none skal have !important her, ellers overtrumfes den af den globale "input, select, textarea
    // { border: 1px solid var(--border-color) !important; }"-regel i htm_page.lib.php (htm_Header) - uden dette
    // vises der en synlig kant BÅDE på selve feltet og på fieldset'et udenom (dobbelt-ramme). CSS-reglen er: en
    // !important-stylesheet-regel vinder over en inline style UDEN !important, selvom inline normalt har højere
    // specificitet.
    $s = 'width:100%; border:none !important; outline:none; background:transparent; font-family:inherit; font-size:1.1rem; margin:0; display:block; color:inherit;';

    if (preg_match('/style=["\']([^"\']+)["\']/', $extr, $style_match)) {
        $s .= ' ' . rtrim($style_match[1], ';') . ';';
        $extr = preg_replace('/style=["\']([^"\']+)["\']/', '', $extr);
    }

    $clean_extr = str_replace(array('leg:left', 'leg:center', 'leg:right', 'align-left', 'align-center'), '', $extr);

    if ($type == 'view' || $type == 'raw') { 
        $h .= '<div style="'.$s.' font-weight:bold; min-height:1.2em; color: var(--text-main); box-sizing: border-box;">'.($valu ? $valu : '&nbsp;').'</div>'; 
    } elseif ($type == 'sele' && is_array($opti)) {
        $h .= '<select name="'.$name.'" id="'.$unique_id.'" style="'.$s.'" '.$clean_extr.'>';
        // RETTET (SIKKERHED, stored XSS): værdi og tekst blev skrevet UESCAPET (kun den etiketløse variant ovenfor
        // escapede) - et brugernavn fra et mislykket loginforsøg ("<script>...") i loginhistorikkens valgliste, eller
        // et kundenavn fra en webbutiksordre i fakturaens kundeliste, kørte som script i en indlogget brugers browser.
        // Eksisterende entiteter (&nbsp; o.l.) bevares (double_encode = false).
        foreach ($opti as $k => $v) {
            $h .= '<option value="'.htmlspecialchars((string)$k, ENT_QUOTES, 'UTF-8', false).'" '.($valu == $k ? 'selected' : '').'>'.htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8', false).'</option>';
        }
        $h .= '</select>';
    } elseif ($type == 'textarea') { 
        $h .= '<textarea name="'.$name.'" id="'.$unique_id.'" '.$p_a.' style="'.$s.' min-height:3em; resize:vertical; line-height:1.5;" '.$clean_extr.'>'; 
        $h .= htmlspecialchars((string)$valu).'</textarea>'; 
    } else { 
        $h .= '<input type="'.$type.'" name="'.$name.'" id="'.$unique_id.'" '.$p_a.' style="'.$s.'" value="'.htmlspecialchars((string)$valu).'" '.$clean_extr.'>'; 
    }
    $h .= '</fieldset></div>';
    if ($echo) { echo $h; } else { return $h; }
} # htm_Field()


# SELECT (bare dropdown) - tynd wrapper omkring htm_Field's bare-tilstand
function htm_Select($name, $options, $selected = '', $styl = '', $attrs = '', $echo = true) {
    $extr = 'bare style="'.$styl.'" '.$attrs;
    return htm_Field('', '', $name, $selected, 'sele', $options, $extr, '100%', '', '', '', $echo);
}


# Indsæt denne funktion i /inc/php2htm.lib.php
# Placering: efter htm_Select() — ca. linje 48

# PROJEKT CODE FELT
# Vises kun hvis setting 'module_projects' = 1.
# Returnerer stille uden output hvis modulet er deaktiveret.
#
# Brug:   htm_ProjektCodeField($conn, $item['proj_id'] ?? null);
# Eller:  htm_ProjektCodeField($conn, $item['proj_id'] ?? null, '50%');
#
function htm_ProjektCodeField($conn, $selected_proj_id = null, $wdth = '100%'): void {
    // Tjek om modulet er aktivt
    $s = get_settings($conn);
    if (empty($s['module_projects']) || $s['module_projects'] != '1') return;

    // Byg options-array
    $opts = ['' => lang('@No project')];
    // RETTET: kun aktive projekter - en udgift/faktura på et siden afsluttet projekt mistede stille sin projektkobling
    // ved næste gem (feltet blev sendt tomt), og projektets resultat ændrede sig. Det valgte projekt beholdes nu.
    $res = DB::query($conn,
        "SELECT proj_id, proj_no, cust_id FROM projects WHERE is_active = 1 OR proj_id = " . (int)$selected_proj_id . " ORDER BY proj_no ASC"
    );
    if ($res) {
        while ($r = DB::fetch_assoc($res)) {
            $opts[$r['proj_id']] = htmlspecialchars($r['proj_no']);
        }
    }

    htm_Field(
        icon: 'fa-folder-open',
        labl: '@Project Code',
        name: 'proj_id',
        valu: $selected_proj_id ?? '',
        type: 'sele',
        opti: $opts,
        wdth: $wdth,
        hint: '@Assign this entry to a project',
        extr: 'dash'
    );
}


function htm_Wrap($content, $tag = 'div', $style = '', $echo = true) {
    $htm = '<'. $tag. ($style !== '' ? ' style="'. $style. '"' : ''). '>'. $content. '</'. $tag. '>';
    if ($echo) echo $htm; else return $htm;
}

# SHELL START
function htm_Shell_($styl='margin:0 auto; padding:10px;', $type='div', $echo = true) {
    static $stack = array();
    if ($styl === 'GET_STACK') return $stack;
    if ($styl === 'POP_STACK') { array_pop($stack); return; }
    $stack[] = $type;
    $htm = '<' . $type . ' style="' . $styl . '">';
    if ($echo) { echo $htm; } else { return $htm; }
}

# SHELL END
function htm_Shell_end($echo = true) {
    $stack = htm_Shell_('GET_STACK');
    if (empty($stack)) return '';
    $last_tag = end($stack);
    htm_Shell_('POP_STACK');
    $htm = '</' . $last_tag . '>';
    if ($echo) { echo $htm; } else { return $htm; }
}

# CSRF-BESKYTTELSE
# RETTET: fandtes slet ikke noget sted i appen - bekræftet ved en fuld projekt-gennemsøgning. En ondsindet side
# kunne derfor få en indlogget brugers browser til automatisk at indsende en formular til en hvilken som helst
# POST-side i TinyCash (ændre firma-indstillinger, oprette en admin-bruger, slette en konto...) uden brugerens
# vidende - SameSite=Lax beskytter kun mod passive tredjeparts-anmodninger (img/iframe/fetch), ikke mod at offeret
# narres til at klikke et link eller en auto-indsendt formular på en ekstern side.
function csrf_token(): string {
    if (session_status() === PHP_SESSION_ACTIVE && empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'] ?? '';
}

function csrf_field($echo = true) {
    $result = '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
    if (!$echo) return $result;
    echo $result;
}

function csrf_verify(): bool {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return true;
    if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token'])) return false;
    return hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}

// RETTET: CSRF-værnet gjaldt kun POST - men en lang række handlinger udføres af et almindeligt LINK (GET): slet
// bruger / konto / leverandør / momskode / bankpost, annullér eller slet en journalpost, kør afskrivninger,
// annullér en udgift, generér / spring over / slå faste fakturaer til og fra, konvertér et tilbud, send en
// faktura... Registret: script => de GET-parametre der udløser en handling (en værdi i 'read_only' er kun
// læsning).
// ÆNDRET: en handling udføres ikke længere som GET med csrf_token i URL'en. Filer der efter navnet er handlinger
// (*_action(s).php, *_duplicate.php, send_*.php) behøver ikke stå her - se csrf_action_by_name; kun sider der både
// vises og udfører en handling (fx customer_edit.php?del=) skal.
function csrf_get_actions(): array {
    return [
        'account_delete.php'          => ['params' => ['id']],
        'user_actions.php'            => ['params' => ['action']],
        'ledger_view.php'             => ['params' => ['action']],
        'reconcile_list.php'          => ['params' => ['action']],
        'recurring_invoices.php'      => ['params' => ['del', 'toggle', 'gen', 'skip']],
        'recurring_expenses.php'      => ['params' => ['del', 'toggle', 'gen', 'skip']],
        'supplier_list.php'           => ['params' => ['del']],
        'bank_integration.php'        => ['params' => ['disconnect']],
        'bank_integration_sync.php'   => ['params' => ['conn_id']],
        'vat_codes.php'               => ['params' => ['delete']],
        'expense_actions.php'         => ['params' => ['action']],
        'fixed_asset_actions.php'     => ['params' => ['action']],
        'inventory_actions.php'       => ['params' => ['action']],
        'project_actions.php'         => ['params' => ['action']],
        'quote_actions.php'           => ['params' => ['action']],
        'time_actions.php'            => ['params' => ['action']],
        'invoice_template_action.php' => ['params' => ['action'], 'read_only' => ['list', 'get']],
        'invoice_duplicate.php'       => ['params' => ['id']],
        'quote_duplicate.php'         => ['params' => ['id']],
        'send_invoice_action.php'     => ['params' => ['id']],
        'send_quote_action.php'       => ['params' => ['id']],
        'customer_edit.php'           => ['params' => ['del']],
        'invoice_edit.php'            => ['params' => ['del']],
        'quote_edit.php'              => ['params' => ['del']],
        'time_entry_edit.php'         => ['params' => ['del']],
        'settings_fees.php'           => ['params' => ['delete']],
        'storage_browser.php'         => ['params' => ['delete']],
        'menu_visibility.php'         => ['params' => ['reset']],
        'account_manage.php'          => ['params' => ['deactivate', 'reactivate']],
        'reminder_action.php'         => ['params' => ['id']],        // (sender en rykker-mail)
        'customer_statement_send.php' => ['params' => ['id']],        // (sender et kontoudtog)
        'quote_followup_action.php'   => ['params' => ['id']],        // (sender en tilbudsopfølgning)
        'webhook_keys.php'            => ['params' => ['revoke']],    // (fortryder en API-nøgle)
    ];
}
// Er filen en handling efter navnet? Så er enhver forespørgsel med parametre en handling - et nyt
// handlings-script er beskyttet uden at skulle huskes i registret (samme regel i htm_Header()'s JS).
function csrf_action_by_name(string $script): bool {
    return (bool)preg_match('/^(send_[a-z0-9_]+|[a-z0-9_]+_actions?|[a-z0-9_]+_duplicate)\.php$/', $script);
}
// Udløser denne query-string en handling i $script?
function csrf_query_is_action(string $script, array $q): bool {
    $reg = csrf_get_actions()[$script] ?? null;
    $params = $reg['params'] ?? (csrf_action_by_name($script) ? array_keys($q) : []);
    foreach ($params as $p) {
        if (!isset($q[$p]) || !is_scalar($q[$p]) || (string)$q[$p] === '') continue;
        if (in_array((string)$q[$p], $reg['read_only'] ?? [], true)) continue;
        return true;
    }
    return false;
}
// Er denne GET-forespørgsel en handling? (afvises i inc/auth.inc.php - den skal komme som POST)
function csrf_get_is_action(): bool {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') return false;
    return csrf_query_is_action(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')), $_GET);
}

# FLASH-BESKED + REDIRECT
// En handling lægger sin besked i sessionen og sender brugeren videre; den vises én gang øverst på den
// næste side (første htm_Card_(), ellers htm_Footer()). Erstatter ?msg=X/?err=X, hvor hver modtager-side
// selv skulle kende hver nøgle - en besked som modtageren ikke kendte, blev aldrig vist.
// $text er en '@nøgle' (oversættes ved visning) eller en allerede oversat tekst.
function flash(string $text, string $type = 'success'): void {
    if (session_status() !== PHP_SESSION_ACTIVE || $text === '') return;
    $_SESSION['tc_flash'][] = [$text, $type];
}
function redirect(string $url, string $msg = '', string $type = 'success'): never {
    if ($msg !== '') flash($msg, $type);
    header('Location: ' . $url);
    exit;
}
function flash_render($echo = true) {
    $htm = '';
    if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['tc_flash'])) {
        foreach ($_SESSION['tc_flash'] as $f) $htm .= htm_Alert(text: (string)$f[0], type: (string)($f[1] ?? 'success'), echo: false);
        unset($_SESSION['tc_flash']);
    }
    if (!$echo) return $htm;
    echo $htm;
}

# CARD START NY PARAMETER: $fold sætter et fold/luk-ikon yderst til højre i header-linjen, der åbner/lukker selve
# card-kroppen. Bevidst IKKE en fuld port af forbilledet (som bruger jQuery/tablesorter, en Pmnu_-popup-menu,
# dvl_pretty og globals der slet ikke findes i denne kodebase) - kun selve fold/luk-funktionen, som brugeren
# eksplicit bad om, genbygget i almindelig vanilla JS (toggleCard i inc/htm_page.lib.php) og 100% bagudkompatibelt:
# $fold er opt-in (default false), så alle 89 eksisterende kaldsteder er helt uændrede.
# RETTET (bruger-fund, live-testet): $form_is_open/$fold_id var FØR en enkelt flad static værdi, ikke en stak -
# virkede fint for sekventielle kort, men gik i stykker ved INDLEJREDE kort (fx backup.php's foldbare "Automatisk
# Backup"-kort, som selv indeholder et helt almindeligt, ikke-foldbart kort via render_auto_backup_settings).
# Omskrevet til en rigtig stak: hvert htm_Card_-kald pusher sin egen tilstand, hvert htm_Card_end popper kun den
# ØVERSTE (sin egen), uanset hvor mange indlejrede kort der måtte være imellem - samme LIFO-rækkefølge som selve
# HTML'ens egne tags naturligt følger.
function htm_Card_($capt, $wdth='600', $info='', $form=false, $echo = true, $tool = '', $fold = false, $bclr = '') {
    static $stack = [];
    static $fold_ix = 0;
    if ($form === 'CHECK_STATE') return !empty($stack) && end($stack)['form_open'];
    if ($form === 'CHECK_FOLD')  return !empty($stack) ? end($stack)['fold_id'] : null;
    if ($form === 'POP_STATE')   { array_pop($stack); return; }

    if (!$echo) ob_start();
    if (empty($stack)) flash_render(); // en ventende flash-besked vises over sidens første kort
    $w = is_numeric($wdth) ? $wdth.'px' : $wdth;

    $entry = ['form_open' => false, 'fold_id' => null];

    if ($form) {
        $entry['form_open'] = true;
        $n = is_string($form) ? " name='$form' id='$form'" : "";
        echo "<form method='post' $n style='margin:0;'>";
        csrf_field(); // Automatisk indlejret i enhver formular bygget via htm_Card_(form:...)
    }

    $tool_html = $tool;
    $capt_attr = ''; // NY: gør selve kort-titlen klikbar for fold, se nedenfor
    $fold_closed = ($fold === 'closed'); // NY: fold:'closed' starter sammenklappet i stedet for åben
    if ($fold) {
        $fold_ix++;
        $entry['fold_id'] = 'cardBody' . $fold_ix;
        $icon_id = $entry['fold_id'] . '_icon';
        $chev = $fold_closed ? 'fa-chevron-right' : 'fa-chevron-down'; // samme par som htm_SectionStart() bruger
        // RETTET: data-hint må ALDRIG sidde direkte på selve <i>-ikonet - FA
        // tegner sin glyf via en CSS ::before-regel på <i>-elementet, og
        // sitets globale hint-CSS ([data-hint]::before/::after { content:
        // none !important; }) slår derfor selve ikonet usynligt, hvis
        // data-hint ligger der. Hintet skal i stedet ligge på et omsluttende
        // element (her et <span>), som alle andre ikon+hint-kombinationer i
        // koden allerede gør det.
        // "tc-fold-icon"-klassen har intet med udseende at gøre - den er
        // udelukkende en JS-krog (htm_page.lib.php: updateToggleAllCardsButton()/
        // toggleAllCards()), så "fold alle ud/sammen"-ikonet kan tælle og
        // finde samtlige foldbare kort på siden uden at kende deres fold_id'er.
        //
        // RETTET (bruger-rapporteret: "ikke der de skulle placeres, men på
        // card ved siden af fold-ikonen") - "fold alle ud/sammen" boede
        // først som én knap i den flydende værktøjsbjælke; brugeren ville i
        // stedet have et ens dobbeltpil-ikon på HVERT foldbart kort, lige
        // ved siden af kortets eget fold-ikon. Starter skjult (display:none)
        // - JS (updateToggleAllCardsButton()) viser det kun, når der er 3+
        // foldbare kort på siden, og PHP kender ikke det tal her (kun kortet
        // foran sig selv). Samme klik-funktion (toggleAllCards()) uanset
        // hvilket af de identiske ikoner man klikker på.
        $tool_html .= ($tool_html !== '' ? ' ' : '') . '<span class="tc-toggle-all-wrap" style="display:none;" data-expand-hint="'.htmlspecialchars(lang('@Expand all sections on this page'), ENT_QUOTES).'" data-collapse-hint="'.htmlspecialchars(lang('@Collapse all sections on this page'), ENT_QUOTES).'" data-hint="'.htmlspecialchars(lang('@Expand all sections on this page'), ENT_QUOTES).'"><i class="fa-solid fa-angles-down tc-toggle-all-icon" onclick="toggleAllCards(this)" style="cursor:pointer; color:var(--text-muted); margin-left:10px; font-size:1.1em;"></i></span>';
        $tool_html .= '<span data-hint="'.htmlspecialchars(lang('@Click to expand/collapse this card'), ENT_QUOTES).'"><i id="'.$icon_id.'" class="fa-solid '.$chev.' tc-fold-icon" onclick="toggleCard(\''.$entry['fold_id'].'\', this)" style="cursor:pointer; color:var(--text-muted); margin-left:10px; font-size:1.1em;"></i></span>';
        // NY: selve titlen skal også kunne folde/lukke kortet, ikke kun det lille chevron-ikon. Peger på DEN SAMME
        // ikon-reference (via id) som selve ikonets eget onclick, så pilens retning altid følger med uanset
        // hvilket af de to man klikker på.
        // RETTET - to separate ting: (1) selve <h2>-elementet fik aldrig sit eget data-hint - kun fold-ikonet
        // havde ét - så hover over selve overskriften viste intet. Samme data-hint-tekst som ikonet, direkte på
        // <h2>, plus "flex:1" (se $h2_style nedenfor) som lader selve <h2>-boksen fylde det blanke rum ud i stedet
        // for at overlade det til justify-content.
        $capt_attr = ' onclick="toggleCard(\''.$entry['fold_id'].'\', document.getElementById(\''.$icon_id.'\'))" data-hint="'.htmlspecialchars(lang('@Click to expand/collapse this card'), ENT_QUOTES).'"';
    }
    $h2_style = 'margin:0; color: var(--text-main, #2c3e50);' . ($fold ? ' cursor:pointer; flex:1;' : '');

    $stack[] = $entry; // Push FØR resten af HTML'en, så et evt. indlejret htm_Card_-kald i callerens kode lægger sig oven på denne, ikke ved siden af den.

    // RETTET: $capt landede uescaped direkte i en rigtig <h2> - ingen tag-udbrud nødvendig her, en dynamisk bygget
    // $capt med rå brugerdata ville udføres med det samme. Ingen nuværende kalder sender bevidst HTML-markup i
    // $capt (kun enkelte sender allerede htmlspecialchars'et brugerdata, fx project_view.php), så denne escaping
    // er et no-op for alle andre.
    $bg = ($bclr !== '') ? htmlspecialchars($bclr, ENT_QUOTES) : 'var(--bg-card)';
    echo '<div style="max-width:'.$w.'; margin: 20px auto; padding: 0 5px;"><div style="background: '.$bg.'; padding:25px; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.1);">';
    // RETTET - skillelinjen adskiller visuelt caption'en fra kortets BRØDTEKST, så den giver ingen mening at vise,
    // når brødteksten er skjult (fold: 'closed', eller efter man selv har klappet kortet sammen). Selve
    // caption-rækken får et forudsigeligt id ({fold_id}_caption), så toggleCard (htm_page.lib.php) kan slå
    // border-bottom til/fra i takt med brødteksten, ikke kun ved selve sidens første indlæsning.
    // RETTET - da skillelinjen ovenfor blev skjult i lukket fold-tilstand, stod margin-bottom/padding-bottom
    // stadig tilbage uændret (de 25px, der oprindeligt var beregnet til at give linjen albuerum), så der blev ved
    // med at se ud som tomt, reserveret rum uden nogen linje i det. toggleCard (htm_page.lib.php) holder dem i
    // takt ved manuel fold/udfold.
    $divider = ($fold && $fold_closed) ? 'none' : '2px solid var(--color-primary)';
    $caption_spacing = ($fold && $fold_closed) ? 'margin-bottom:0; padding-bottom:0;' : 'margin-bottom:15px; padding-bottom:10px;';
    $caption_id_attr = $entry['fold_id'] ? ' id="'.$entry['fold_id'].'_caption"' : '';
    echo '<div'.$caption_id_attr.' style="display:flex; justify-content:space-between; align-items:center; border-bottom:'.$divider.'; '.$caption_spacing.'"><h2 style="'.$h2_style.'"'.$capt_attr.'>'.htmlspecialchars(lang($capt)).'</h2><div>'.$tool_html.'</div></div>';
    if($info) echo '<div style="margin-bottom:15px; padding:10px; background: var(--bg-panel); border-radius:4px; font-size:0.9em; color: var(--text-muted);">'.$info.'</div>';
    if ($entry['fold_id']) echo '<div id="'.$entry['fold_id'].'"'.($fold_closed ? ' style="display:none;"' : '').'>';

    if (!$echo) return ob_get_clean();
}

# CARD END
function htm_Card_end($echo = true) {
    if (!$echo) ob_start();
    if (htm_Card_('', '', '', 'CHECK_FOLD')) echo '</div>'; // lukker fold-wrapper (kun hvis $fold=true blev brugt)
    if (htm_Card_('', '', '', 'CHECK_STATE')) {
        echo '</div></div></form>';
    } else {
        echo '</div></div>';
    }
    htm_Card_('', '', '', 'POP_STATE');
    if (!$echo) return ob_get_clean();
}

# BUTTON 
function htm_Button($icon='', $labl='', $type='primary', $link='', $styl='', $attr='', $cont='', $echo=true) {
    $s = "display:inline-block; text-align:center; background-color: var(--color-$type); color: var(--text-light); padding:8px 16px; border-radius:4px; text-decoration:none; border:none; cursor:pointer; font-size:14px; font-weight:600;";

    $l = ($labl != '') ? " ".lang($labl) : ''; 
    $i_h = ($icon != '') ? "<i class='fa-solid $icon'></i>" : "";
    $b = ($link != '') ? "<a href='$link' style='$s$styl' $attr>$i_h$l</a>" : "<button type='submit' style='$s$styl' $attr>$i_h$l</button>";
    if (!$echo) return $b; echo $b;
}


# php2htm.lib.php — htm_Table() v:1.3.1 d:2026-08-02 i:claude
# Nyt: $vhgh (synlig højde), skjulte kolonner (hidd-præfiks i $head), CSV-eksport ($expo)

function htm_Table($head, $data, $name='tbl', $limt=25, $html='', $echo=true, $cols=array(),
                   $vhgh='500px', $expo='') {
    /*
     * $head  — associativt array: ['Label' => ...] eller numerisk ['Label', ...]
     *          Nøgle der starter med 'hidd:' skjuler kolonnen i visningen men
     *          inkluderer data-værdien som data-attribut på <tr> (til brug i JS/links).
     *          Eks: ['hidd:id', 'Navn', 'Beløb']
     *
     * $vhgh  — max synlig højde af tabel-scrollvinduet, fx '400px' eller '80vh'
     *
     * $expo  — filnavn til CSV-download-knap, fx 'fakturaliste.csv'.
     *          Tom streng = ingen eksport-knap.
     */
    if (!$echo) ob_start();

    // Byg liste over skjulte kolonner (indeks i $head-arrayet)
    $head_keys  = array_keys($head);
    $head_clean = [];   // Label til visning
    $head_hidd  = [];   // bool: er kolonnen skjult?
    foreach ($head as $k => $labl) {
        if (strpos((string)$k, 'hidd:') === 0 || strpos($labl, 'hidd:') === 0) {
            $head_clean[] = ltrim($labl, 'hidd:');
            $head_hidd[]  = true;
        } else {
            $head_clean[] = $labl;
            $head_hidd[]  = false;
        }
    }

    echo '<style>
        #'.$name.' input { text-align:inherit !important; background:transparent; border:none; color:inherit; }
        #'.$name.' tr:nth-child(even) { background:var(--bg-table-even); }
        #'.$name.' tr:hover { background:var(--bg-table-hover); }
        .sort-ptr { cursor:pointer; }
        #'.$name.' td { padding:6px 8px; border-bottom:1px solid var(--border-subtle); color:var(--text-main); }
        #'.$name.' td.truncate { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; cursor:pointer; max-width:0; }
        #'.$name.' td.expanded { white-space:normal !important; word-break:break-word; cursor:pointer; }
        #'.$name.' th { padding:8px 10px; border-bottom:2px solid var(--border-color); text-align:left;
            background:var(--bg-panel); color:var(--text-main);
            position:sticky; top:0; z-index:10;
            box-shadow:0 2px 0 var(--border-color); }
        #'.$name.' .col-hidd { display:none; }
        #line_tbl input[readonly] { background-color:var(--bg-main) !important; cursor:not-allowed; color:var(--text-muted); }
    </style>';

    // ── Søgefelt + eksport-knap + ekstra HTML ────────────────────────────────
    echo '<div style="margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">';
    echo '  <div style="position:relative; width:160px;">';
    echo '    <i class="fa fa-search" style="position:absolute; left:8px; top:50%; transform:translateY(-50%); color:var(--color-secondary); font-size:0.8rem;"></i>';
    echo '    <input type="text" id="'.$name.'_search" onkeyup="filterTable(\''.$name.'\')" placeholder="'.lang('@Search').'..."
               style="padding:6px 6px 6px 28px; border:1px solid var(--border-color); border-radius:4px; width:100%;
               font-size:0.85rem; background:var(--bg-card); color:inherit;">';
    echo '  </div>';
    echo '  <div style="display:flex; gap:8px; align-items:center;">';
    if ($expo !== '') {
        $safeExpo = htmlspecialchars($expo);
        $safeName = htmlspecialchars($name);
        echo '    <button onclick="exportCsv(\''.$safeName.'\',\''.$safeExpo.'\')"
                    style="background:var(--color-success); color:white; border:none; padding:5px 12px;
                    border-radius:4px; cursor:pointer; font-size:13px; display:flex; align-items:center; gap:6px;"
                    title="'.lang('@Download table as CSV file').'">
                    <i class="fa fa-download"></i> '.lang('@CSV').'
                  </button>';
    }
    echo '    '.$html;
    echo '  </div>';
    echo '</div>';

    // ── Scroll-wrapper: ingen border-radius her — bryder sticky ──────────────
    echo '<div style="margin-bottom:60px; max-height:'.$vhgh.'; overflow:auto;">';
    echo '<table id="'.$name.'" style="width:100%; border-collapse:separate; border-spacing:0;
        table-layout:auto; border:1px solid var(--border-subtle); border-radius:8px;">';

    // ── Colgroup ─────────────────────────────────────────────────────────────
    if (!empty($cols)) {
        echo '<colgroup>';
        foreach ($cols as $ci => $style) {
            if (!empty($head_hidd[$ci])) { echo '<col class="col-hidd">'; continue; }
            preg_match('/width:\s?([^;]+)/', $style, $matches);
            $w = isset($matches[1]) ? 'width:'.$matches[1] : (is_numeric($style) ? 'width:'.$style : '');
            echo '<col style="'.$w.'">';
        }
        echo '</colgroup>';
    }

    // ── THEAD ─────────────────────────────────────────────────────────────────
    echo '<thead><tr>';
    $i = 0;
    foreach ($head_clean as $ci => $labl) {
        $hidd = !empty($head_hidd[$ci]);

        $align    = '';
        $is_right = false;
        if (!$hidd) {
            if (isset($cols[$ci]) && strpos($cols[$ci], 'text-align') !== false) {
                $align    = preg_replace('/width:[^;]+;?/', '', $cols[$ci]);
                if (strpos($cols[$ci], 'right') !== false) $is_right = true;
            }
        }

        $is_action     = (!$hidd && ($labl === '' || $ci === 'actions'
                          || strpos(strtolower($labl), 'action') !== false
                          || strpos($labl, '<') !== false));
        $display_label = (!$hidd && strpos($labl, '<') !== false) ? $labl : lang($labl);

        if (!$hidd && $is_action && (trim(strip_tags($display_label)) === ''
                           || strtolower(trim($display_label)) === 'action'
                           || strtolower(trim($display_label)) === '@action')) {
            $display_label = lang('@Actions');
        }

        if ($hidd) {
            echo '<th class="col-hidd"></th>';
        } elseif ($is_action) {
            echo '<th style="'.$align.'">'.$display_label.'</th>';
        } else {
            $flex = $is_right
                ? 'display:inline-flex; flex-direction:row; align-items:center; gap:5px; justify-content:flex-end; width:100%;'
                : 'display:inline-flex; align-items:center; gap:5px;';
            echo '<th class="sort-ptr" onclick="sortTable(\''.$name.'\', '.$i.')" style="'.$align.'">';
            echo '<span style="'.$flex.'">'.$display_label
                .' <i class="fa fa-sort" style="font-size:0.7rem; color:var(--color-secondary); flex-shrink:0;"></i></span>';
            echo '</th>';
            $i++;
        }
    }
    echo '</tr></thead>';

    // ── TBODY ─────────────────────────────────────────────────────────────────
    echo '<tbody>';
    foreach ($data as $rowv) {
        // Saml skjulte kolonner som data-attributter på <tr>
        $data_attrs = '';
        foreach ($head_hidd as $ci => $hidd) {
            if ($hidd) {
                $key = ltrim(array_keys($head)[$ci] ?? '', 'hidd:');
                $val = htmlspecialchars($rowv[$ci] ?? '');
                $data_attrs .= ' data-'.$key.'="'.$val.'"';
            }
        }
        echo '<tr'.$data_attrs.'>';
        foreach ($rowv as $ci => $valu) {
            $hidd  = !empty($head_hidd[$ci]);
            $style = isset($cols[$ci]) ? $cols[$ci] : '';
            if ($hidd) {
                echo '<td class="col-hidd"></td>';
            } else {
                echo '<td style="'.$style.'">'.$valu.'</td>';
            }
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
    ?>
    <script>
    function sortTable(tableId, n) {
        var table = document.getElementById(tableId); if (!table) return;
        // Find den n'te synlige th (spring skjulte over)
        var ths = Array.from(table.getElementsByTagName("th"))
                       .filter(function(t) { return !t.classList.contains("col-hidd"); });
        var th = ths[n];
        if (!th || !th.classList.contains("sort-ptr")) return;

        // Find kolonneindeks i tabellen (inkl. skjulte)
        var allThs = Array.from(table.getElementsByTagName("th"));
        var colIdx = allThs.indexOf(th);

        // RETTET: (1) boblesortering der flyttede én DOM-række ad gangen og startede forfra efter hver flytning - O(n^2)
        // med DOM-opslag, så en tabel med et par hundrede rækker frøs browseren i sekunder; (2) beløb med valuta eller
        // enhed ("-1.250,00 DKK", "1.250,00 kr.", "25 %") og tal med én decimal ("12,5") blev sorteret som TEKST.
        // Nu: hver celles sorteringsværdi beregnes én gang, rækkerne sorteres som et array (stabilt) og sættes ind igen.
        function getCleanValue(cell) {
            if (!cell) return "";
            var text = cell.innerText.trim(); var lower = text.toLowerCase();
            if (lower.endsWith(" mb") || lower.endsWith(" kb")) {
                var num = parseFloat(text.replace(/[^\d,.-]/g, "").replace(",", "."));
                if (isNaN(num)) return 0;
                return lower.endsWith(" mb") ? num * 1024 * 1024 : num * 1024;
            }
            var dm = text.match(/^(\d{2})[.\/-](\d{2})[.\/-](\d{4})(?:\s(\d{2}):(\d{2}))?$/);
            if (dm) return new Date(+dm[3], +dm[2]-1, +dm[1], +(dm[4] || 0), +(dm[5] || 0)).getTime();
            var nm = text.replace(/\s*(dkk|eur|usd|sek|nok|gbp|kr\.?|%)$/i, "").replace(/−/g, "-");
            if (/^-?\d{1,3}(\.\d{3})*(,\d+)?$|^-?\d+(,\d+)?$/.test(nm)) {
                var cleanNum = parseFloat(nm.replace(/\./g, "").replace(",", "."));
                if (!isNaN(cleanNum)) return cleanNum;
            }
            return lower;
        }
        var body = table.tBodies[0] || table;
        var rows = Array.from(body.rows).filter(function(r) { return r.getElementsByTagName("TD").length > 0; });
        var dir = (table.dataset.sortCol == String(colIdx) && table.dataset.sortDir === "asc") ? "desc" : "asc";
        table.dataset.sortCol = String(colIdx);  table.dataset.sortDir = dir;
        var keyed = rows.map(function(r, i) { return { r: r, i: i, v: getCleanValue(r.getElementsByTagName("TD")[colIdx]) }; });
        keyed.sort(function(a, b) {
            var x = a.v, y = b.v, c;
            if (typeof x === typeof y) c = (x < y) ? -1 : (x > y ? 1 : 0);
            else c = (typeof x === "number") ? -1 : 1;      // tal før tekst
            if (dir === "desc") c = -c;
            return c || (a.i - b.i);
        });
        keyed.forEach(function(k) { body.appendChild(k.r); });
    }

    function toggleCell(cell) {
        if (cell.classList.contains("expanded")) {
            cell.classList.remove("expanded");
            cell.classList.add("truncate");
        } else {
            cell.classList.remove("truncate");
            cell.classList.add("expanded");
        }
    }

    // RETTET (§bugs-batch-13-review): CSV/Excel-formel-injektion. En celle
    // der starter med =, +, - eller @ kan af Excel/LibreOffice blive
    // fortolket som en formel i stedet for tekst, hvis brugeren senere åbner
    // den eksporterede CSV-fil - samme sårbarhedsklasse som allerede var
    // rettet i export.php/inventory_export.php (server-side CSV-eksport),
    // men ALDRIG i denne fælles klient-side eksportknap, som en lang række
    // andre sider (audit_log.php, customer_statement.php, inventory_status.php
    // m.fl.) genbruger via htm_Table(...,'fil.csv'). Data i cellerne kan
    // stamme fra frit tekstfelter (kundenavn, banktekst osv.), som en bruger
    // reelt kontrollerer.
    // RETTET: alt der begyndte med "-" fik en apostrof foran (formel-værn) - også negative beløb ("-1.250,00 DKK"),
    // som så blev tekst med en synlig ' i Excel og ikke kunne regnes med. Et tal (evt. med valuta/enhed) er ufarligt.
    function csvSafe(v) {
        if (/^-?\d{1,3}(\.\d{3})*(,\d+)?(\s*(dkk|eur|usd|sek|nok|gbp|kr\.?|%))?$|^-?\d+(,\d+)?(\s*(dkk|eur|usd|sek|nok|gbp|kr\.?|%))?$/i.test(v)) return v;
        return (v.length > 0 && "=+-@".indexOf(v[0]) !== -1) ? "'" + v : v;
    }

    function exportCsv(tableId, filename) {
        var table = document.getElementById(tableId);
        if (!table) return;
        var rows = [];

        // Headers (kun synlige)
        var hdrs = Array.from(table.querySelectorAll("thead th"))
                        .filter(function(t) { return !t.classList.contains("col-hidd"); })
                        .map(function(t) { return '"' + csvSafe(t.innerText.trim()).replace(/"/g, '""') + '"'; });
        rows.push(hdrs.join(";"));

        // Data-rækker (kun synlige kolonner og rækker)
        Array.from(table.querySelectorAll("tbody tr")).forEach(function(tr) {
            if (tr.style.display === "none") return;
            var cells = Array.from(tr.querySelectorAll("td"))
                             .filter(function(td) { return !td.classList.contains("col-hidd"); })
                             .map(function(td) { return '"' + csvSafe(td.innerText.trim()).replace(/"/g, '""') + '"'; });
            rows.push(cells.join(";"));
        });

        var bom    = "\uFEFF"; // BOM så Excel åbner UTF-8 korrekt
        var blob   = new Blob([bom + rows.join("\n")], { type: "text/csv;charset=utf-8;" });
        var url    = URL.createObjectURL(blob);
        var a      = document.createElement("a");
        a.href     = url;
        a.download = filename;
        a.click();
        setTimeout(function() { URL.revokeObjectURL(url); }, 1000);      // (straks efter klik kunne nogle browsere afbryde hentningen)
    }
    </script>
    <?php
    if (!$echo) return ob_get_clean();
}




# SECTION START
function htm_SectionStart($icon, $labl, $open=false, $colr='var(--color-primary)', $echo=true, $tool='', $show_toggle=false) {
    if (!$echo) ob_start();
    $s = $open ? 'open' : '';
    $indicator = $open ? 'fa-chevron-down' : 'fa-chevron-right';
    // Hvis show_toggle er aktiveret, indsættes knapperne automatisk i tool-delen
    if ($show_toggle) {
        $toggle_btns = '<button type="button" onclick="toggleAllSections(true)" title="' . lang('@Expand All') . '" style="background:none; border:none; cursor:pointer; color:var(--text-muted); font-size:1em; padding:0;"><i class="fa fa-angle-double-down"></i></button>'
                     . '<button type="button" onclick="toggleAllSections(false)" title="' . lang('@Collapse All') . '" style="background:none; border:none; cursor:pointer; color:var(--text-muted); font-size:1em; padding:0;"><i class="fa fa-angle-double-up"></i></button>';
        $tool = $tool !== '' ? $tool . ' ' . $toggle_btns : $toggle_btns;
    }
    echo '<details '.$s.' ontoggle="this.querySelector(\'.section-arrow\').classList.toggle(\'fa-chevron-right\'); this.querySelector(\'.section-arrow\').classList.toggle(\'fa-chevron-down\');" style="margin-bottom:20px; border:2px solid var(--border-color); border-radius:8px; background: var(--bg-card);">';
    echo '<summary style="padding:14px 20px; background: var(--bg-panel); color: var(--text-main); cursor:pointer; font-weight:bold; display:flex; align-items:center; list-style:none;">';
    echo '<i class="fa-solid '.$icon.'" style="font-size:1.4em; width:35px; color:'.$colr.';"></i>';
    echo '<span style="flex-grow:1;">'.lang($labl).'</span>';
    if ($tool !== '') {
        echo '<div style="margin-left:auto; margin-right:10px; display:flex; gap:8px; align-items:center;" onclick="event.stopPropagation();">'.$tool.'</div>';
    }
    echo '<i class="fa-solid '.$indicator.' section-arrow" style="font-size:0.9em; color:var(--text-muted); transition:transform 0.2s;"></i>';
    echo '</summary><div style="padding:20px;">';
    if (!$echo) return ob_get_clean();
}

# SECTION END
function htm_SectionEnd($echo=true) {  
    if ($echo) { echo '</div></details>'; } else { return '</div></details>'; }
}
# ALERT
# RETTET: understøttede FØR kun 'error' og alt-andet-er-'success' - hånd-rullede advarsels-/infobannere i mindst 11
# filer opfandt derfor deres egen farvekode hver gang, i stedet for at kunne bruge denne fælles funktion.
# 'warning'/'info' tilføjet, samme --bg-alert-*/--text-alert-*-mønster som 'success'/'error' allerede brugte (nu
# rettet til rent faktisk at ligge inde i temablokkene, se inc/htm_page.lib.php).
function htm_Alert($text, $type='success', $width=700, $echo=true) {
    if (empty($text)) return "";
    if (!$echo) ob_start();
    $known = ['success', 'error', 'warning', 'info'];
    $t = in_array($type, $known, true) ? $type : 'success';
    $fallbacks = [
        'success' => ['#d4edda', '#155724'],
        'error'   => ['#f8d7da', '#721c24'],
        'warning' => ['#fff3cd', '#856404'],
        'info'    => ['#d1ecf1', '#0c5460'],
    ];
    $bg = "var(--bg-alert-$t, {$fallbacks[$t][0]})";
    $c  = "var(--text-alert-$t, {$fallbacks[$t][1]})";
    $htm = '<div style="background:'.$bg.'; color:'.$c.'; padding:15px; margin:10px auto; max-width:'.$width.'px; border-radius:4px; border:1px solid '.$c.'50;">' . lang($text) . '</div>';
    if ($echo) { echo $htm; } else { return $htm; }
}

# NOTE (dæmpet forklarende tekst, typisk lige under et korts overskrift). $text er færdig HTML (allerede
# lang()'et/escaped af kalderen); $styl lægges efter den dæmpede farve (fx 'font-size:0.9em; margin-top:-5px;').
function htm_Note($text, $styl = '', $echo = true) {
    $htm = '<p style="color:var(--text-muted);' . ($styl !== '' ? ' ' . $styl : '') . '">' . $text . '</p>';
    if (!$echo) return $htm;
    echo $htm;
}

# BANNER (venstre-kant-markeret, stående sidenotits)
# RETTET: mindst 11 filer hånd-rullede samme venstre-kant-bannér-mønster (background: var(--bg-panel); border-left:
# Npx solid var(--color-X); border-radius:4px;...) hver for sig, med små, utilsigtede forskelle (3-5px kantbredde,
# forskellige paddings/margener). htm_Banner er BEVIDST en ANDEN funktion end htm_Alert ovenfor, ikke blot en
# ekstra type dér - visuelt og semantisk forskellige formål: htm_Alert er en centreret, fuldt indrammet boks til et
# ÉN-GANGS handlings-resultat (gem lykkedes/fejlede); htm_Banner er en venstrestillet, fuld-bredde, STÅENDE
# notits/advarsel der sidder øverst på en side uafhængigt af nogen bestemt handling (fx "denne rapport er et
# udkast").
function htm_Banner($text, $type='warning', $echo=true) {
    if (empty($text)) return "";
    if (!$echo) ob_start();
    $known = ['info', 'warning', 'danger', 'success'];
    $t = in_array($type, $known, true) ? $type : 'warning';
    $colr = "var(--color-$t)";
    $htm = '<div style="background:var(--bg-panel); color:var(--text-main); border-left:4px solid '.$colr.'; border-radius:4px; padding:12px 15px; margin-bottom:16px; font-size:0.9em;">' . lang($text) . '</div>';
    if ($echo) { echo $htm; } else { return $htm; }
}

# BADGE
function htm_Badge($text, $type = 'secondary', $echo = true) {
    $light_bg_variants = ['warning'];
    $text_color = in_array($type, $light_bg_variants) ? 'var(--color-dark)' : 'var(--text-light)';

    $htm = '<span style="display:inline-block; padding:3px 10px; border-radius:12px; '
       . 'font-size:11px; font-weight:bold; text-align:center; line-height:1.4; '
       . 'color:'.$text_color.'; background:var(--color-'.$type.', var(--color-secondary));">'
       . lang($text) . '</span>';
    if (!$echo) return $htm;
    echo $htm;
}

# CONFIRM - JS til en on*-attribut (onclick/onsubmit="..."): "return confirm(...)" - eller med $then: nej = return false, ja = $then.
# Teksten (en '@nøgle' eller færdig tekst) escapes til JS (json_encode) OG til attributten (htmlspecialchars) - de
# håndskrevne varianter (addslashes alene, htmlspecialchars i '...', omvendt rækkefølge) brød på ' eller ", og så
# sprang browseren bekræftelsen over og udførte handlingen.
function htm_confirm_js(string $text, string $then = ''): string {
    $msg = htmlspecialchars(json_encode(strncmp($text, '@', 1) === 0 ? lang($text) : $text, JSON_UNESCAPED_UNICODE), ENT_QUOTES);
    return $then === '' ? "return confirm($msg)" : "if (!confirm($msg)) return false; $then";
}

# CONFIRM LINK/BUTTON
function htm_ConfirmLink($icon = '', $labl = '', $link = '', $mess = '@Are you sure?', 
                         $type = 'danger', $styl = '', $attr = '', $echo = true) {
    $s = "display:inline-block; text-align:center; background-color: var(--color-$type); "
       . "color: var(--text-light); padding:8px 16px; border-radius:4px; text-decoration:none; "
       . "border:none; cursor:pointer; font-size:14px; font-weight:600;";
    $l   = ($labl != '') ? ' ' . lang($labl) : '';
    $i_h = ($icon != '') ? "<i class='fa-solid $icon'></i>" : '';
    $htm = "<a href='" . htmlspecialchars($link) . "' style='$s$styl' "
       . "onclick=\"" . htm_confirm_js($mess) . "\" $attr>$i_h$l</a>";
    if (!$echo) return $htm;
    echo $htm;
}

# ACTION BUTTONS
function htm_ActionButtons($acti, $echo = true) {
    $htm = '<div style="display:flex; gap:4px; justify-content:flex-end; align-items:center;">';
    foreach ($acti as $a) {
        $type    = $a['type']    ?? 'secondary';
        $icon    = $a['icon']    ?? '';
        $hint    = $a['hint']    ?? '';
        $label   = $a['label']   ?? '';
        $link    = $a['link']    ?? '';
        $onclick = $a['onclick'] ?? '';
        $confirm = $a['confirm'] ?? '';
        if ($confirm !== '') $onclick = htm_confirm_js($confirm, $onclick);      // (før: "return confirm(...);onclick" - onclick kørte aldrig)
        $has_label = ($label !== '');
        if ($has_label) {
            $style = "display:inline-flex; align-items:center; justify-content:center; gap:6px; "
                   . "height:28px; padding:0 12px; white-space:nowrap; "
                   . "border-radius:4px; background:var(--color-$type); color:var(--text-light); "
                   . "text-decoration:none; border:none; cursor:pointer; font-size:12px; font-weight:600;";
        } else {
            $style = "display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; "
                   . "border-radius:4px; background:var(--color-$type); color:var(--text-light); "
                   . "text-decoration:none; border:none; cursor:pointer; font-size:12px;";
        }
        $hint_attr = ($hint !== '') ? ' data-hint="' . htmlspecialchars(lang($hint)) . '"' : '';
        $icon_html = $icon !== '' ? "<i class='fa-solid $icon'></i>" : '';
        $label_html = $has_label ? ' ' . lang($label) : '';
        $onclick_attr = $onclick !== '' ? ' onclick="' . $onclick . '"' : '';
        if ($link !== '') {
            $htm .= "<a href='" . htmlspecialchars($link) . "' style='$style'{$onclick_attr}{$hint_attr}>$icon_html$label_html</a>";
        } else {
            $htm .= "<button type='button' style='$style'{$onclick_attr}{$hint_attr}>$icon_html$label_html</button>";
        }
    }
    $htm .= '</div>';
    if (!$echo) return $htm;
    echo $htm;
}

# UTILS (HTML-byggende)
function htm_nl($rept=1) {
    echo str_repeat('<br />', $rept);
}

function htm_GetDocIcon($filename, $type = 'other') {
    // Kalder resolve_doc_path() (tidligere htm_DocPath()) fra core_utils.lib.php
    $path = resolve_doc_path($filename); if (!$path) return '---';
    $icons = array(
        'expense' => array('icon' => 'fa-file-invoice-dollar', 'color' => 'var(--color-danger)'),
        'revenue' => array('icon' => 'fa-file-invoice',        'color' => '#27ae60'),
        'bank'    => array('icon' => 'fa-university',          'color' => 'var(--color-primary)'),
        'other'   => array('icon' => 'fa-paperclip',           'color' => 'var(--color-secondary)')
    );
    if (strpos($filename, 'EXP_') === 0) $type = 'expense';
    $cfg = isset($icons[$type]) ? $icons[$type] : $icons['other'];
    return '<a href="'.$path.'" target="_blank" style="color:'.$cfg['color'].'; font-size:1.1em;" data-hint="'.htmlspecialchars($filename).'"><i class="fa-solid '.$cfg['icon'].'"></i></a>';
}

function print_arr($arrVar,$titl='',$attr='',$wdth='fit-content',$rtrn=false)
{
    if (is_string($arrVar)) {
        if (empty($titl)) { $titl = '$' . $arrVar; }
        if (isset($GLOBALS[$arrVar])) { $arrVar = $GLOBALS[$arrVar]; }
        elseif (isset($_REQUEST[$arrVar])) { $arrVar = $_REQUEST[$arrVar]; }
    }

    $result = '<div style="background:var(--bg-panel); color:var(--text-main); border:1px solid var(--border-color); padding:10px; margin:10px 0; border-radius:5px; width:'.$wdth.'; font-family:monospace; font-size:12px; overflow:auto; '.$attr.'">';
    if (!empty($titl)) { $result .= '<b style="color:var(--color-primary); display:block; margin-bottom:5px;">'.htmlspecialchars($titl).'</b>'; }
    $result .= '<pre style="margin:0; white-space:pre-wrap;">' . htmlspecialchars(print_r($arrVar, true)) . '</pre></div>';

    if ($rtrn) { return $result; }
    echo $result;
}