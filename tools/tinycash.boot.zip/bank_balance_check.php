<?php # /bank_balance_check.php v:1.3.1 d:2026-09-15 i:evs
# NY FUNKTION (bruger-anmodet, "kan bogholderen ønske sig mere", runde 26):
# reconcile_list.php matcher enkelte banklinjer, men ingen side sammenlignede
# hovedbogens bankkonto-saldo mod den FAKTISKE saldo på selve bankkontoudtoget
# pr. en given dato - samme kontrolprincip som subledger_reconciliation.php
# allerede gør for debitorer/kreditorer, blot for banken/kassen. Bevidst INGEN
# gemt historik (samme som subledger_reconciliation.php) - ren on-demand
# sammenligning, ingen ny tabel nødvendig.
#
# RETTET (BEK 811/2026-gennemgang, Bilag 3 "bankafstemning", se
# [[digital-standard-bookkeeping-registration-goal]]): on-demand-sammenligning
# alene efterlod intet bevis for, HVORNÅR og AF HVEM en konto sidst reelt blev
# afstemt - kun at værktøjet FINDES, ikke at det bruges løbende. "Gem
# afstemning" gør nu hver udført sammenligning til en permanent, dateret post
# i den nye bank_reconciliations-tabel (db-setup/migrate_bank_reconciliations.
# php) - bevidst APPEND-ONLY (intet rediger/slet-endpoint er bygget), samme
# bevis-må-ikke-kunne-ændres-filosofi som append-only-triggerne på journal/
# ledger/expenses.
$rLev = 3;
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';
require_once 'inc/audit.inc.php';

$has_recon_table = db_has_table($conn, 'bank_reconciliations');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_recon'])) {
    if (!csrf_verify()) {
        redirect('bank_balance_check.php', '@Security check failed (CSRF). Please try again.', 'error');
    }
    if (!$has_recon_table) {
        redirect('bank_balance_check.php', '@This installation has not yet run the "Saved bank reconciliations" migration (see run_migrate.php).', 'error');
    }
    $p_acc_id    = (int)($_POST['acc_id'] ?? 0);
    $p_stmt_date = $_POST['stmt_date'] ?? '';
    // RETTET: gl_balance/difference blev FØR taget direkte fra $_POST og skrevet uændret ind i den
    // append-only-ment afstemningspost - en bruger kunne (fx via devtools) ændre det skjulte gl_balance-felt og
    // gemme en falsk "afstemt, 0 kr. difference"-post, selvom hovedbogens reelle saldo var noget andet. gl_balance
    // genberegnes nu her, SERVER-SIDE, fra journal/ledger - nøjagtig samme forespørgsel som selve
    // sammenlignings-visningen ovenfor bruger.
    $p_stmt_bal  = (float)($_POST['stmt_balance'] ?? 0);
    if (!is_numeric((string)($_POST['stmt_balance'] ?? ''))) redirect('bank_balance_check.php', '@Please enter a valid amount.', 'error');
    $p_note      = trim($_POST['note'] ?? '');

    // RETTET: kontoudtogsdatoen blev ikke kontrolleret - en ugyldig dato ("2026-02-31", "abc") blev gemt i den
    // permanente, daterede afstemningspost (som ikke kan rettes bagefter), og hovedbogssaldoen beregnet til den.
    $bb_saved = false;
    if ($p_acc_id > 0 && tc_is_date($p_stmt_date)) {
        $bb_saved = true;
        $ds_save = DB::escape($conn, $p_stmt_date);
        $gl_row_save = DB::fetch_assoc(DB::query($conn, "SELECT SUM(l.amount) AS bal FROM ledger l JOIN journal j ON l.jou_id = j.jou_id WHERE l.acc_id = $p_acc_id AND j.jou_date <= '$ds_save'"));
        $p_gl_bal = (float)($gl_row_save['bal'] ?? 0);
        $p_diff   = round($p_gl_bal - $p_stmt_bal, 2);
        DB::insert($conn, 'bank_reconciliations', [
            'acc_id'       => $p_acc_id,
            'stmt_date'    => $p_stmt_date,
            'gl_balance'   => $p_gl_bal,
            'stmt_balance' => $p_stmt_bal,
            'difference'   => $p_diff,
            'note'         => $p_note !== '' ? $p_note : null,
            'created_by'   => (int)($_SESSION['user_id'] ?? 0),
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        $bb_rid = (int)DB::insert_id($conn);      // (revisionssporet pegede på række 0 - ikke den gemte afstemning)
        log_action($conn, 'SAVE_BANK_RECONCILIATION', 'bank_reconciliations', $bb_rid, null,
            ['acc_id' => $p_acc_id, 'stmt_date' => $p_stmt_date, 'difference' => $p_diff]);
    }
    redirect('bank_balance_check.php?acc_id=' . $p_acc_id . '&stmt_date=' . urlencode($p_stmt_date) . '&stmt_bal=' . urlencode(fmt_dk_input($p_stmt_bal)),
        $bb_saved ? '@Reconciliation saved - this is now a permanent, dated record.' : '@Nothing was saved - choose a bank account and a valid statement date.', $bb_saved ? 'success' : 'error');      // (sagde "gemt" også når intet blev gemt)
    exit;
}

$s   = get_settings($conn);
$cur = $s['currency'] ?? 'DKK';

require_once __DIR__ . '/inc/accounts.inc.php';     // valglisten: slukkede konti udeladt, dæmpede nederst
$acc_res = DB::query($conn, "SELECT acc_id, acc_name" . acc_status_col($conn) . " FROM accounts WHERE acc_type = 'bank' AND " . acc_visible_sql($conn, '', [(int)($_GET['acc_id'] ?? 0), (int)($s['conf_acc_bank'] ?? 0)]) . " ORDER BY " . acc_order_sql($conn) . "acc_id");
$acc_options = [];
while ($ar = DB::fetch_assoc($acc_res)) { $acc_options[$ar['acc_id']] = $ar['acc_id'] . ' - ' . acc_label($ar['acc_name'], $ar['acc_status'] ?? null); }

$acc_id    = isset($_GET['acc_id']) ? (int)$_GET['acc_id'] : (int)($s['conf_acc_bank'] ?? 0);
$stmt_date = isset($_GET['stmt_date']) && tc_is_date($_GET['stmt_date']) ? $_GET['stmt_date'] : date('Y-m-d');
// (et ugyldigt beløb - "abc", "12.500 kr" - blev læst som 0 eller et forkert tal, og kunne gemmes som en permanent
// afstemningspost, der ikke kan rettes bagefter)
$stmt_bal_raw = trim((string)($_GET['stmt_bal'] ?? ''));
$stmt_bal  = $stmt_bal_raw !== '' ? tc_num($stmt_bal_raw) : null;
$stmt_bal_bad = $stmt_bal_raw !== '' && $stmt_bal === null;

htm_Header('@Bank Balance Reconciliation');
showMenu();

echo "<div style='max-width:800px; margin:0 auto; padding:10px;'>";

flash_render();

htm_Note(lang('@Compares the general ledger balance of a bank/cash account against the actual closing balance shown on the real bank statement as of a chosen date - catches missing or duplicate imports that reconcile_list.php\'s line-by-line matching alone would not surface.'), 'margin-bottom:20px;');

htm_Card_('@Bank Balance Reconciliation', 800);

if (empty($acc_options)) {
    htm_Banner('<i class="fa fa-triangle-exclamation"></i> ' . lang('@No accounts of type "bank" found in the Chart of Accounts.'), 'warning');
} else {
    echo '<form method="get" style="display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap; margin-bottom:20px;">';
    echo '<div><label style="font-size:0.85em; font-weight:bold; display:block;">' . lang('@Account') . '</label>';
    htm_Select('acc_id', $acc_options, (string)$acc_id, 'width:260px; padding:6px;');
    echo '</div>';
    echo '<div><label style="font-size:0.85em; font-weight:bold; display:block;">' . lang('@Statement Date') . '</label>';
    echo '<input type="date" name="stmt_date" value="' . htmlspecialchars($stmt_date) . '" style="padding:6px;"></div>';
    echo '<div><label style="font-size:0.85em; font-weight:bold; display:block;">' . lang('@Statement Closing Balance') . '</label>';
    echo '<input type="text" name="stmt_bal" value="' . htmlspecialchars($_GET['stmt_bal'] ?? '') . '" placeholder="' . htmlspecialchars($cur) . '" style="width:150px; padding:6px;"></div>';
    htm_Button(labl: '@Compare', type: 'primary', attr: 'data-hint="'.lang('@Compare the ledger balance against this statement balance').'"');
    echo '</form>';

    if ($stmt_bal_bad) htm_Alert(lang('@Please enter a valid amount.'), 'error', 800, true);
    if ($acc_id > 0 && $stmt_bal !== null) {
        $ds = DB::escape($conn, $stmt_date);
        $gl_row = DB::fetch_assoc(DB::query($conn, "SELECT SUM(l.amount) AS bal FROM ledger l JOIN journal j ON l.jou_id = j.jou_id WHERE l.acc_id = $acc_id AND j.jou_date <= '$ds'"));
        $gl_bal = (float)($gl_row['bal'] ?? 0);
        $diff = round($gl_bal - $stmt_bal, 2);

        echo '<div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:15px; margin-bottom:15px;">';
        echo '<div><div style="color:var(--text-muted); font-size:0.85em;">' . lang('@General Ledger Balance') . '</div><div style="font-weight:bold; font-size:1.2em;"><a href="account_card.php?acc_id=' . $acc_id . '&to=' . htmlspecialchars($stmt_date) . '">' . fmt_dk($gl_bal) . ' ' . $cur . '</a></div></div>';
        echo '<div><div style="color:var(--text-muted); font-size:0.85em;">' . lang('@Statement Closing Balance') . '</div><div style="font-weight:bold; font-size:1.2em;">' . fmt_dk($stmt_bal) . ' ' . $cur . '</div></div>';
        echo '<div><div style="color:var(--text-muted); font-size:0.85em;">' . lang('@Difference') . '</div><div style="font-weight:bold; font-size:1.2em; color:' . (abs($diff) > 0.01 ? 'var(--color-danger)' : 'inherit') . ';">' . fmt_dk($diff) . ' ' . $cur . '</div></div>';
        echo '</div>';

        if (abs($diff) <= 0.01) {
            htm_Alert(lang('@Reconciled - the ledger balance matches the bank statement.'), 'success', 800, true);
        } else {
            htm_Alert(sprintf(lang('@NOT reconciled - the ledger and the bank statement differ by %s as of %s. Check reconcile_list.php for unmatched or duplicate lines.'), fmt_dk(abs($diff)) . ' ' . $cur, date(CONF_DATE_FORMAT, strtotime($stmt_date))), 'error', 800, true);
        }
        echo '<p><a href="reconcile_list.php">' . lang('@Go to Bank Reconciliation') . '</a> · <a href="account_card.php?acc_id=' . $acc_id . '">' . lang('@View Account Card') . '</a></p>';

        if ($has_recon_table) {
            echo '<form method="post" style="border-top:1px solid var(--border-color); padding-top:15px; margin-top:10px; display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap;">';
            csrf_field();
            echo '<input type="hidden" name="acc_id" value="' . $acc_id . '">';
            echo '<input type="hidden" name="stmt_date" value="' . htmlspecialchars($stmt_date) . '">';
            // RETTET: gl_balance/difference sendes ikke længere med - gemme-handleren genberegner selv gl_balance
            // server-side,. stmt_balance er brugerens eget aflæste tal og er den ENESTE af de tre, der reelt skal
            // sendes.
            echo '<input type="hidden" name="stmt_balance" value="' . htmlspecialchars((string)$stmt_bal) . '">';
            echo '<div style="flex:1; min-width:200px;"><label style="font-size:0.85em; font-weight:bold; display:block;">' . lang('@Note (optional)') . '</label>';
            echo '<input type="text" name="note" style="width:100%; padding:6px;" placeholder="' . htmlspecialchars(lang('@e.g. explanation of a difference')) . '"></div>';
            htm_Button(icon: 'fa-check', labl: '@Save Reconciliation', type: 'success', attr: 'type="submit" name="save_recon" value="1" data-hint="'.lang('@Permanently record that this account was reconciled as of this date - cannot be edited or deleted afterwards.').'"');
            echo '</form>';
        }
    }

    // --- AFSTEMNINGSHISTORIK (BEK 811/2026, se filens egen begrundelse) ---
    if ($has_recon_table && $acc_id > 0) {
        echo '<h3 style="margin-top:25px; border-top:1px solid var(--border-color); padding-top:15px;">' . lang('@Reconciliation History') . '</h3>';
        $hist_res = DB::query($conn, "SELECT r.*, u.username FROM bank_reconciliations r LEFT JOIN users u ON u.user_id = r.created_by WHERE r.acc_id = $acc_id ORDER BY r.stmt_date DESC, r.recon_id DESC LIMIT 25");
        $rows = [];
        while ($hist_res && ($h = DB::fetch_assoc($hist_res))) {
            $h_diff = (float)$h['difference'];
            $rows[] = [
                date(CONF_DATE_FORMAT, strtotime($h['stmt_date'])),
                fmt_dk((float)$h['gl_balance']) . ' ' . $cur,
                fmt_dk((float)$h['stmt_balance']) . ' ' . $cur,
                '<span style="' . (abs($h_diff) > 0.01 ? 'color:var(--color-danger); font-weight:bold;' : '') . '">' . fmt_dk($h_diff) . ' ' . $cur . '</span>',
                htmlspecialchars($h['username'] ?? '-'),
                htmlspecialchars($h['note'] ?? ''),
            ];
        }
        if ($rows) {
            htm_Table(['@Statement Date', '@General Ledger Balance', '@Statement Closing Balance', '@Difference', '@User', '@Note'], $rows, 'bankReconHistTbl', 25);
        } else {
            htm_Note(lang('@No saved reconciliations for this account yet.'));
        }
    }
}

htm_Card_end();
echo "</div>";
htm_Footer();
