<?php # /user_edit.php v:1.3.1 d:2026-09-15 i:evs
# KRITISK: rolleskift til Administrator opdaterede ALDRIG det egentlige adgangsniveau - bruger-rapporteret
# v1.2.0: gem-logikken opdaterede kun user_role, aldrig user_level - men ALT
# $rLev-tjek i inc/auth.inc.php bruger user_level, ikke user_role. En bruger
# forfremmet til "Administrator" her forblev derfor fastlåst på sit
# oprindelige niveau (typisk 1) på hver eneste niveau-3-spærret side i
# appen, selvom rolle-feltet viste "Administrator". Rettet med
# role_to_level() (inc/db_connect.inc.php). Se [[user-role-level-sync-fix]].
# v1.0.0: KRITISK - denne side havde INTET adgangstjek overhovedet. Enhver
# logget-ind bruger, uanset niveau, kunne redigere en HVILKEN SOM HELST
# brugers rolle og adgangskode via ?id=X - fuld kontoovertagelse, inkl. den
# rigtige administrators. Tilføjet samme admin-rolletjek som user_list.php
# allerede havde. Fundet ved en adgangskontrol-gennemgang.
ob_start();
require_once 'inc/php2htm.lib.php';
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/audit.inc.php';
require_once 'inc/field_visibility.inc.php';

$edit_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Sikkerhed: kun admins må redigere brugere (samme tjek som user_list.php).
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    deny_access_gracefully();
}
$msg = ""; $err = "";

// NYT: findes is_active-kolonnen (db-setup/migrate_user_active_status.php)? Samme "stille degradering hvis ikke
// migreret endnu"-mønster som andre nyere kolonner - beregnes altid, også ved GET, da visnings-feltet nedenfor
// ligger uden for POST-blokken.
$has_active_col = db_has_column($conn, 'users', 'is_active');

// 1. Gem-logik
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_user'])) {
    $_POST['username'] = trim((string)($_POST['username'] ?? ''));
    $username = DB::escape($conn, $_POST['username']);
    $role     = DB::escape($conn, $_POST['user_role']);
    $level    = role_to_level($_POST['user_role']);
    $pw1      = $_POST['new_password'];
    $pw2      = $_POST['confirm_password'];

    // Hent nuværende rolle/brugernavn FØR opdatering, til revisionssporet -
    // en rolleændring (fx forfremmelse til admin) er en sikkerhedsrelevant
    // handling, der før slet ikke blev logget. Bruger-anmodet.
    $before_res = DB::query($conn, "SELECT username, user_role, user_level, is_active FROM users WHERE user_id = $edit_id");
    $before_row = $before_res ? DB::fetch_assoc($before_res) : null;

    // NYT: deaktiver bruger - to selvstændige værn, uafhængige af den eksisterende "kan ikke slette sig
    // selv"-beskyttelse (user_actions.php), som slet ikke dækker deaktivering. Beholder derfor bevidst den
    // EKSISTERENDE værdi uændret for egen konto, i stedet for at stole på om feltet indgik i denne konkrete
    // request.
    $is_own_account = ($edit_id === (int)($_SESSION['user_id'] ?? 0));
    if ($is_own_account) {
        $requested_active = (int)($before_row['is_active'] ?? 1);
    } else {
        $requested_active = isset($_POST['is_active']) ? 1 : 0;
    }
    if ($has_active_col && $requested_active === 0 && !empty($before_row) && $before_row['user_role'] === 'admin') {
        // Kun relevant når MÅLET selv er admin - forhindrer at systemet
        // ender uden en eneste aktiv administrator tilbage, som ingen
        // (heller ikke en anden admin) derefter kunne rette op på uden
        // direkte databaseadgang.
        $active_admins = DB::fetch_assoc(DB::query($conn, "SELECT COUNT(*) AS c FROM users WHERE user_role = 'admin' AND is_active = 1"));
        if ((int)($active_admins['c'] ?? 0) <= 1) {
            $err = lang('@Cannot disable the last active administrator account.');
            $requested_active = 1;
        }
    }

    // RETTET: den SIDSTE aktive administrator kunne nedgraderes (kun deaktivering var spærret) - så fandtes
    // ingen administrator, og user_create.php lader netop da ENHVER indlogget bruger oprette en ny admin.
    if (!empty($before_row) && $before_row['user_role'] === 'admin' && (string)$_POST['user_role'] !== 'admin') {
        $act_sql = $has_active_col ? " AND is_active = 1" : "";
        $admins_left = DB::fetch_assoc(DB::query($conn, "SELECT COUNT(*) AS c FROM users WHERE user_role = 'admin'$act_sql AND user_id <> $edit_id"));
        if ((int)($admins_left['c'] ?? 0) < 1) {
            $err   = lang('@The last active administrator cannot be given another role - make another user administrator first.');
            $role  = 'admin';
            $level = role_to_level('admin');
            $_POST['user_role'] = 'admin';
        }
    }

    // RETTET: en bruger kunne omdøbes til et brugernavn der allerede fandtes (eller til tomt) - to brugere med samme
    // navn, hvor login kun finder den ene. Navnet beholdes da uændret (samme mønster som rolle-tjekket ovenfor).
    $dup_user = $_POST['username'] === '' ? true
        : (bool)DB::fetch_assoc(DB::query($conn, "SELECT user_id FROM users WHERE LOWER(username) = LOWER('$username') AND user_id <> $edit_id"));
    if ($dup_user && !empty($before_row)) {
        $err = lang('@Username already exists');
        $username = DB::escape($conn, (string)$before_row['username']);
        $_POST['username'] = $before_row['username'];
    }

    // RETTET: manglede at opdatere user_level i takt med user_role - rollen ("Administrator" osv.) blev gemt, men
    // det egentlige numeriske adgangsniveau, som alt $rLev-tjek i appen reelt bruger, forblev urørt (typisk
    // fastlåst på 1 siden brugeren blev oprettet). Se role_to_level i inc/db_connect.inc.php for baggrunden.
    $sql = "UPDATE users SET username='$username', user_role='$role', user_level=$level"
         . ($has_active_col ? ", is_active = $requested_active" : "") . "
           WHERE user_id=$edit_id";

    if (DB::query($conn, $sql)) {
        $msg = lang('@User updated successfully');
        $password_changed = false;
        if (!empty($pw1)) {
            if ($pw1 !== $pw2) { $err = lang('@Passwords do not match'); }
            // RETTET (§bugs-batch-20-review): se user_create.php for samme fund
            // - denne side havde INTET mindstekrav til en ny adgangskode ved
            // skift af en eksisterende brugers kodeord.
            elseif (strlen($pw1) < 8) { $err = lang('@Password must be at least 8 characters long'); }
            else {
                $hash = password_hash($pw1, PASSWORD_DEFAULT);
                DB::query($conn, "UPDATE users SET password_hash='$hash' WHERE user_id=$edit_id");
                $msg .= " + " . lang('@Password changed');
                $password_changed = true;
            }
        }
        // Log kun hvis noget reelt ændrede sig (rolle/brugernavn/kodeord) -
        // ikke ved et "gem" der reelt ikke rørte noget. Selve kodeordet
        // logges aldrig, kun AT det blev ændret.
        $active_changed = $has_active_col && $before_row && (int)($before_row['is_active'] ?? 1) !== $requested_active;
        if ($before_row && ($before_row['username'] !== $_POST['username'] || $before_row['user_role'] !== $_POST['user_role'] || (int)$before_row['user_level'] !== $level || $password_changed || $active_changed)) {
            log_action($conn, 'UPDATE_USER', 'users', $edit_id,
                ['username' => $before_row['username'], 'user_role' => $before_row['user_role'], 'user_level' => (int)$before_row['user_level'], 'is_active' => (int)($before_row['is_active'] ?? 1)],
                ['username' => $_POST['username'], 'user_role' => $_POST['user_role'], 'user_level' => $level, 'password_changed' => $password_changed, 'is_active' => $requested_active]);
        }
    } else { $err = DB::error($conn); }
}

// 2. Hent data
$res = DB::query($conn, "SELECT * FROM users WHERE user_id = $edit_id");
$u = DB::fetch_assoc($res);
if (!$u) redirect('user_list.php', '@Not found - it may already have been deleted.', 'error');      // RETTET: hvid side uden menu

htm_Header(capt: '@Edit User');
showMenu();

// NYT: samme højreklik-skjul-mønster som menuen selv, nu for enkelte felter (se inc/field_visibility.inc.php).
// BEMÆRK: denne side er allerede fuldt admin-only (linje 24) - at skjule et felt her for L1/L2 har derfor ingen
// praktisk effekt i dag, da de aldrig kan nå siden overhovedet.
$fv_overrides = get_field_visibility_overrides($conn);
$fv_is_admin  = true; // siden er allerede spærret til admin ovenfor
$fv_uLev      = (int)($_SESSION['user_level'] ?? 1);

if($msg) htm_Alert(text: $msg, type: 'success');
if($err) htm_Alert(text: $err, type: 'error');

// 3. Udnyt htm_Card_ med indbygget form
htm_Card_(
    capt: '@User Settings', 
    wdth: 450, 
    form: 'post'
);

htm_Field(icon: 'fa-user', labl: '@Username', name: 'username', valu: $u['username']);
    
    // Definer alle tilgængelige roller i systemet én gang
    $role_options = [
        'admin'      => 'Administrator',    // Program admin
        'user'       => 'User',             // Alm. bruger
        'accountant' => 'Accountant'        // Revisor
    ];

    // Vis dropdown-menuen én enkelt gang
    htm_Field(
        icon: 'fa-user-tie', 
        labl: '@Role', 
        name: 'user_role', 
        valu: $u['user_role'], 
        type: 'sele', 
        opti: $role_options
    );

    // NYT: en admin kunne FØR kun slette en bruger helt (ofte slet ikke muligt, hvis brugeren er refereret i
    // ledger/audit_log/expenses/time_entries) eller ændre kodeordet. Deaktivering dræber nu en aktiv session med
    // det samme.
    if ($has_active_col) {
        render_hideable_field($fv_overrides, 'user_edit.is_active', $fv_is_admin, $fv_uLev, function() use ($edit_id, $u) {
            $is_self = ($edit_id === (int)($_SESSION['user_id'] ?? 0));
            echo '<div style="margin:10px 0 5px 0; padding:0 5px;">';
            echo '<label style="font-size:0.9em; cursor:' . ($is_self ? 'not-allowed' : 'pointer') . '; display:flex; align-items:center; gap:8px; opacity:' . ($is_self ? '0.6' : '1') . ';">';
            echo '<input type="checkbox" name="is_active" value="1" ' . (!empty($u['is_active']) || !isset($u['is_active']) ? 'checked' : '') . ' ' . ($is_self ? 'disabled' : '') . ' style="width:16px; height:16px;">';
            echo lang('@Account active (unchecking immediately blocks new logins and ends any active session)');
            echo '</label>';
            if ($is_self) {
                echo '<div style="font-size:0.8em; color:var(--text-muted); margin-top:4px;">' . lang('@You cannot disable your own account.') . '</div>';
            }
            echo '</div>';
        });
    }

    echo "<hr style='margin:25px 0; border:none; border-top:1px dashed #ddd;'>";    echo "<h4 style='color:#7f8c8d; margin-bottom:10px;'>" . lang('@Change Password') . "</h4>";
    
    htm_Field(icon: 'fa-lock', labl: '@New Password', name: 'new_password', valu: '', type: 'password', plho: '******');
    htm_Field(icon: 'fa-check-double', labl: '@Confirm Password', name: 'confirm_password', valu: '', type: 'password', plho: '******');

    // 4. Knapper via cont
    // Vi samler Gem og Annuller i samme div via cont-variablen
    htm_Button(
        icon: 'fa-save',
        labl: '@Save User',
        type: 'success',
        attr: 'name="save_user" data-hint="'.lang('@Save changes to this user account').'"',
        styl: 'flex:2; padding:12px; font-weight:bold;',
        cont: '<div style="margin-top:25px; display:flex; gap:10px; border-top:1px solid #eee; padding-top:20px;">' .
              htm_Button(icon: 'fa-times', labl: '@Cancel', type: 'secondary', link: 'user_list.php', styl: 'flex:1; padding:12px;', attr: 'data-hint="'.lang('@Discard changes and return to the user list').'"') .
              '</div>'
    );

htm_Card_end(); 

htm_Footer(); 
ob_end_flush();
?>