<?php # /voucher_archive_export.php v:1.3.1 d:2026-09-15 i:evs
# NY FUNKTION (bruger-anmodet, "kan bogholderen ønske sig mere", runde 26):
# kun fulde systembackups fandtes - ingen måde at hente "alle bilag for år X"
# som en ren pakke til aflevering til revisor, eller til at opfylde
# bogføringslovens 5-års opbevaringspligt uden at grave enkeltvis. Bundler
# de FAKTISKE bilagsfiler (kun udgifter har en fysisk vedhæftet fil -
# invoices har ingen attachment-kolonne, selve fakturaposten/PDF'en er dens
# eget bilag og kan printes/downloades enkeltvist fra invoice_view.php,
# nævnes derfor kun i CSV-oversigten, ikke som en fabrikeret fil i ZIP'en -
# se §fabricated-cvr-bank-details-bug for hvorfor vi aldrig lader som om
# data findes, når det ikke gør). Admin-only, samme niveau som backup.php,
# da eksporten samler følsomme regnskabsdata + bilag i én downloadbar fil.
$rLev = 3;
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';

function csv_safe($v) {
    if (!is_string($v) || $v === '') return $v;
    return (strpbrk($v[0], '=+-@') !== false) ? "'" . $v : $v;
}

// Året er regnskabsåret (opkaldt efter sit slutår) - før altid 1/1-31/12, også ved et forskudt regnskabsår
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)substr(tc_fiscal_year_bounds($conn)[1], 0, 4);

if (isset($_GET['download']) && $_GET['download'] == '1') {
    if (!class_exists('ZipArchive')) {
        die(lang('@PHP ZipArchive extension is not enabled on this server.'));
    }

    [$ys, $ye] = tc_fiscal_year_of($conn, $year);
    $backupDir = 'backups/';
    if (!is_dir($backupDir)) mkdir($backupDir, 0755);
    $zipName = "Bilagsarkiv_{$year}_" . date('Y-m-d_Hi') . '.zip';
    $zipPath = $backupDir . $zipName;

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
        die(lang('@ZIP creation failed'));
    }

    $csv_rows = [];
    $csv_rows[] = [lang('@Type'), lang('@Voucher No'), lang('@Date'), lang('@Counterpart'), lang('@Amount'), lang('@Attachment')];

    // --- Udgifter: de eneste poster der reelt kan have en fysisk vedhæftet fil ---
    $res_e = DB::query($conn, "SELECT exp_id, exp_date, supplier, amount, voucher_no, attachment, no_attachment_reason
        FROM expenses WHERE is_cancelled = 0 AND voucher_no IS NOT NULL AND exp_date BETWEEN '$ys' AND '$ye'
        ORDER BY exp_date ASC");      // RETTET: ubogførte kladder er ingen bilag og hørte ikke med i bilagsarkivet
    $attached_count = 0;
    if ($res_e) {
        while ($e = DB::fetch_assoc($res_e)) {
            $has_file = false;
            if (!empty($e['attachment'])) {
                $local_path = get_tc_doc($e['attachment']);
                if ($local_path && file_exists($local_path)) {
                    $safe_name = 'bilag_' . $e['exp_id'] . '_' . basename($e['attachment']);
                    $zip->addFile($local_path, 'udgifter/' . $safe_name);
                    $has_file = true;
                    $attached_count++;
                }
            }
            $csv_rows[] = [
                lang('@Expense'),
                csv_safe($e['voucher_no'] ?? ''),
                $e['exp_date'],
                csv_safe($e['supplier'] ?? ''),
                fmt_dk_input((float)$e['amount']),
                $has_file ? lang('@Included in ZIP') : ($e['no_attachment_reason'] ? lang('@Exempt') . ': ' . csv_safe($e['no_attachment_reason']) : lang('@Missing')),
            ];
        }
    }

    // --- Fakturaer: ingen fysisk fil at bundle - kun med i selve oversigten,
    // så revisoren ved de findes og kan tilgås/printes fra systemet ---
    // RETTET: fakturaerne og kreditnotaerne HAR nu en fil - den arkiverede PDF (inc/invoice_pdf_archive.inc.php,
    // BEK 811/2026: opbevaring af bilag) - men den kom ikke med i årets bilagsarkiv. Den lægges nu i ZIP'en.
    require_once __DIR__ . '/inc/invoice_pdf_archive.inc.php';
    // RETTET: en faktura i fremmed valuta stod med sit valutabeløb uden kurs - oversigtens øvrige beløb (udgifterne)
    // er i bogføringsvalutaen, så kolonnen blandede valutaer. Nu omregnet med fakturaens kurs, som i hovedbogen.
    // Kolonnen "Bilagsnr." er bogføringens bilagsnummer (journal.voucher_no) - før stod faktura-/kreditnotanummeret (en
    // anden nummerserie) i samme kolonne som udgifternes bilagsnumre; dokumentnummeret står nu ved typen
    $va_jou = db_has_column($conn, 'invoices', 'jou_id');
    $res_i = DB::query($conn, "SELECT i.inv_id, i.invoice_no, i.credit_ref, i.credit_note_no, i.inv_date, c.cust_name, " . ($va_jou ? "j.voucher_no" : "NULL AS voucher_no") . ",
            (SELECT COALESCE(SUM(quantity * price_each " . invoice_discount_sql($conn) . " * (100 + line_vat_rate) / 100.0), 0)
             FROM invoice_lines WHERE inv_id = i.inv_id) * COALESCE(NULLIF(i.exch_rate, 0), 1) AS total
        FROM invoices i JOIN customers c ON i.cust_id = c.cust_id" . ($va_jou ? " LEFT JOIN journal j ON j.jou_id = i.jou_id" : "") . "
        WHERE LOWER(i.inv_status) != 'draft' AND i.inv_date BETWEEN '$ys' AND '$ye'
        ORDER BY i.inv_date ASC");
    if ($res_i) {
        while ($i = DB::fetch_assoc($res_i)) {
            $pdf = invoice_archive_pdf_path($conn, (int)$i['inv_id']);
            $pdf_ok = $pdf && file_exists($pdf) && filesize($pdf) > 0;
            if ($pdf_ok) { $zip->addFile($pdf, 'fakturaer/' . basename($pdf));  $attached_count++; }
            $is_cn = !empty($i['credit_ref']);
            $csv_rows[] = [
                lang($is_cn ? '@Credit Note' : '@Invoice') . ' ' . ($is_cn ? (!empty($i['credit_note_no']) ? 'KN-' . str_pad((string)$i['credit_note_no'], 6, '0', STR_PAD_LEFT) : '') : '#' . str_pad((string)($i['invoice_no'] ?? ''), 6, '0', STR_PAD_LEFT)),
                (string)($i['voucher_no'] ?? ''),
                $i['inv_date'],
                csv_safe($i['cust_name'] ?? ''),
                fmt_dk_input((float)$i['total']),
                $pdf_ok ? lang('@Included in ZIP') : lang('@View/print from Invoice View in the system'),
            ];
        }
    }

    // De øvrige bilag (manuelle posteringer, bankbetalinger, afskrivninger, rykkergebyrer, årsafslutning ...) - LÆS MIG
    // lover "hvert bilag i året", men oversigten havde kun udgifter og fakturaer. Beløbet er bilagets debetsum.
    $va_seen = [];
    foreach (array_slice($csv_rows, 1) as $r) if ((string)$r[1] !== '') $va_seen[(string)$r[1]] = true;
    $res_j = DB::query($conn, "SELECT j.voucher_no, MIN(j.jou_date) AS jou_date, MIN(j.jou_text) AS jou_text,
            SUM(CASE WHEN l.amount > 0 THEN l.amount ELSE 0 END) AS debit
        FROM journal j JOIN ledger l ON l.jou_id = j.jou_id
        WHERE j.voucher_no IS NOT NULL AND j.jou_date BETWEEN '$ys' AND '$ye'
        GROUP BY j.voucher_no ORDER BY MIN(j.jou_date), j.voucher_no");
    while ($res_j && ($j = DB::fetch_assoc($res_j))) {
        if (isset($va_seen[(string)$j['voucher_no']])) continue;
        $csv_rows[] = [lang('@Journal entry'), (string)$j['voucher_no'], $j['jou_date'], csv_safe((string)$j['jou_text']),
                       fmt_dk_input((float)$j['debit']), lang('@View/print from the general ledger in the system')];
    }

    $csv_out = chr(0xEF) . chr(0xBB) . chr(0xBF);
    foreach ($csv_rows as $row) {
        $csv_out .= implode(';', array_map(fn($c) => '"' . str_replace('"', '""', (string)$c) . '"', $row)) . "\r\n";
    }
    $zip->addFromString('bilagsoversigt.csv', $csv_out);
    $zip->addFromString('LÆS MIG.txt',
        sprintf(lang('@Voucher archive for year %d, generated %s. Contains the attached files of the posted expenses, the archived PDF of each invoice and credit note, and a CSV index of every voucher of the year (including those without a file).'), $year, date('Y-m-d H:i'))
    );

    $zip->close();

    if (file_exists($zipPath)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipName . '"');
        header('Content-Length: ' . filesize($zipPath));
        header('Pragma: no-cache');
        header('Expires: 0');
        readfile($zipPath);
        unlink($zipPath);
        exit;
    } else {
        die(lang('@Backup file not found'));
    }
}

htm_Header('@Voucher Archive Export');
showMenu();

htm_Card_('@Voucher Archive Export', 700);
htm_Note(lang('@Download a ZIP bundle of all expense attachments and a full CSV index of every voucher (expenses and non-draft invoices) for a chosen year - useful for handing off to an accountant/auditor, or for the bookkeeping law\'s 5-year retention requirement.'), 'font-size:0.9em; margin-top:-5px;');
echo '<form method="get" style="display:flex; gap:10px; align-items:flex-end;">';
echo '<input type="hidden" name="download" value="1">';
echo '<div><label style="font-size:0.85em; font-weight:bold; display:block;">' . lang('@Year') . '</label>';
echo '<input type="number" name="year" value="' . $year . '" style="width:110px; padding:6px;"></div>';
htm_Button(icon: 'fa-file-zipper', labl: '@Download ZIP', type: 'success', attr: 'data-hint="'.lang('@Download the voucher archive for the selected year').'"');
echo '</form>';
htm_Card_end();

htm_Footer();
