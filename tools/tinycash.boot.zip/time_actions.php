<?php # /time_actions.php v:1.3.0 d:2026-08-30 i:evs
# NY FUNKTION: Timeregistrering (bruger-anmodet) - "Opret faktura af timer".
# Samler ALLE ikke-fakturerede, fakturerbare timer for ét projekt til ÉN
# fakturakladde, med ét fakturalinje PR. registrering (bevidst ingen
# sammenlægning af flere timer til én linje - fuld gennemsigtighed for
# kunden om hvilke dage/opgaver der faktureres, og undgår enhver risiko for
# en forkert sammenlægnings-beregning). Samme "opret altid en KLADDE, aldrig
# bogført direkte"-princip som recurring_invoices/quotes - hele den
# eksisterende bogførings-pipeline (invoice_edit.php -> invoice_post_
# action.php) genbruges uændret derfra.
ob_start();
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/audit.inc.php';

$action  = $_GET['action'] ?? '';
$proj_id = isset($_GET['proj_id']) ? (int)$_GET['proj_id'] : 0;

if ($action !== 'invoice' || $proj_id <= 0) {
    redirect("time_list.php");
}

$proj = DB::fetch_assoc(DB::query($conn, "SELECT * FROM projects WHERE proj_id = $proj_id"));
if (!$proj) {
    redirect("time_list.php?proj_id=$proj_id", '@No unbilled, billable hours found for this project.', 'error');
}
// RETTET: et projekt UDEN kunde gav beskeden "ingen ufakturerede timer" - selvom timerne stod lige på listen, så
// brugeren ikke kunne se hvad der var galt. Fakturaen skal have en kunde: sæt den på projektet først.
if (empty($proj['cust_id'])) {
    redirect("time_list.php?proj_id=$proj_id", '@This project has no customer - choose a customer on the project before invoicing its hours.', 'error');
}
// (som duplikering og tilbud: ingen ny faktura til en kunde i papirkurven)
if (!tc_customer_ok($conn, (int)$proj['cust_id'])) {
    redirect("time_list.php?proj_id=$proj_id", '@The customer is in the trash bin - restore the customer first.', 'error');
}

DB::begin_transaction($conn);
try {
    // Hent kandidat-rækkerne FØR claim, så vi ved præcis hvilke entry_id'er
    // vi forsøger at tage (claimet nedenfor bruger denne liste, ikke en frisk
    // SELECT - undgår at "vinde" nogle rækker der kom til efter selve claimet).
    $entries = [];
    // I datoorden - uden ORDER BY kom fakturalinjerne i tilfældig rækkefølge (typisk oprettelsesordenen, ikke datoerne)
    $res = DB::query($conn, "SELECT * FROM time_entries WHERE proj_id = $proj_id AND is_billable = 1 AND is_invoiced = 0 ORDER BY entry_date ASC, entry_id ASC");
    while ($row = DB::fetch_assoc($res)) { $entries[] = $row; }

    if (empty($entries)) {
        DB::rollback($conn);
        redirect("time_list.php?proj_id=$proj_id", '@No unbilled, billable hours found for this project.', 'error');
    }

    $ids = array_map(fn($e) => (int)$e['entry_id'], $entries);
    $ids_list = implode(',', $ids);

    // Atomisk claim - kun ét "Opret faktura"-forsøg må reelt tage disse
    // præcise rækker, uanset dobbeltklik/to samtidige faner (samme TOCTOU-
    // mønster som resten af appens statusskift). Claimer FØRST, opretter
    // fakturaen bagefter - hvis en anden forespørgsel allerede har taget en
    // eller flere af rækkerne, matcher affected_rows ikke antallet forventet.
    $claim = DB::query($conn, "UPDATE time_entries SET is_invoiced = 1 WHERE entry_id IN ($ids_list) AND is_invoiced = 0");
    if (!$claim || DB::affected_rows($conn, $claim) < count($ids)) {
        throw new Exception(lang('@Some of these hours were already invoiced by another, simultaneous request. Please try again.'));
    }

    $inv_date = date('Y-m-d');
    // RETTET: forfaldet var altid 8 dage - kundens egne betalingsbetingelser (cust_payment_days) blev
    // ignoreret (samme rettelse som quote_actions.php fik)
    $tc_days  = DB::fetch_assoc(DB::query($conn, "SELECT cust_payment_days FROM customers WHERE cust_id = " . (int)$proj['cust_id']));
    $due_days = max(0, (int)($tc_days['cust_payment_days'] ?? 8));
    $due_date = date('Y-m-d', strtotime("+$due_days days"));
    // RETTET: hardkodede 'DKK' ignorerede virksomhedens faktisk konfigurerede basisvaluta (Firmaindstillinger ->
    // Valuta) - tredje forekomst af samme fejl fundet i quote_actions.php og inc/recurring_invoices.inc.php i
    // denne runde, alle tre tydeligvis kopieret fra samme oprindelige mønster.
    $settings     = get_settings($conn);
    $inv_currency = DB::escape($conn, $settings['currency'] ?? 'DKK');
    $ok = DB::query($conn, "INSERT INTO invoices
        (cust_id, inv_date, inv_due_date, inv_status, currency, proj_id)
        VALUES (" . (int)$proj['cust_id'] . ", '$inv_date', '$due_date', 'draft', '$inv_currency', $proj_id)");
    if (!$ok) throw new Exception('Kunne ikke oprette fakturakladde: ' . DB::error($conn));
    $inv_id = DB::insert_id($conn);
    // Timer er ydelser, som til en privatkunde i et andet EU-land beskattes i eget land (art. 45) - ikke EU-OSS. Kan ændres på fakturaen.
    require_once 'inc/oss.inc.php';
    // (også før en OSS-registrering: ydelserne tæller ikke i OSS-tærsklen på 10.000 EUR, som kun gælder fjernsalg af varer m.m.)
    if (oss_off_ready($conn) && oss_is_eu_b2c_customer($conn, (int)$proj['cust_id'])) DB::query($conn, "UPDATE invoices SET inv_oss_off = 1 WHERE inv_id = " . (int)$inv_id);

    foreach ($entries as $e) {
        $txt = DB::escape($conn, date(CONF_DATE_FORMAT, strtotime($e['entry_date'])) . ' - ' . $e['description']);
        DB::query($conn, "INSERT INTO invoice_lines
            (inv_id, line_text, quantity, price_each, line_vat_rate, proj_id)
            VALUES ($inv_id, '$txt', " . (float)$e['hours'] . ", " . (float)$e['hourly_rate'] . ", "
            . (float)$e['line_vat_rate'] . ", $proj_id)");
    }

    DB::query($conn, "UPDATE time_entries SET inv_id = $inv_id WHERE entry_id IN ($ids_list)");

    log_action($conn, 'INVOICE_TIME_ENTRIES', 'time_entries', $proj_id, null,
        ['invoice_id' => $inv_id, 'entry_count' => count($ids), 'entry_ids' => $ids_list]);

    DB::commit($conn);
    redirect("invoice_edit.php?id=$inv_id", '@Draft invoice created from the hours - review it and post it.');
} catch (Exception $e) {
    DB::rollback($conn);
    redirect("time_list.php?proj_id=$proj_id", lang('@Error:') . ' ' . htmlspecialchars($e->getMessage()), 'error');      // (var en hvid side - fx "timerne er allerede faktureret af en samtidig anmodning")
}
?>
