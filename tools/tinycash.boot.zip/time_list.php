<?php # /time_list.php v:1.3.1 d:2026-09-15 i:evs
# NY FUNKTION: Timeregistrering (bruger-anmodet, sidste punkt fra "hvilke
# funktioner mangler TinyCash"-gennemgangen). Oversigt + filtrering + "Opret
# faktura af timer"-handlingen. Kræver Projekt-modulet aktivt - se
# db-setup/migrate_time_tracking.php for hvorfor (hver time skal kunne
# spores til en kunde via sit projekt for at kunne faktureres).
ob_start();
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';
require_once 'inc/audit.inc.php';

$s   = get_settings($conn);
$cur = $s['currency'] ?? 'DKK';
$module_projects = !empty($s['module_projects']) && $s['module_projects'] == '1';

htm_Header('@Time Tracking', 1300);
showMenu();

if (!$module_projects) {
    echo "<div style='max-width:700px; margin:20px auto;'>";
    htm_Card_(capt: '@Time Tracking');
    htm_Banner('<i class="fa fa-triangle-exclamation"></i> ' . lang('@Time tracking requires the Project module to be active, since every logged hour needs to be traceable to a customer through its project. Activate it under Project Settings.'), 'warning');
    htm_Button(icon: 'fa-cog', labl: '@Project Settings', type: 'primary', link: 'project_edit.php?id=0', attr: 'data-hint="'.lang('@Go to project settings to activate the module').'"');
    htm_Card_end();
    echo "</div>";
    htm_Footer();
    ob_end_flush();
    exit;
}

$table_exists = db_has_table($conn, 'time_entries');
if (!$table_exists) {
    echo "<div style='max-width:700px; margin:20px auto;'>";
    htm_Card_(capt: '@Time Tracking');
    htm_Banner('<i class="fa fa-triangle-exclamation"></i> ' . lang('@The time tracking database structure has not been set up yet. Run the migration under System -> Maintenance -> Database migration.'), 'warning');
    htm_Card_end();
    echo "</div>";
    htm_Footer();
    ob_end_flush();
    exit;
}


// --- Filter (projekt) ---
$filter_proj = (int)($_GET['proj_id'] ?? 0);
$proj_opts = ['0' => lang('@All projects')];
// RETTET: "ufakturerede timer"-listen herunder linker også til AFSLUTTEDE projekter (typisk: projektet lukkes, så
// faktureres timerne) - filteret manglede så projektet og viste "Alle projekter", mens listen var filtreret.
$pres = DB::query($conn, "SELECT proj_id, proj_no FROM projects WHERE is_active = 1 OR proj_id = $filter_proj ORDER BY proj_no ASC");
while ($p = DB::fetch_assoc($pres)) { $proj_opts[$p['proj_id']] = $p['proj_no']; }

$tools = htm_Button(icon: 'fa-plus', labl: '@Log Time', type: 'success', link: 'time_entry_edit.php?id=0'.($filter_proj ? '&proj_id='.$filter_proj : ''), attr: 'data-hint="'.lang('@Log a new time entry').'"', echo: false);
htm_Card_(capt: '@Time Tracking', wdth: 1300, tool: $tools);

htm_Note(lang('@Logged hours per project. A time entry never affects the ledger or VAT return - only "Create Invoice from Hours" below does, by generating a normal draft invoice.'), 'font-size:0.9em; margin-top:-5px;');

echo '<form method="get" style="display:flex; gap:10px; align-items:flex-end; margin-bottom:15px;">';
htm_Field(icon: 'fa-folder-open', labl: '@Project', name: 'proj_id', valu: $filter_proj, type: 'sele', opti: $proj_opts, extr: 'onchange="this.form.submit()" bare', wdth: '260px');
echo '</form>';

// --- "Opret faktura af timer" ---
// RETTET: den oprindelige ufaktureret-tid-boks nedenfor viste KUN noget når ét bestemt projekt var valgt i
// filteret - ved "Alle projekter" (eller ved første besøg på siden) var der intet der samlede det på tværs, så
// glemt tid på et projekt man ikke lige havde valgt kunne stå usynligt i årevis. Ny boks her, kun vist ved "Alle
// projekter" (viser ellers samme information dobbelt), grupperer ufaktureret tid PR. projekt (ikke summeret til ét
// tal - en faktura oprettes altid pr. projekt/kunde, aldrig på tværs af flere), med sin egen "Opret faktura"-knap
// pr. række, så en glemt post et hvilket som helst sted bliver synlig med det samme uden at skulle klikke sig
// igennem hvert projekt manuelt.
if ($filter_proj === 0) {
    $all_unbilled_res = DB::query($conn, "SELECT p.proj_id, p.proj_no,
            COUNT(*) AS cnt, COALESCE(SUM(t.hours * t.hourly_rate),0) AS total
        FROM time_entries t JOIN projects p ON t.proj_id = p.proj_id
        WHERE t.is_billable = 1 AND t.is_invoiced = 0
        GROUP BY p.proj_id, p.proj_no
        ORDER BY total DESC");
    $all_unbilled = [];
    if ($all_unbilled_res) { while ($ur = DB::fetch_assoc($all_unbilled_res)) { $all_unbilled[] = $ur; } }

    if (!empty($all_unbilled)) {
        $grand_unbilled_cnt   = array_sum(array_column($all_unbilled, 'cnt'));
        $grand_unbilled_total = array_sum(array_column($all_unbilled, 'total'));
        echo '<div style="margin-bottom:15px; padding:12px 15px; background:var(--bg-panel); border-radius:8px;">';
        echo '<div style="font-weight:bold; margin-bottom:8px;"><i class="fa-solid fa-triangle-exclamation" style="color:var(--color-warning);"></i> '
            . sprintf(lang('@%d unbilled, billable hour entries across %d project(s), totaling %s.'), $grand_unbilled_cnt, count($all_unbilled), fmt_dk($grand_unbilled_total) . ' ' . $cur)
            . '</div>';
        foreach ($all_unbilled as $u) {
            echo '<div style="display:flex; justify-content:space-between; align-items:center; padding:4px 0; border-top:1px solid var(--border-subtle);">';
            echo '<span><a href="time_list.php?proj_id='.(int)$u['proj_id'].'">'.htmlspecialchars($u['proj_no']).'</a> - '
                . sprintf(lang('@%d entries, %s'), (int)$u['cnt'], fmt_dk((float)$u['total']) . ' ' . $cur) . '</span>';
            htm_Button(icon: 'fa-file-invoice', labl: '@Create Invoice from Hours', type: 'success',
                link: 'time_actions.php?action=invoice&proj_id='.(int)$u['proj_id'],
                attr: 'data-hint="' . lang('@Creates a draft invoice from the unbilled hours and opens it') . '" onclick="' . htm_confirm_js('@Create a draft invoice with one line per unbilled hour entry for this project?') . '" style="padding:4px 10px; font-size:0.85em;"');
            echo '</div>';
        }
        echo '</div>';
    }
}

if ($filter_proj > 0) {
    $unbilled_row = DB::fetch_assoc(DB::query($conn,
        "SELECT COUNT(*) AS cnt, COALESCE(SUM(hours * hourly_rate),0) AS total
         FROM time_entries WHERE proj_id = $filter_proj AND is_billable = 1 AND is_invoiced = 0"));
    $unbilled_cnt   = (int)($unbilled_row['cnt'] ?? 0);
    $unbilled_total = (float)($unbilled_row['total'] ?? 0);

    if ($unbilled_cnt > 0) {
        echo '<div style="margin-bottom:15px; padding:12px 15px; background:var(--bg-panel); border-radius:8px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">';
        echo '<div>' . sprintf(lang('@%d unbilled, billable hour entries for this project, totaling %s.'), $unbilled_cnt, fmt_dk($unbilled_total) . ' ' . $cur) . '</div>';
        htm_Button(icon: 'fa-file-invoice', labl: '@Create Invoice from Hours', type: 'success',
            link: 'time_actions.php?action=invoice&proj_id='.$filter_proj,
            attr: 'onclick="' . htm_confirm_js('@Create a draft invoice with one line per unbilled hour entry for this project?') . '" data-hint="'.lang('@Generate a draft invoice from all unbilled hours on this project').'"');
        echo '</div>';
        // (Advarslen om "kun 5 linjer" er fjernet: fakturaformularen viser og gemmer nu alle linjer, også fritekst-
        // linjer fra timer - advarslen fik brugeren til at undgå at rette en helt almindelig kladde.)
    }
}

// --- Tabel ---
$where = $filter_proj > 0 ? "WHERE t.proj_id = $filter_proj" : "";
$res = DB::query($conn, "SELECT t.*, p.proj_no, u.username
    FROM time_entries t
    LEFT JOIN projects p ON t.proj_id = p.proj_id
    LEFT JOIN users u ON t.user_id = u.user_id
    $where
    ORDER BY t.entry_date DESC, t.entry_id DESC");

$headers = ['@Date', '@Project', '@Description', '@User', '@Hours', '@Rate', '@Amount', '@Billable', '@Status', '@Actions'];
$data = [];
$grand_total_hours = 0;

if ($res) {
    while ($row = DB::fetch_assoc($res)) {
        $eid    = (int)$row['entry_id'];
        $amount = (float)$row['hours'] * (float)$row['hourly_rate'];
        $grand_total_hours += (float)$row['hours'];

        if ($row['is_invoiced']) {
            $status_html = '<a href="invoice_edit.php?id='.(int)$row['inv_id'].'" data-hint="' . lang('@Open the invoice the hours are on') . '" style="color:var(--color-primary); font-weight:bold;"><i class="fa-solid fa-file-invoice"></i> ' . lang('@Invoiced') . '</a>';
        } elseif (!$row['is_billable']) {
            $status_html = '<span style="color:var(--text-muted);">' . lang('@Non-billable') . '</span>';
        } else {
            $status_html = '<span style="color:var(--color-warning);">' . lang('@Unbilled') . '</span>';
        }

        $actions = '';
        if (!$row['is_invoiced']) {
            $actions = htm_ActionButtons([
                ['icon' => 'fa-pencil', 'link' => 'time_entry_edit.php?id='.$eid, 'hint' => '@Edit', 'type' => 'primary'],
            ], false);
            $actions .= htm_ConfirmLink(icon: 'fa-trash', labl: '', link: 'time_entry_edit.php?id='.$eid.'&del=1',
                mess: '@Are you sure you want to delete this time entry?',
                type: 'danger', styl: 'display:inline-block; margin-left:4px; padding:4px 8px;', attr: 'data-hint="' . lang('@Delete the time entry (you are asked first)') . '"', echo: false);
        }

        $data[] = [
            date(CONF_DATE_FORMAT, strtotime($row['entry_date'])),
            $row['proj_no'] ? htmlspecialchars($row['proj_no']) : '<span style="color:var(--text-muted);">—</span>',
            htmlspecialchars($row['description'] ?? ''),
            htmlspecialchars($row['username'] ?? '—'),
            fmt_dk((float)$row['hours']),
            fmt_dk((float)$row['hourly_rate']) . ' ' . $cur,
            fmt_dk($amount) . ' ' . $cur,
            $row['is_billable'] ? lang('@Yes') : lang('@No'),
            $status_html,
            $actions,
        ];
    }
}

if (empty($data)) {
    echo "<p style='padding:30px; text-align:center; color:var(--text-muted);'>" . lang('@No time entries logged yet.') . "</p>";
} else {
    htm_Table($headers, $data, 'timeTbl', 100, '', true,
        ['width:100px;', 'width:100px;', '', 'width:110px;', 'width:80px; text-align:right;', 'width:110px; text-align:right;', 'width:120px; text-align:right;', 'width:80px;', 'width:120px;', 'width:90px;'],
        '500px', 'time_entries.csv');
    echo '<div style="text-align:right; font-weight:bold; padding:10px 0;">' . lang('@Total Hours') . ': ' . fmt_dk($grand_total_hours) . '</div>';
}

htm_Card_end();
htm_Footer();
ob_end_flush();
?>
