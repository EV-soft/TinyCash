<?php # /bank_import_step1.php v:1.3.1 d:2026-09-15 i:evs
# Trin 1 af bankimport: upload/forhåndsvisning af CSV samt gem/hent af
# kolonne-mapping-profiler (settings-tabellen). Selve importen sker i
# bank_import_process.php.
ob_start();
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php'; 

$upload_dir = 'uploads/';
$suggested = ['date' => '', 'text' => '', 'amount' => '', 'skip' => '1'];
$preview_data = [];
$msg_html = '';
$original_filename = '';

// Bankkontoen kontoudtoget hører til - afstemningen bogfører på den (inc/reconcile.inc.php, tc_bank_line_account()).
// Før landede et udtog fra fx opsparingskontoen altid på standard-bankkontoen.
require_once 'inc/accounts.inc.php';
$bi_std   = (int)setting('conf_acc_bank', 5000);
$bi_banks = [];
$bi_res = DB::query($conn, "SELECT acc_id, acc_name" . acc_status_col($conn) . " FROM accounts WHERE acc_type = 'bank' AND " . acc_visible_sql($conn, '', [$bi_std]) . " ORDER BY " . acc_order_sql($conn) . "acc_id");
while ($bi_res && ($br = DB::fetch_assoc($bi_res))) $bi_banks[(int)$br['acc_id']] = $br['acc_id'] . ' - ' . acc_label($br['acc_name'], $br['acc_status'] ?? null);
$bi_acc = (int)($_POST['import_acc'] ?? 0);
if (!isset($bi_banks[$bi_acc]) || $bi_acc === $bi_std) $bi_acc = 0;

// --- 1. GEM PROFIL LOGIK ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['profile_name'])) {
    $p_name = strtolower(DB::real_escape_string($conn, $_POST['profile_name']));
    $key = 'import_profile_' . $p_name;
    $setup = [
        'col_date'   => $_POST['col_date'],
        'col_text'   => $_POST['col_text'],
        'col_amount' => $_POST['col_amount'],
        'skip_lines' => $_POST['skip_lines']
    ];
    // SIKKERHEDSRETTELSE (ansvarligt indrapporteret, SQL-injection/CWE-89):
    // $val blev tidligere interpoleret RÅT i SQL-strengen nedenfor.
    // json_encode() escaper kun JSON-syntaks (", \, kontroltegn) - IKKE et
    // enkelt anførselstegn, som er det tegn der afgrænser SQL-strengen. En
    // ondsindet kolonneværdi (fx col_date = "x'); DROP TABLE ...--") kunne
    // dermed bryde ud af '$val'-literalen. $key blev allerede escaped
    // korrekt via DB::real_escape_string() ovenfor - $val manglede samme
    // beskyttelse. Siden sætter heller ikke $rLev, så enhver logget-ind
    // bruger (ikke kun admin) kunne udnytte det. Rettet ved at escape $val
    // på samme måde som $key, jf. det indrapporterede forslag.
    $val = DB::escape($conn, json_encode($setup));
    // RETTET 2026-08-19: "ON DUPLICATE KEY UPDATE" er ren MySQL-syntaks og fejlede stille på SQLite (bekræftet:
    // SQLSTATE[HY000] syntax error) - DB::query fangede fejlen og returnerede false, men resultatet blev aldrig
    // tjekket, så "gemt"-beskeden vistes uanset. Følger nu samme mønster som
    // annual_report.php/company_settings.php.
    $upsert_sql = DB::is_sqlite()
        ? "INSERT INTO settings (setting_key, setting_value) VALUES ('$key', '$val')
           ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value"
        : "INSERT INTO settings (setting_key, setting_value) VALUES ('$key', '$val')
           ON DUPLICATE KEY UPDATE setting_value = '$val'";
    $save_ok = DB::query($conn, $upsert_sql);
    $msg_html = $save_ok
        ? htm_Alert(text: '@Profile saved successfully!', type: 'success', echo: false)
        : htm_Alert(text: lang('@Error: Could not save profile.') . ' (' . htmlspecialchars((string)DB::error($conn)) . ')', type: 'danger', echo: false);
}

// --- 2. HENT PROFIL LOGIK ---
if (isset($_GET['load_profile']) && !empty($_GET['load_profile'])) {
    $p_json = setting('import_profile_' . (string)$_GET['load_profile']);
    if ($p_json !== '') {
        $p_data = json_decode($p_json, true);
        $suggested['date']   = $p_data['col_date'];
        $suggested['text']   = $p_data['col_text'];
        $suggested['amount'] = $p_data['col_amount'];
        $suggested['skip']   = $p_data['skip_lines'] ?? '1';
    }
}

// --- 3. HÅNDTER UPLOAD ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
    $original_filename = basename($_FILES['csv_file']['name']);

    // RETTET: KRITISK - det uploadede filnavn kom FØR direkte fra klienten, ubeskåret og med endelsen
    // ukontrolleret, lige ind i stien i uploads/ (offentligt tilgængelig uden login). uploads/.htaccess blokerer
    // nu også farlige endelser direkte på Apache-niveau som endnu et lag.
    $ext = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
    // Et CAMT-kontoudtog (ISO 20022 XML) har fast struktur - indlæses direkte uden kolonnevalg (inc/camt.inc.php)
    if ($ext === 'xml') {
        require_once 'inc/camt.inc.php';
        try {
            if ((int)($_FILES['csv_file']['error'] ?? 1) !== UPLOAD_ERR_OK) throw new Exception(lang('@Error: Could not save file.'));
            $camt = camt_import($conn, camt_parse((string)file_get_contents($_FILES['csv_file']['tmp_name'])), 'camt', $bi_acc);
        } catch (Exception $e) {
            redirect('bank_import_step1.php', lang('@CAMT import failed:') . ' ' . htmlspecialchars($e->getMessage()), 'error');
        }
        flash(sprintf(lang('@%d transaction(s) imported.'), $camt['imported']));
        if ($camt['duplicates'] > 0) flash(sprintf(lang('@%d row(s) were skipped because a transaction with the same date, text and amount was already imported previously.'), $camt['duplicates']), 'info');
        if ($camt['foreign'] > 0) flash(sprintf(lang('@%d transaction(s) are in another currency than the accounts - marked with the currency code in the text.'), $camt['foreign']), 'warning');
        redirect('reconcile_list.php');
    }
    if ($ext !== 'csv') {
        redirect('bank_import_step1.php', '@Error: Only CSV or CAMT (XML) bank statements can be imported.', 'error');      // (var en hvid side)
    }
    // Tilfældigt filnavn i stedet for det forudsigelige "time()_originalnavn"
    // - samme begrundelse som expense_edit.php's bilags-upload (se
    // [[bugs-batch-18-review]]): uploads/ er offentligt tilgængelig, så et
    // gættet/kendt filnavn ville afsløre andre brugeres importerede CSV-data.
    $file_path = $upload_dir . 'BANK_' . date('Ymd') . '_' . bin2hex(random_bytes(8)) . '.csv';

    if (move_uploaded_file($_FILES['csv_file']['tmp_name'], $file_path)) {
        $handle = fopen($file_path, "r");
        // Skilletegnet: det af ; TAB , der deler de første linjer i lige mange kolonner (flest) - tabulator med, da flere
        // nordiske bankers .txt-udtræk er tabulatorseparerede. Kun at tælle tegnet i første linje valgte komma i en
        // semikolonfil uden overskrift, hvor tekst og beløb ("Husleje, jan";"-1.234,56") selv har kommaer.
        $dl_lines = [];
        while (count($dl_lines) < 6 && ($dl_l = fgets($handle)) !== false) if (trim($dl_l) !== '') $dl_lines[] = $dl_l;
        $delimiter = ',';  $dl_best = -1;
        foreach ([';', "\t", ','] as $dl_c) {
            $dl_cols = array_map(fn($l) => count(str_getcsv($l, $dl_c, '"', '')), $dl_lines);
            if (!$dl_cols || max($dl_cols) < 2) continue;
            $dl_score = (count(array_unique($dl_cols)) === 1 ? 1000 : 0) + min($dl_cols);      // ensartet først, så flest kolonner
            if ($dl_score > $dl_best) { $dl_best = $dl_score;  $delimiter = $dl_c; }
        }
        rewind($handle);

        while (($data = fgetcsv($handle, 0, $delimiter, '"', '')) !== FALSE) {
            // (samme omkodning som bank_import_process.php - ellers var forhåndsvisningen af æøå-tekster tom)
            if (empty($preview_data) && isset($data[0])) $data[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$data[0]);
            foreach ($data as $di => $dv) if ($dv !== null && !mb_check_encoding((string)$dv, 'UTF-8')) $data[$di] = mb_convert_encoding((string)$dv, 'UTF-8', 'Windows-1252');
            $preview_data[] = $data;
            if (count($preview_data) >= 6) break;
        }
        fclose($handle);

        // Auto-detect kolonner hvis ingen profil er indlæst
        if (!empty($preview_data) && empty($suggested['date'])) {
            foreach ($preview_data[0] as $idx => $val) {
                $col = $idx + 1;
                $val = mb_strtolower($val);
                if (preg_match('/payout date|date|dato/i', $val)) $suggested['date'] = $col;
                if (preg_match('/merchant name|tekst|text/i', $val)) $suggested['text'] = $col;
                if (preg_match('/gross amount|amount|beløb/i', $val)) $suggested['amount'] = $col;
            }
        }
    } else {
        $msg_html = htm_Alert(text: "@Error: Could not save file.", type: 'danger', echo: false);
    }
}

// --- 4. RENDER SIDE ---
htm_Header(capt: '@Bank Import', mwidth: 1000);
showMenu();
echo $msg_html;

htm_Card_(capt: '@Configure Import', wdth: 1000);

// Hent gemte profiler til dropdown-opsætning
$res = DB::query($conn, "SELECT setting_key FROM settings WHERE setting_key LIKE 'import_profile_%' ORDER BY setting_key ASC");
$profile_options = ['' => '-- ' . lang('@Select a profile...') . ' --'];
while ($row = DB::fetch_assoc($res)) {
    $name = str_replace('import_profile_', '', $row['setting_key']);
    $profile_options[$name] = ucfirst($name);
}

// Profil-vælger via InputGroup
echo '<form method="get" id="profile_form" style="margin-bottom:25px;">';
htm_Field(
    icon: 'fa-folder-open', 
    labl: '@Load Saved Profile', 
    name: 'load_profile', 
    valu: ($_GET['load_profile'] ?? ''), 
    type: 'sele', 
    opti: $profile_options, 
    extr: 'onchange="document.getElementById(\'profile_form\').submit();"',
    echo: true
);
echo '</form>';
?>

<?php if (empty($preview_data)): ?>
    <form method="post" enctype="multipart/form-data" style="text-align:center; padding:40px;">
        <?php csrf_field(); ?>
        <div style="margin-bottom: 25px;">
            <input type="file" name="csv_file" accept=".csv,.xml,text/csv,text/xml,application/xml" required style="font-size: 1.1em;">
        </div>
        <?php htm_Note(lang('@CSV from any bank (you choose the columns), or a CAMT.053 bank statement in XML (ISO 20022) - read directly without setup.'), 'font-size:0.9em; margin:-10px 0 20px;'); ?>
        <?php if (count($bi_banks) > 1): ?>
            <div style="max-width:420px; margin:0 auto 20px; text-align:left;">
                <?php htm_Field(icon: 'fa-building-columns', labl: '@Bank account of the statement', name: 'import_acc', valu: (string)$bi_std, type: 'sele', opti: $bi_banks, hint: '@The account the statement comes from - the lines are posted to it during the bank reconciliation.', echo: true); ?>
            </div>
        <?php endif; ?>
        <?php 
        htm_Button(
            icon: 'fa-upload',
            labl: '@Upload and Preview Data',
            type: 'primary',
            attr: 'type="submit" data-hint="'.lang('@Read the file and show a preview before importing').'"',
            echo: true
        );
        ?>
    </form>
<?php else: ?>
    <div style="margin-bottom: 15px; padding: 10px 15px; background: #e8f4fd; border-left: 4px solid #3498db; border-radius: 4px; font-size: 0.95em; color: #2c3e50; font-weight: 600;">
        <i class="fa-solid fa-file-csv" style="color: #3498db; margin-right: 8px; font-size: 1.1em;"></i>
        <?php echo lang('@Active File:') . ' ' . htmlspecialchars($original_filename); ?>
    </div>

    <style>
        #preview_tbl th { font-size: 11px !important; padding: 4px 6px !important; }
        #preview_tbl td { font-size: 11px !important; font-family: monospace !important; padding: 3px 6px !important; }
    </style>
    
    <div style="overflow-x:auto; margin-bottom:25px;">
        <?php
        $headers = [];
        for($i=1; $i <= count($preview_data[0]); $i++) {
            $headers[] = lang('@Col.') . ' ' . $i;
        }

        $formatted_preview = [];
        foreach($preview_data as $row) {
            $formatted_row = [];
            foreach($row as $idx => $cell) {
                $formatted_row[] = htmlspecialchars($cell);
            }
            $formatted_preview[] = $formatted_row;
        }

        htm_Table(
            head: $headers, 
            data: $formatted_preview, 
            name: 'preview_tbl', 
            limt: 0, 
            echo: true
        );
        ?>
    </div>

    <form method="post" action="bank_import_process.php" id="import_config_form" onsubmit="return tcBuildColumnMap(this);">
        <?php csrf_field(); ?>
        <input type="hidden" name="file_path" value="<?php echo htmlspecialchars($file_path); ?>">
        <input type="hidden" name="delimiter" value="<?php echo htmlspecialchars($delimiter); ?>">
        <input type="hidden" name="import_acc" value="<?php echo (int)$bi_acc; ?>">
        <input type="hidden" name="col_count" value="<?php echo count($preview_data[0]); ?>">

        <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:15px; margin-bottom:20px;">
            <?php
            htm_Field(icon: 'fa-calendar', labl: '@Date Column #', name: 'col_date', valu: $suggested['date'], type: 'number', extr: 'required', echo: true);
            htm_Field(icon: 'fa-font', labl: '@Text Column #', name: 'col_text', valu: $suggested['text'], type: 'number', extr: 'required', echo: true);
            htm_Field(icon: 'fa-money-bill', labl: '@Amount Column #', name: 'col_amount', valu: $suggested['amount'], type: 'number', extr: 'required', echo: true);
            ?>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 2fr auto; gap:15px; margin-top:15px; align-items: end;">
            <div>
                <?php htm_Field(icon: 'fa-step-forward', labl: '@Skip Lines', name: 'skip_lines', valu: $suggested['skip'], type: 'number', echo: true); ?>
            </div>
            <div>
                <?php 
                htm_Field(
                    icon: 'fa-save', 
                    labl: '@Save Configuration as Profile', 
                    name: 'profile_name', 
                    valu: '', 
                    type: 'text', 
                    extr: 'placeholder="'.lang('@Name profile...').'"', 
                    echo: true
                ); 
                ?>
            </div>
            <div style="padding-bottom: 2px;">
                <?php
                htm_Button(
                    icon: 'fa-floppy-o',
                    labl: '@Save Profile Only',
                    type: 'info',
                    attr: 'type="submit" name="save_only" formaction="bank_import_step1.php" style="height: 44px; display: flex; align-items: center;" data-hint="'.lang('@Save this column mapping as a reusable profile, without importing now').'"',
                    echo: true
                );
                ?>
            </div>
        </div>
        
        <hr style="margin:25px 0; border:0; border-top:1px solid #eee;">
        
        <?php
        htm_Button(
            icon: 'fa-arrow-right',
            labl: '@Complete Import',
            type: 'success',
            attr: 'type="submit" style="padding:15px; font-size:1.1em; width:100%;" data-hint="'.lang('@Import the mapped transactions into the reconciliation queue').'"',
            echo: true
        );
        ?>
    </form>
    <script>
    // RETTET (§bugs-batch-24-review): ALVORLIGT FUND - denne formular
    // sendte ALDRIG det map[]-array bank_import_process.php rent faktisk
    // læser (map[kolonneindeks] = 'trans_date'/'text_val'/'amount'/'ignore').
    // Den sendte kun col_date/col_text/col_amount (kolonneNUMRE, ikke et
    // map[]), som bank_import_process.php slet ikke kender noget til.
    // Resultatet: $_POST['map'] var altid udefineret dér, foreach()-løkken
    // der rent faktisk udtrækker dato/tekst/beløb fra CSV-rækken kørte
    // derfor ALDRIG, og hver eneste importeret transaktion endte i
    // bank_statement_temp med dagens dato, tom tekst og 0 kr i beløb -
    // ALDRIG de rigtige CSV-data. Ingen fejl blev vist ("msg=imported&
    // count=N" så ud som en succesfuld import). Bekræftet direkte mod en
    // rigtig import: to rækker med reelle beløb endte som ÉN tom 0-kr-
    // "dublet" (den blanke pladsholder-række matchede sig selv i
    // dublet-tjekket). Bygger nu det rigtige map[]-array her i browseren
    // ud fra de samme tre kolonnenumre, umiddelbart før formularen sendes.
    function tcBuildColumnMap(form) {
        var colCount = parseInt(form.col_count.value, 10) || 0;
        var dateCol   = parseInt(form.col_date.value, 10);
        var textCol   = parseInt(form.col_text.value, 10);
        var amountCol = parseInt(form.col_amount.value, 10);
        for (var i = 1; i <= colCount; i++) {
            var fieldName = 'ignore';
            if (i === dateCol)        fieldName = 'trans_date';
            else if (i === textCol)   fieldName = 'text_val';
            else if (i === amountCol) fieldName = 'amount';
            var input = document.createElement('input');
            input.type = 'hidden';
            // map[]-nøglerne er 0-baserede array-indekser (fra fgetcsv()),
            // mens kolonnenumrene vist til brugeren ("Kolonne #") er
            // 1-baserede - konverteres her (i - 1).
            input.name = 'map[' + (i - 1) + ']';
            input.value = fieldName;
            form.appendChild(input);
        }
        return true;
    }
    </script>
<?php endif;

htm_Card_end();
htm_Footer();
ob_end_flush();
?>