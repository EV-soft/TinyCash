<?php # /search.php v:1.3.2 d:2026-09-15 i:evs
# Global søgning på tværs af systemet (§bogholder-behov-gennemgang
# 2026-09-01) - før fandtes kun lokale filtre pr. liste (fakturaer, udgifter,
# kunder hver for sig); ingen måde at slå "den faktura til kunde X fra marts"
# op uden at vide hvilken liste den lå i og lede der. Søger på tværs af
# kunder/fakturaer/udgifter/leverandører/produkter i én omgang og linker
# direkte videre til hver post.
#
# Leverandørsøgningen degraderer stille (samme @-mønster som aging_report.php)
# hvis leverandørmodulets tabel ikke er migreret endnu.
#
# GET (ikke POST) med query-param 'q' - bevidst, så en søgning kan bogmærkes/
# deles/åbnes direkte via URL, samme konvention som fx trial_balance.php's
# periodevalg.
ob_start();
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';

$q = trim($_GET['q'] ?? '');
$RESULT_LIMIT = 20;

htm_Header('@Search');
showMenu();

echo "<div style='max-width:1000px; margin:0 auto; padding:10px;'>";

echo '<form method="get" style="margin-bottom:20px;">';
echo '<div style="display:flex; gap:10px;">';
echo '<input type="text" name="q" value="'.htmlspecialchars($q).'" autofocus placeholder="'.htmlspecialchars(lang('@Search customers, invoices, expenses, suppliers, products, quotes, assets, time entries...')).'" style="flex:1; padding:12px; font-size:1.1em; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-card); color:var(--text-main);">';
htm_Button('fa-search', '@Search', 'primary', '', '', 'type="submit"');
echo '</div>';
echo '</form>';

if (strlen($q) < 2) {
    if ($q !== '') {
        htm_Alert(lang('@Please enter at least 2 characters.'), 'info', 700, true);
    }
    echo "</div>";
    htm_Footer();
    ob_end_flush();
    exit;
}

// RETTET: % og _ i søgeteksten virkede som jokertegn - "AB_12" fandt også "ABX12", og "%" fandt alt. De matches nu
// bogstaveligt (backslash som escape-tegn; SQLite skal have ESCAPE angivet, MySQL bruger backslash som standard).
$like_q = DB::escape($conn, $q);
if (DB::is_sqlite()) $like_q = str_replace('\\', '\\\\', $like_q);      // (MySQL's escape fordobler allerede backslash)
$like = '%' . str_replace(['%', '_'], ['\%', '\_'], $like_q) . '%';
$lesc = DB::is_sqlite() ? " ESCAPE '\'" : '';
// Uden hensyn til store/små bogstaver - også æ/ø/å: SQLite's LIKE kender kun A-Z ("ælling" fandt ikke "Ælling");
// tc_lower() er registreret i inc/db_connect.inc.php. MySQL's utf8mb4-sortering klarer det selv.
$like_lc = mb_strtolower($like, 'UTF-8');
$L = fn(string $col): string => DB::is_sqlite() ? "tc_lower($col) LIKE '$like_lc'$lesc" : "$col LIKE '$like'";
$any_results = false;

// --- KUNDER ---
// RETTET: kunder og leverandører i papirkurven blev fundet og åbnet som almindelige, aktive poster
$cust_res = DB::query($conn, "SELECT cust_id, cust_name, cust_email, cust_cvr FROM customers
    WHERE ({$L('cust_name')} OR {$L('cust_email')} OR {$L('cust_cvr')}) AND " . customers_active_filter($conn) . "
    ORDER BY cust_name LIMIT $RESULT_LIMIT");
$cust_rows = [];
if ($cust_res) { while ($r = DB::fetch_assoc($cust_res)) { $cust_rows[] = $r; } }

if (!empty($cust_rows)) {
    $any_results = true;
    htm_Card_(sprintf(lang('@Customers (%d)'), count($cust_rows)), 1000);
    $data = [];
    foreach ($cust_rows as $r) {
        $data[] = [
            '<a href="customer_statement.php?id=' . (int)$r['cust_id'] . '">' . htmlspecialchars($r['cust_name']) . '</a>',
            htmlspecialchars($r['cust_email'] ?? ''),
            htmlspecialchars($r['cust_cvr'] ?? ''),
        ];
    }
    htm_Table(['@Name', '@Email', tc_company_id_short()], $data, 'search_cust_tbl', 100);      // (landets firma-id, ikke altid "CVR")
    htm_Card_end();
}

// --- FAKTURAER ---
// RETTET: kreditnotaer (intet invoice_no) stod som "Kladde" og kunne ikke findes på deres eget nummer (KN-000003)
require_once __DIR__ . '/inc/invoice_layouts.inc.php';
$sr_has_cn = il_column_exists($conn, 'invoices', 'credit_note_no');
$sr_cn_no  = (int)preg_replace('/\D/', '', preg_replace('/^\s*KN-?/i', '', $q));
$sr_cn_sql = ($sr_has_cn && $sr_cn_no > 0 && preg_match('/^\s*(KN-?)?\d+\s*$/i', $q)) ? " OR i.credit_note_no = $sr_cn_no" : '';
$sr_cn_sql .= preg_match('/^\s*#\s*0*(\d+)\s*$/', $q, $sr_im) ? " OR i.invoice_no = " . (int)$sr_im[1] : '';      // (fakturanummeret vises som "#1005")
$inv_res = DB::query($conn, "SELECT i.inv_id, i.invoice_no, i.inv_status, i.inv_date, i.credit_ref" . ($sr_has_cn ? ", i.credit_note_no" : "") . ", c.cust_name
    FROM invoices i JOIN customers c ON i.cust_id = c.cust_id
    WHERE {$L('i.invoice_no')} OR {$L('c.cust_name')} OR {$L('i.cust_reference')}$sr_cn_sql
    ORDER BY i.inv_date DESC LIMIT $RESULT_LIMIT");
$inv_rows = [];
if ($inv_res) { while ($r = DB::fetch_assoc($inv_res)) { $inv_rows[] = $r; } }

if (!empty($inv_rows)) {
    $any_results = true;
    htm_Card_(sprintf(lang('@Invoices (%d)'), count($inv_rows)), 1000);
    $data = [];
    foreach ($inv_rows as $r) {
        $label = !empty($r['invoice_no']) ? '#' . $r['invoice_no']
               : (!empty($r['credit_ref']) ? lang('@Credit Note') . ' KN-' . str_pad((string)($r['credit_note_no'] ?? ''), 6, '0', STR_PAD_LEFT) : lang('@Draft'));
        $data[] = [
            '<a href="invoice_view.php?id=' . (int)$r['inv_id'] . '">' . htmlspecialchars($label) . '</a>',
            htmlspecialchars($r['cust_name']),
            date(CONF_DATE_FORMAT, strtotime($r['inv_date'])),
            tc_invoice_status_label($r['inv_status']),      // ("Sent"/"Paid" stod på engelsk for en dansk bruger)
        ];
    }
    htm_Table(['@Invoice', '@Customer', '@Date', '@Status'], $data, 'search_inv_tbl', 100);
    htm_Card_end();
}

// --- UDGIFTER ---
// RETTET: en udgift kunne ikke findes på sit bilagsnummer (bogholderens mest almindelige opslag: "bilag 117"), og en
// annulleret udgift stod som "Bogført". Et rent tal søges nu også som bilagsnummer; annullerede vises som annulleret.
$exp_voucher_sql = preg_match('/^\d{1,9}$/', $q) ? " OR voucher_no = " . (int)$q : '';
$exp_res = DB::query($conn, "SELECT exp_id, exp_date, supplier, description, amount, voucher_no, is_cancelled FROM expenses
    WHERE {$L('supplier')} OR {$L('description')}$exp_voucher_sql
    ORDER BY exp_date DESC LIMIT $RESULT_LIMIT");
$exp_rows = [];
if ($exp_res) { while ($r = DB::fetch_assoc($exp_res)) { $exp_rows[] = $r; } }

if (!empty($exp_rows)) {
    $any_results = true;
    htm_Card_(sprintf(lang('@Expenses (%d)'), count($exp_rows)), 1000);
    $data = [];
    foreach ($exp_rows as $r) {
        $data[] = [
            '<a href="expense_edit.php?id=' . (int)$r['exp_id'] . '">' . htmlspecialchars($r['supplier']) . '</a>',
            htmlspecialchars($r['description']),
            date(CONF_DATE_FORMAT, strtotime($r['exp_date'])),
            fmt_dk((float)$r['amount']),
            !empty($r['is_cancelled']) ? '<span style="color:var(--color-danger);">' . lang('@Cancelled') . '</span>'
                : (empty($r['voucher_no']) ? '<span style="color:var(--text-muted);">' . lang('@Draft') . '</span>' : lang('@Posted') . ' (' . lang('@Voucher') . ' ' . (int)$r['voucher_no'] . ')'),
        ];
    }
    htm_Table(['@Supplier', '@Description', '@Date', '@Amount', '@Status'], $data, 'search_exp_tbl', 100);
    htm_Card_end();
}

// --- LEVERANDØRER (leverandørmodul kan mangle - degraderer stille) ---
$sup_res = @DB::query($conn, "SELECT supplier_id, supplier_name, cvr FROM suppliers
    WHERE {$L('supplier_name')} AND " . suppliers_active_filter($conn) . " ORDER BY supplier_name LIMIT $RESULT_LIMIT");
if ($sup_res !== false) {
    $sup_rows = [];
    while ($r = DB::fetch_assoc($sup_res)) { $sup_rows[] = $r; }
    if (!empty($sup_rows)) {
        $any_results = true;
        htm_Card_(sprintf(lang('@Suppliers (%d)'), count($sup_rows)), 1000);
        $data = [];
        foreach ($sup_rows as $r) {
            $data[] = [
                '<a href="supplier_statement.php?id=' . (int)$r['supplier_id'] . '">' . htmlspecialchars($r['supplier_name']) . '</a>',
                htmlspecialchars($r['cvr'] ?? ''),
            ];
        }
        htm_Table(['@Name', tc_company_id_short()], $data, 'search_sup_tbl', 100);
        htm_Card_end();
    }
}

// --- PRODUKTER ---
$prod_res = DB::query($conn, "SELECT prod_id, prod_sku, prod_name, prod_price, prod_stock FROM products
    WHERE {$L('prod_name')} OR {$L('prod_sku')}
    ORDER BY prod_name LIMIT $RESULT_LIMIT");
$prod_rows = [];
if ($prod_res) { while ($r = DB::fetch_assoc($prod_res)) { $prod_rows[] = $r; } }

if (!empty($prod_rows)) {
    $any_results = true;
    htm_Card_(sprintf(lang('@Products (%d)'), count($prod_rows)), 1000);
    $data = [];
    foreach ($prod_rows as $r) {
        $data[] = [
            '<a href="product_edit.php?id=' . (int)$r['prod_id'] . '">' . htmlspecialchars($r['prod_name']) . '</a>',
            htmlspecialchars($r['prod_sku'] ?? ''),
            fmt_dk((float)$r['prod_price']),
            rtrim(rtrim(fmt_dk((float)$r['prod_stock'], 3), '0'), tc_num_sep()[0]),      // (stod rå fra databasen: "7.5000")
        ];
    }
    htm_Table(['@Name', '@SKU', '@Price', '@Stock'], $data, 'search_prod_tbl', 100);
    htm_Card_end();
}

// NYT: søgningen dækkede kun de fem oprindelige moduler - Tilbud/Anlægsaktiver/Timeregistrering (alle tre bygget
// SENERE end selve global-søgningen) blev aldrig koblet på. En søgning på et firmanavn fandt derfor ikke et tilbud
// lavet til dem, selvom tilbuddet er et fuldgyldigt dokument på lige fod med en faktura.

// --- TILBUD ---
// Tilbudsnummeret vises som "T-000012" - det søgte man på, men kolonnen rummer kun tallet 12
$sr_q_sql = preg_match('/^\s*T-?0*(\d+)\s*$/i', $q, $sr_qm) ? " OR q.quote_no = " . (int)$sr_qm[1] : '';
$quote_res = @DB::query($conn, "SELECT q.quote_id, q.quote_no, q.status, q.quote_date, c.cust_name
    FROM quotes q JOIN customers c ON q.cust_id = c.cust_id
    WHERE {$L('q.quote_no')} OR {$L('c.cust_name')} OR {$L('q.cust_reference')}$sr_q_sql
    ORDER BY q.quote_date DESC LIMIT $RESULT_LIMIT");
if ($quote_res !== false) {
    $quote_rows = [];
    while ($r = DB::fetch_assoc($quote_res)) { $quote_rows[] = $r; }
    if (!empty($quote_rows)) {
        $any_results = true;
        htm_Card_(sprintf(lang('@Quotes (%d)'), count($quote_rows)), 1000);
        $data = [];
        foreach ($quote_rows as $r) {
            $data[] = [
                '<a href="quote_view.php?id=' . (int)$r['quote_id'] . '">T-' . str_pad((string)$r['quote_no'], 6, '0', STR_PAD_LEFT) . '</a>',
                htmlspecialchars($r['cust_name']),
                date(CONF_DATE_FORMAT, strtotime($r['quote_date'])),
                ($sr_q = ['draft' => '@Draft', 'sent' => '@Sent', 'accepted' => '@Accepted', 'rejected' => '@Rejected', 'converted' => '@Converted to Invoice'][$r['status']] ?? null)
                    ? lang($sr_q) : htmlspecialchars(ucfirst((string)$r['status'])),
            ];
        }
        htm_Table(['@Quote', '@Customer', '@Date', '@Status'], $data, 'search_quote_tbl', 100);
        htm_Card_end();
    }
}

// --- ANLÆGSAKTIVER ---
$asset_res = @DB::query($conn, "SELECT asset_id, asset_name, description, acquisition_date, status FROM fixed_assets
    WHERE {$L('asset_name')} OR {$L('description')}
    ORDER BY acquisition_date DESC LIMIT $RESULT_LIMIT");
if ($asset_res !== false) {
    $asset_rows = [];
    while ($r = DB::fetch_assoc($asset_res)) { $asset_rows[] = $r; }
    if (!empty($asset_rows)) {
        $any_results = true;
        htm_Card_(sprintf(lang('@Fixed Assets (%d)'), count($asset_rows)), 1000);
        $data = [];
        foreach ($asset_rows as $r) {
            $data[] = [
                '<a href="fixed_asset_edit.php?id=' . (int)$r['asset_id'] . '">' . htmlspecialchars($r['asset_name']) . '</a>',
                htmlspecialchars($r['description'] ?? ''),
                date(CONF_DATE_FORMAT, strtotime($r['acquisition_date'])),
                ($sr_a = ['active' => '@Active', 'disposed' => '@Disposed', 'cancelled' => '@Cancelled'][$r['status']] ?? null)
                    ? lang($sr_a) : htmlspecialchars(ucfirst((string)$r['status'])),
            ];
        }
        htm_Table(['@Name', '@Description', '@Acquired', '@Status'], $data, 'search_asset_tbl', 100);
        htm_Card_end();
    }
}

// --- TIMEREGISTRERING ---
$time_res = @DB::query($conn, "SELECT t.entry_id, t.entry_date, t.description, t.hours, p.proj_no
    FROM time_entries t LEFT JOIN projects p ON t.proj_id = p.proj_id
    WHERE {$L('t.description')} OR {$L('p.proj_no')}
    ORDER BY t.entry_date DESC LIMIT $RESULT_LIMIT");
if ($time_res !== false) {
    $time_rows = [];
    while ($r = DB::fetch_assoc($time_res)) { $time_rows[] = $r; }
    if (!empty($time_rows)) {
        $any_results = true;
        htm_Card_(sprintf(lang('@Time Entries (%d)'), count($time_rows)), 1000);
        $data = [];
        foreach ($time_rows as $r) {
            $data[] = [
                '<a href="time_entry_edit.php?id=' . (int)$r['entry_id'] . '">' . htmlspecialchars($r['description'] ?? '') . '</a>',
                htmlspecialchars($r['proj_no'] ?? ''),
                date(CONF_DATE_FORMAT, strtotime($r['entry_date'])),
                fmt_dk((float)$r['hours']),
            ];
        }
        htm_Table(['@Description', '@Project', '@Date', '@Hours'], $data, 'search_time_tbl', 100);
        htm_Card_end();
    }
}

if (!$any_results) {
    htm_Alert(sprintf(lang('@No results found for "%s".'), htmlspecialchars($q)), 'info', 700, true);
}

echo "</div>";
htm_Footer();
ob_end_flush();
?>
