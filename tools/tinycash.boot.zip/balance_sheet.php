<?php # /balance_sheet.php v:1.3.0 d:2026-08-30 i:evs
# Ny side - fandtes ikke i systemet før (§regnskabslov-status, fase 2 trin 1).
# Statusopgørelse (Aktiver/Passiver) efter ÅRL skema 1 - forenklet til det
# kontoplanen understøtter. Beregningen ligger i inc/annual_report.lib.php
# (delt med annual_report.php) - se den fil for fortegnskonventionen.
# v1.1.0: beregningslogik udtrukket til inc/annual_report.lib.php (DRY, deles
# nu med annual_report.php i stedet for at være duplikeret).
# v1.2.0: tilføjet samme "udkast, ikke indberetningsklar"-advarsel som
# annual_report.php fik - denne side viser samme type data (bruger-anmodet)
# v1.2.1: begrænset til user_level 3 (bruger-anmodet) - $rLev skal sættes FØR
# auth.inc.php inkluderes (se inc/auth.inc.php linje ~97).
$rLev = 3;
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';
require_once 'inc/annual_report.lib.php';

$s = get_settings($conn);
$currency = $s['currency'] ?? 'DKK';

$as_of = $_GET['as_of'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $as_of)) $as_of = date('Y-m-d');

$bs = arl_balance_sheet($conn, $as_of);

htm_Header(lang('@Balance Sheet'));
showMenu();

echo "<div style='max-width:1000px; margin:0 auto; padding:10px;'>";

echo '<form method="get" style="margin-bottom:16px; display:flex; align-items:center; gap:10px;">';
echo '<label style="font-weight:bold; font-size:0.9em;">' . lang('@Status as of') . ':</label>';
echo '<input type="date" name="as_of" value="' . htmlspecialchars($as_of) . '" onchange="this.form.submit()" style="padding:6px; border:1px solid var(--border-color); border-radius:4px;">';
echo '</form>';

// Samme forbehold som annual_report.php (§regnskabslov-status): dette er en
// intern statusopgørelse beregnet direkte fra bogføringen - ikke en officielt
// indberettet balance. Genbruger samme oversættelsesnøgle for konsistens.
echo '<div style="margin-bottom:16px; padding:10px 14px; background:#fbeaea; border-left:4px solid #c0392b; border-radius:4px; color:#c0392b; font-size:0.85em; font-weight:bold;">'
   . lang('@DRAFT - not suitable for direct filing with the Danish Business Authority. Requires digital XBRL submission via virk.dk or an accountant.')
   . '</div>';

if (abs($bs['diff']) > 0.01) {
    htm_Alert(sprintf(lang('@Balance does not match: Assets and Liabilities+Equity differ by %s %s. This may indicate a posting outside the normal flows.'), fmt_dk($bs['diff']), $currency), 'error');
} else {
    htm_Alert(lang('@Assets equal Liabilities + Equity. The balance is correct.'), 'success');
}

echo "<div style='display:grid; grid-template-columns: 1fr 1fr; gap:20px;'>";

    // ===== AKTIVER =====
    htm_Card_(lang('@Assets'), '480');
    $rows = [];
    foreach ($bs['asset_rows'] as $r) {
        $rows[] = [$r['acc_id'] . ' - ' . htmlspecialchars($r['acc_name']), '<div style="text-align:right;">' . fmt_dk($r['balance']) . '</div>'];
    }
    if ($bs['vat_is_asset'] && $bs['vat_net'] != 0) {
        $rows[] = [lang('@VAT receivable'), '<div style="text-align:right;">' . fmt_dk($bs['vat_net']) . '</div>'];
    }
    if (empty($rows)) {
        htm_Note(lang('@No asset postings found.'), 'font-style:italic;');
    } else {
        htm_Table(['@Account', '@Balance'], $rows, 'assets_tbl', 100, '', true, [], '500px', 'aktiver.csv');
    }
    echo '<div style="display:flex; justify-content:space-between; padding:14px 0; margin-top:8px; border-top:2px solid var(--color-primary); font-weight:bold;">';
    echo '<span>' . lang('@Total Assets') . '</span><span>' . fmt_dk($bs['assets_total']) . ' ' . $currency . '</span>';
    echo '</div>';
    htm_Card_end();

    // ===== PASSIVER =====
    htm_Card_(lang('@Liabilities and Equity'), '480');

    echo '<h4 style="margin:0 0 8px; font-size:0.95em; color:var(--text-muted);">' . lang('@Equity') . '</h4>';
    $rows = [];
    foreach ($bs['equity_rows'] as $r) {
        $rows[] = [$r['acc_id'] . ' - ' . htmlspecialchars($r['acc_name']), '<div style="text-align:right;">' . fmt_dk(-$r['balance']) . '</div>'];
    }
    $rows[] = ['<em>' . lang('@Result for the year (not yet closed)') . '</em>', '<div style="text-align:right;">' . fmt_dk($bs['unclosed_result']) . '</div>'];
    htm_Table(['@Account', '@Balance'], $rows, 'equity_tbl', 100, '', true, [], '500px', 'egenkapital.csv');

    echo '<h4 style="margin:16px 0 8px; font-size:0.95em; color:var(--text-muted);">' . lang('@Liabilities') . '</h4>';
    $rows = [];
    foreach ($bs['liability_rows'] as $r) {
        $rows[] = [$r['acc_id'] . ' - ' . htmlspecialchars($r['acc_name']), '<div style="text-align:right;">' . fmt_dk(-$r['balance']) . '</div>'];
    }
    if (!$bs['vat_is_asset'] && $bs['vat_net'] != 0) {
        $rows[] = [lang('@VAT payable'), '<div style="text-align:right;">' . fmt_dk(-$bs['vat_net']) . '</div>'];
    }
    if (empty($rows)) {
        htm_Note(lang('@No liability postings found.'), 'font-style:italic;');
    } else {
        htm_Table(['@Account', '@Balance'], $rows, 'liab_tbl', 100, '', true, [], '500px', 'passiver.csv');
    }

    echo '<div style="display:flex; justify-content:space-between; padding:14px 0; margin-top:8px; border-top:2px solid var(--color-primary); font-weight:bold;">';
    echo '<span>' . lang('@Total Liabilities and Equity') . '</span><span>' . fmt_dk($bs['passives_total']) . ' ' . $currency . '</span>';
    echo '</div>';
    htm_Card_end();

echo "</div>"; // grid

// NYT: ingen side beregnede de klassiske regnskabsnøgletal. Likviditetsgrad kan IKKE beregnes fuldt korrekt her -
// kontoplanen har ingen "kortfristet vs. langfristet"-opdeling af aktiver/passiver (kun flade acc_type-kategorier)
// - i stedet en BEVIDST forenklet, tydeligt mærket udgave: (bank + debitorer) / kreditorer, de tre konti systemet
// allerede selv bruger til netop disse formål (conf_acc_bank/debitor/creditor, samme som
// subledger_reconciliation.php/aging_report.php).
$soliditetsgrad = $bs['assets_total'] > 0 ? ($bs['equity_total'] / $bs['assets_total'] * 100) : null;

$as_of_esc = DB::escape($conn, $as_of);
$acc_bank_bs     = (int)($s['conf_acc_bank']     ?? 5000);
$acc_debitor_bs  = (int)($s['conf_acc_debitor']  ?? 8100);
$acc_creditor_bs = (int)($s['conf_acc_creditor'] ?? 4000);
function bs_acc_balance($conn, int $acc_id, string $as_of_esc): float {
    $row = DB::fetch_assoc(DB::query($conn, "SELECT SUM(l.amount) AS bal FROM ledger l JOIN journal j ON l.jou_id = j.jou_id WHERE l.acc_id = $acc_id AND j.jou_date <= '$as_of_esc'"));
    return (float)($row['bal'] ?? 0);
}
// RETTET: kun conf_acc_bank talte med - kasse, opsparing og andre konti af typen 'bank' blev ignoreret, så
// likviditetsgraden var for lav. Nu samme kontoudvalg som forsidens saldograf (index.php).
$bank_ids_bs = [$acc_bank_bs];
$bres_bs = DB::query($conn, "SELECT acc_id FROM accounts WHERE acc_type = 'bank'");
while ($bres_bs && ($br = DB::fetch_assoc($bres_bs))) $bank_ids_bs[] = (int)$br['acc_id'];
$bank_bal = 0.0;
foreach (array_unique($bank_ids_bs) as $bid) $bank_bal += bs_acc_balance($conn, $bid, $as_of_esc);
$debitor_bal  = bs_acc_balance($conn, $acc_debitor_bs, $as_of_esc);
$creditor_bal = -bs_acc_balance($conn, $acc_creditor_bs, $as_of_esc); // kreditkonto er negativ i hovedbogen
$likviditetsgrad = $creditor_bal > 0.01 ? (($bank_bal + $debitor_bal) / $creditor_bal * 100) : null;

echo "<div style='margin-top:20px;'>";
htm_Card_(lang('@Key Financial Ratios'), '1000');
htm_Note(lang('@Reference figures only - not part of the official balance sheet above.'), 'font-size:0.85em; margin-top:-5px;');
echo '<div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">';
echo '<div><div style="color:var(--text-muted); font-size:0.85em;">' . lang('@Solvency Ratio (Equity / Total Assets)') . '</div><div style="font-weight:bold; font-size:1.3em;">' . ($soliditetsgrad !== null ? fmt_dk($soliditetsgrad, 1) . ' %' : '—') . '</div></div>';
echo '<div><div style="color:var(--text-muted); font-size:0.85em;">' . lang('@Simplified Liquidity Ratio ((Bank + Receivables) / Payables)') . '</div><div style="font-weight:bold; font-size:1.3em;">' . ($likviditetsgrad !== null ? fmt_dk($likviditetsgrad, 1) . ' %' : '—') . '</div></div>';
echo '</div>';
htm_Note(lang('@The liquidity ratio is a simplification using only the configured bank/receivables/payables control accounts - the chart of accounts does not distinguish current from long-term assets/liabilities, so a full current ratio cannot be calculated reliably.'), 'font-size:0.8em; margin-top:12px; margin-bottom:0;');
htm_Card_end();
echo "</div>";

echo "</div>"; // container

htm_Footer();
?>
