<?php # /send_quote_action.php v:1.3.0 d:2026-08-30 i:evs
# AJAX-handler der mailer et tilbud/en ordrebekræftelse til kunden - samme
# mønster som send_invoice_action.php, men UDEN dens kladde-låsning: et
# tilbud SKAL netop kunne sendes mens det stadig er 'draft' (det er selve
# afsendelsen der gør det til 'sent') - der er intet "bogført"-krav for et
# tilbud, i modsætning til en faktura.
// RETTET: fejlvisning var tvunget TIL - en PHP-advarsel endte midt i JSON-svaret (ødelagt svar i browseren) og viste
// serverstier. Styres centralt med ?Debug=true (inc/db_connect.inc.php), samme som send_invoice_action.php.
header('Content-Type: application/json');

try {
    require_once 'inc/auth.inc.php';
    require_once 'inc/db_connect.inc.php';
    require_once 'inc/mail_handler.lib.php';
    require_once 'inc/php2htm.lib.php';
    require_once 'inc/audit.inc.php';

    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id === 0) {
        echo json_encode(['success' => false, 'error' => lang('@Invalid ID')]);
        exit;
    }

    $sql = "SELECT q.*, c.cust_name, c.cust_email FROM quotes q JOIN customers c ON q.cust_id = c.cust_id WHERE q.quote_id = $id";
    $res = DB::query($conn, $sql);
    if (!$res) throw new Exception("Database error: " . DB::error($conn));
    $q = DB::fetch_assoc($res);
    if (!$q) {
        echo json_encode(['success' => false, 'error' => lang('@Invoice or customer not found')]);
        exit;
    }

    if (empty($q['cust_email'])) {
        echo json_encode(['success' => false, 'error' => lang('@This customer has no email address registered.')]);
        exit;
    }

    // Vedhæftningen er en midlertidig fil, der altid slettes igen. Før lå den som storage/quote_<id>.pdf - fælles for alle
    // regnskaber (samme tilbuds-id) og blev liggende, når mailen fejlede - og hvad som helst blev sendt som "PDF"
    $tmpBase = tempnam(sys_get_temp_dir(), 'tcq');
    $pdfPath = $tmpBase . '.pdf';      // (filnavnet på vedhæftningen kommer fra $doc_label, ikke herfra)
    register_shutdown_function(function () use ($tmpBase, $pdfPath) { @unlink($tmpBase);  @unlink($pdfPath); });
    if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['pdf_file']['tmp_name'], $pdfPath);
    } elseif (isset($_POST['pdf_data'])) {
        $data = $_POST['pdf_data'];
        if (strpos($data, ',') !== false) $data = explode(',', $data)[1];
        file_put_contents($pdfPath, base64_decode($data));
    } else {
        echo json_encode(['success' => false, 'error' => lang('@No PDF data received from the browser.')]);
        exit;
    }

    $fh = @fopen($pdfPath, 'rb');  $head = $fh ? (string)fread($fh, 5) : '';  if ($fh) fclose($fh);
    if (!file_exists($pdfPath) || filesize($pdfPath) === 0 || $head !== '%PDF-') {
        echo json_encode(['success' => false, 'error' => lang('@PDF file could not be saved or was empty.')]);
        exit;
    }

    // RETTET: emne og standardtekst fulgte den indloggede brugers sprog, ikke kundens (som fakturamailen gør)
    require_once __DIR__ . '/inc/doc_paper.inc.php';
    doc_lang_push(doc_customer_lang($conn, (int)$q['cust_id']));
    $quote_no_display = 'T-' . str_pad((string)$q['quote_no'], 6, '0', STR_PAD_LEFT);
    $is_confirmation = in_array($q['status'], ['accepted', 'converted'], true);
    $doc_title = $is_confirmation ? lang('@Order Confirmation') : lang('@Quote');
    $subject = $doc_title . ' ' . $quote_no_display;
    // ASCII-sikkert (uden æ/ø/å) til selve vedhæftningens filnavn - se
    // sendTinyMail()'s nye $doc_label-parameter, §bugs-batch-31-review.
    $doc_label = $is_confirmation ? 'Ordrebekraeftelse' : 'Tilbud';

    $sys_settings = function_exists('get_settings') ? get_settings($conn) : [];
    if (isset($_POST['custom_body']) && trim($_POST['custom_body']) !== '') {
        $body = nl2br(htmlspecialchars($_POST['custom_body']));
    } else {
        // RETTET: hårdkodet engelsk og dobbelt escapet kundenavn - se send_invoice_action.php
        // (firmaets egen standardtekst er en FAKTURAtekst - et tilbud får sin egen oversatte tekst)
        // RETTET: en ORDREBEKRÆFTELSE (accepteret tilbud) blev sendt med emnet "Ordrebekræftelse", men teksten
        // "Vedhæftet finder du dit tilbud" - kunden kunne tro, at der var tale om et nyt tilbud
        $fallback_text = $is_confirmation
            ? sprintf(lang("@Hi %s,\n\nPlease find your order confirmation attached.\n\nBest regards,"), $q['cust_name'])
            : sprintf(lang("@Hi %s,\n\nPlease find your quote attached.\n\nBest regards,"), $q['cust_name']);
        $body = nl2br(htmlspecialchars($fallback_text));
    }
    doc_lang_pop();

    $result = sendTinyMail($q['cust_email'], $q['cust_name'], $subject, $body, $pdfPath, $q['quote_no'], $doc_label);

    if (isset($result['success']) && $result['success'] == true) {
        // Kun 'draft' -> 'sent' - en gensendelse af et allerede accepteret/
        // afvist/konverteret tilbud må ikke rulle den reelle kunde-beslutning
        // tilbage (samme princip som send_invoice_action.php's paid/credited-
        // undtagelse).
        if ($q['status'] === 'draft') {
            DB::query($conn, "UPDATE quotes SET status = 'sent' WHERE quote_id = $id");
            log_action($conn, 'MARK_QUOTE_SENT', 'quotes', $id, ['status' => 'draft'], ['status' => 'sent', 'to' => $q['cust_email']]);
        }
    }

    echo json_encode($result);
    exit;

} catch (Throwable $e) {
    error_log('[send_quote_action] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    echo json_encode(['success' => false, 'error' => lang('@PHP Error:') . ' ' . $e->getMessage()]);      // (fil og linje kun i loggen)
    exit;
}
?>
