<?php # /fixed_asset_dispose.php v:1.3.0 d:2026-08-30 i:evs
# NY FUNKTION: Anlægsaktiver/afskrivninger - afhændelse (solgt eller
# kasseret). Fjerner aktivets resterende bogførte værdi (netto) fra
# aktivkontoen og bogfører en eventuel gevinst/tab på afskrivningskontoen:
#   KREDIT aktivkonto        = − bogført værdi (fjerner resten fra bøgerne)
#   DEBET  bank               = + salgsprovenu (0 hvis kasseret)
#   DEBET/KREDIT afskrivningskonto = differencen (tab hvis solgt under bogført
#   værdi, gevinst hvis solgt over - bevidst bogført på samme konto som den
#   løbende afskrivning, for ikke at kræve endnu en kontovælger for et
#   sjældent forekommende beløb, jf. den flade kontoplan-filosofi ellers brugt
#   i projektet, se inc/annual_report.lib.php's egen kommentar herom).
ob_start();
require_once 'inc/auth.inc.php';
require_once 'inc/db_connect.inc.php';
require_once 'inc/menu.inc.php';
require_once 'inc/php2htm.lib.php';
require_once 'inc/audit.inc.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { redirect("fixed_asset_list.php"); }

$res   = DB::query($conn, "SELECT * FROM fixed_assets WHERE asset_id = $id");
$asset = $res ? DB::fetch_assoc($res) : null;
if (!$asset) { redirect("fixed_asset_list.php"); }
if ($asset['status'] !== 'active') { redirect("fixed_asset_list.php"); }

$nbv = round((float)$asset['acquisition_cost'] - (float)$asset['accumulated_depreciation'], 2);
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_dispose'])) {
    $dispose_date = trim($_POST['disposed_date'] ?? date('Y-m-d'));
    $proceeds     = parse_dk_number($_POST['disposal_proceeds'] ?? 0);

    // RETTET: datoen blev ikke kontrolleret - en afhændelse FØR seneste afskrivning (eller før anskaffelsen)
    // blev bogført med en restværdi der allerede var afskrevet for måneder EFTER salget, og en tom / ugyldig
    // dato gav en journalpost uden dato. En fremtidig dato bogførte salget i en periode der ikke er nået.
    $fa_floor = max((string)$asset['acquisition_date'], (string)($asset['last_depreciated_date'] ?? ''));
    if (!tc_is_date($dispose_date)) {
        $err = lang('@Please enter a valid date.');
    } elseif (trim((string)($_POST['disposal_proceeds'] ?? '')) !== '' && tc_num($_POST['disposal_proceeds']) === null) {      // ("12.500 kr" blev til 12,50)
        $err = lang('@Please enter a valid amount.');
    // RETTET: et negativt salgsprovenu (fx "-5.000" tastet for et tab) blev taget imod - banken blev KREDITERET
    // som om virksomheden betalte køberen, og tabet blev dobbelt så stort. Et tab beregnes selv ud fra restværdien.
    } elseif ($proceeds < 0) {
        $err = lang('@The sales price cannot be negative - enter 0 if the asset is scrapped.');
    } elseif ($dispose_date > date('Y-m-d')) {
        $err = lang('@The disposal date cannot be in the future.');
    } elseif ($dispose_date < $fa_floor) {
        $err = sprintf(lang('@The disposal date cannot be before the acquisition or the last posted depreciation (%s).'), date(CONF_DATE_FORMAT, strtotime($fa_floor)));
    } elseif (is_date_locked($conn, $dispose_date)) {
        $err = lang('@The disposal date is in a locked accounting period.');
    } else {
        DB::begin_transaction($conn);
        try {
            // Atomisk claim - samme mønster som resten af sessionens
            // kapløbsrettelser: kun ét afhændelsesforsøg må reelt gennemføres.
            $claim = DB::prepare_and_execute($conn,
                "UPDATE fixed_assets SET status = 'disposed', disposed_date = ?, disposal_proceeds = ? WHERE asset_id = ? AND status = 'active'",
                [$dispose_date, $proceeds, $id]);
            if (!$claim || DB::affected_rows($conn, $claim) < 1) {
                throw new Exception(lang('@This asset was already disposed of by another, simultaneous request.'));
            }

            // RETTET: hele salgsprisen blev ført som provenu uden salgsmoms. "Inkl. moms" (standard) udskiller nu
            // 25 % moms til salgsmomskontoen; fjern fluebenet ved fx salg af et aktiv, der er købt uden
            // momsfradrag.
            $ds_settings = get_settings($conn);
            $sale_vat   = !empty($_POST['proceeds_incl_vat']) ? tc_vat_of_gross((float)$proceeds) : 0.0;
            $net_proceeds = round($proceeds - $sale_vat, 2);
            $gain_loss  = round($net_proceeds - $nbv, 2);
            $acc_bank   = (int)($ds_settings['conf_acc_bank'] ?? 5000);
            $voucher_no = next_voucher_no($conn);
            $jou_text   = DB::escape($conn, lang('@Disposal of fixed asset:') . ' ' . $asset['asset_name']);
            // RETTET (§currency-setting-is-cosmetic-label): journal.currency
            // blev aldrig sat (faldt tilbage til skemaets DEFAULT 'DKK').
            $jou_currency = DB::escape($conn, $global_settings['currency'] ?? 'DKK');
            // NYT (BEK 811/2026-gennemgang, [[digital-standard-bookkeeping-registration-goal]]).
            $cb = journal_created_by_sql($conn);

            DB::query($conn, "INSERT INTO journal (jou_date, jou_text, trans_type, voucher_no, currency{$cb['col']})
                VALUES ('" . DB::escape($conn, $dispose_date) . "', '$jou_text', 'fixed_asset_disposal', $voucher_no, '$jou_currency'{$cb['val']})");
            $jou_id = DB::insert_id($conn);

            if ($nbv != 0)      ledger_post($conn, $jou_id, (int)$asset['asset_account_id'], $nbv * -1);
            if ($proceeds != 0) ledger_post($conn, $jou_id, $acc_bank, $proceeds);
            if ($sale_vat != 0) ledger_post($conn, $jou_id, (int)($ds_settings['conf_acc_vat'] ?? 6900), -$sale_vat);
            if ($gain_loss != 0) ledger_post($conn, $jou_id, (int)$asset['depreciation_account_id'], $gain_loss * -1);

            log_action($conn, 'DISPOSE_FIXED_ASSET', 'fixed_assets', $id,
                ['status' => 'active', 'net_book_value' => $nbv],
                ['status' => 'disposed', 'proceeds' => $proceeds, 'sale_vat' => $sale_vat, 'gain_loss' => $gain_loss, 'disposal_voucher_no' => $voucher_no]);

            DB::commit($conn);
            redirect('fixed_asset_list.php', '@Asset disposed successfully.');
        } catch (Exception $e) {
            DB::rollback($conn);
            $err = lang('@Error:') . ' ' . $e->getMessage();
        }
    }
}

htm_Header(lang('@Dispose Fixed Asset'));
showMenu();

if ($err) htm_Alert($err, 'error');

$s   = get_settings($conn);
$cur = $s['currency'] ?? 'DKK';

echo "<div style='max-width:600px; margin:20px auto;'>";
htm_Card_(capt: '@Dispose Fixed Asset', wdth: 600);

$notice = '<strong><i class="fa fa-info-circle"></i> ' . lang('@What happens when you dispose of this asset:') . '</strong><ul style="margin:8px 0 0 0; padding-left:20px; line-height:1.8;">'
    . '<li>' . sprintf(lang('@The remaining net book value (%s) is removed from the asset account'), fmt_dk($nbv) . ' ' . $cur) . '</li>'
    . '<li>' . lang('@Any sale proceeds are posted to the bank account') . '</li>'
    . '<li>' . lang('@Any gain or loss versus the net book value is posted to the depreciation account') . '</li>'
    . '<li>' . lang('@No further depreciation can be posted for this asset afterwards') . '</li>'
    . '</ul>';
htm_Banner($notice, 'warning');

echo '<div style="margin-bottom:15px; padding:12px; background:var(--bg-panel); border-radius:6px;">';
echo '<strong>' . htmlspecialchars($asset['asset_name']) . '</strong><br>';
echo '<span style="font-size:0.9em; color:var(--text-muted);">' . lang('@Net Book Value') . ': ' . fmt_dk($nbv) . ' ' . $cur . '</span>';
echo '</div>';

echo '<form method="post">';
csrf_field();
// (efter en fejl beholdes det indtastede - før stod salgsprisen igen på 0,00)
$fa_posted = ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_dispose']));
htm_Field(icon: 'fa-calendar', labl: '@Disposal Date', name: 'disposed_date', valu: (string)($_POST['disposed_date'] ?? date('Y-m-d')), type: 'date', extr: 'required leg:left', wdth: '50%');
htm_Field(icon: 'fa-money-bill-wave', labl: '@Sale Proceeds', name: 'disposal_proceeds', valu: (string)($_POST['disposal_proceeds'] ?? '0,00'), type: 'text',
    extr: 'leg:left style="text-align:right;"', wdth: '50%', hint: '@Enter 0 if the asset was scrapped with no sale value.');
echo '<label style="display:block; margin:6px 0 0; font-size:0.9em;"><input type="checkbox" name="proceeds_incl_vat" value="1"' . ($fa_posted && empty($_POST['proceeds_incl_vat']) ? '' : ' checked') . '> '
   . sprintf(lang('@The sale price includes %s %% VAT (posted as output VAT)'), fmt_pct(tc_vat_std_rate())) . '</label>';

echo '<div style="margin-top:20px; display:flex; gap:10px; border-top:1px solid var(--border-color); padding-top:20px;">';
echo '<button type="submit" name="confirm_dispose" value="1" style="flex:2; background:var(--color-danger); color:white; border:none; padding:12px; border-radius:4px; font-weight:bold; cursor:pointer;">'
   . '<i class="fa fa-box-open"></i> ' . lang('@Confirm Disposal') . '</button>';
echo '<a href="fixed_asset_edit.php?id=' . $id . '" data-hint="' . lang('@Return to the asset without disposing of it') . '" style="flex:1; background:var(--bg-panel); color:var(--text-main); border:1px solid var(--border-color); padding:12px; border-radius:4px; font-weight:bold; text-align:center; text-decoration:none; display:flex; align-items:center; justify-content:center;">' . lang('@Cancel') . '</a>';
echo '</div>';
echo '</form>';

htm_Card_end();
echo "</div>";
htm_Footer();
ob_end_flush();
?>
